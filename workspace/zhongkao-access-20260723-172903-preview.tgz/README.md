# Guangzhou Zhongkao access service

This Node.js 22 service stores verified accounts, orders, sessions and durable product entitlements in SQLite. The browser cookie contains only a random session token; purchase rights remain in the server database.

## Safety state

- `ACCESS_MODE=preview` leaves the existing tool accessible while account and payment flows are tested.
- `OTP_PROVIDER=disabled` refuses login-code requests.
- `PAYMENT_PROVIDER=disabled` refuses order creation and can never grant a paid entitlement.
- Production enforcement must not be enabled until a real SMS provider and a verified WeChat Pay callback are tested end to end.

## Local checks

```powershell
npm run test:zhongkao-access
```

For local UI testing, set `STATIC_DIR` to `dist/zhongkao` and run `npm run dev:zhongkao-access`.

## Production data

- Application releases: `/opt/zhongkao-access/releases/<version>`
- Active symlink: `/opt/zhongkao-access/current`
- Environment file: `/etc/zhongkao-access.env` (`0600`, never committed)
- Database: `/var/lib/zhongkao-access/access.sqlite`

The database and WAL files require encrypted daily off-server backups before payment is enabled.
