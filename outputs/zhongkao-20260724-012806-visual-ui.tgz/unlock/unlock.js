const $ = (selector) => document.querySelector(selector);
const API_BASE = '/api/access';
let config = null;
let session = { authenticated: false, entitled: false };
let countdownTimer = null;

function toast(message) {
  const element = $('#accessToast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove('show'), 3500);
}

async function api(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    credentials: 'include',
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const body = response.status === 204 ? {} : await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(body.error || '服务暂时不可用'), { code: body.code, status: response.status });
  return body;
}

function render() {
  const notice = $('#setupNotice');
  const loginForm = $('#loginForm');
  const accountPanel = $('#accountPanel');
  const purchasePanel = $('#purchasePanel');
  const entitledPanel = $('#entitledPanel');
  if (!config) return;

  if (!config.otpReady || !config.paymentReady) {
    notice.className = 'setup-notice warning';
    notice.textContent = '付费系统正在进行商户与短信通道配置，当前页面不会产生扣款；志愿助手仍处于内部测试阶段。';
  } else if (config.accessMode !== 'enforce') {
    notice.className = 'setup-notice warning';
    notice.textContent = '支付通道已就绪，当前仍为付费切换前测试模式。';
  } else {
    notice.className = 'setup-notice ready';
    notice.textContent = '账户与支付服务运行正常。购买后权益将长期保存在当前账号。';
  }

  $('#requestCode').disabled = !config.otpReady;
  loginForm.hidden = session.authenticated;
  accountPanel.hidden = !session.authenticated;
  if (session.authenticated) $('#phoneLast4').textContent = session.user.phoneLast4;
  purchasePanel.hidden = Boolean(session.entitled);
  entitledPanel.hidden = !session.entitled;
  $('#payButton').disabled = !session.authenticated || !config.paymentReady || !$('#agreement').checked;
  $('#paymentHint').textContent = !session.authenticated
    ? '请先完成登录。'
    : !config.paymentReady
      ? '微信支付商户参数尚未启用，不会产生扣款。'
      : '付款成功后由服务器自动写入长期权益。';
}

async function load() {
  try {
    [config, session] = await Promise.all([api('/config'), api('/session')]);
    render();
  } catch (error) {
    $('#setupNotice').className = 'setup-notice warning';
    $('#setupNotice').textContent = '账户服务尚未启动，当前不会产生扣款。';
    toast(error.message);
  }
}

function startCountdown(seconds) {
  const button = $('#requestCode');
  clearInterval(countdownTimer);
  let remaining = seconds;
  button.disabled = true;
  button.textContent = `${remaining}秒后重试`;
  countdownTimer = setInterval(() => {
    remaining -= 1;
    button.textContent = `${remaining}秒后重试`;
    if (remaining <= 0) {
      clearInterval(countdownTimer);
      button.textContent = '重新获取';
      button.disabled = !config?.otpReady;
    }
  }, 1000);
}

$('#requestCode').addEventListener('click', async () => {
  const phone = $('#phone').value.trim();
  try {
    const result = await api('/auth/request-code', { method: 'POST', body: JSON.stringify({ phone }) });
    startCountdown(Math.min(60, result.expiresIn || 60));
    toast(result.debugCode ? `测试验证码：${result.debugCode}` : '验证码已发送，请注意查收。');
  } catch (error) { toast(error.message); }
});

$('#loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('#loginButton').disabled = true;
  try {
    session = await api('/auth/verify-code', {
      method: 'POST',
      body: JSON.stringify({ phone: $('#phone').value.trim(), code: $('#code').value.trim() })
    });
    toast(session.entitled ? '登录成功，已恢复长期权益。' : '登录成功，可以继续解锁。');
    render();
  } catch (error) { toast(error.message); }
  finally { $('#loginButton').disabled = false; }
});

$('#logoutButton').addEventListener('click', async () => {
  try { await api('/auth/logout', { method: 'POST', body: '{}' }); } catch {}
  session = { authenticated: false, entitled: false };
  render();
  toast('已退出当前账号。');
});

$('#agreement').addEventListener('change', render);

$('#payButton').addEventListener('click', async () => {
  $('#payButton').disabled = true;
  try {
    const result = await api('/orders', { method: 'POST', body: '{}' });
    toast(`订单${result.order.id}已创建，正在打开微信支付…`);
  } catch (error) { toast(error.message); }
  finally { render(); }
});

load();
