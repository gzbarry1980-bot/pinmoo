const storageKey = 'pinmoo-ai-diagnosis-history-v3';
const draftKey = 'pinmoo-ai-diagnosis-draft-v3';
const actionStorageKey = 'pinmoo-ai-action-ledger-v1';
const appVersion = 'v0.11.0 · 2026-07-15 · 经营闭环版';

const fieldIds = [
  'brandName', 'storeName', 'industry', 'reportType', 'reportPurpose', 'periodStart', 'periodEnd', 'period', 'compareType', 'dataSource',
  'sales', 'prevSales', 'visitors', 'prevVisitors', 'conversion', 'aov', 'refundRate', 'roi',
  'productCount', 'activeProductCount', 'topSkuShare', 'serviceRate',
  'searchShare', 'recommendShare', 'contentShare', 'paidShare', 'privateShare', 'notes'
];

const benchmarks = {
  default: { conversion: 3.2, refund: 5, roi: 3, activeRate: 68, service: 90, privateShare: 10, topSkuMax: 55 },
  '美妆个护': { conversion: 3.5, refund: 5, roi: 3.2, activeRate: 70, service: 92, privateShare: 12, topSkuMax: 55 },
  '服装鞋包': { conversion: 2.6, refund: 10, roi: 2.6, activeRate: 62, service: 88, privateShare: 8, topSkuMax: 50 },
  '食品茶饮': { conversion: 3.8, refund: 4, roi: 3.4, activeRate: 72, service: 90, privateShare: 14, topSkuMax: 58 },
  '母婴营养': { conversion: 3.0, refund: 4.5, roi: 3.2, activeRate: 66, service: 94, privateShare: 12, topSkuMax: 52 },
  '家居百货': { conversion: 3.1, refund: 6.5, roi: 3.0, activeRate: 64, service: 88, privateShare: 10, topSkuMax: 60 },
  '产业带工厂': { conversion: 2.8, refund: 6, roi: 2.8, activeRate: 58, service: 86, privateShare: 8, topSkuMax: 62 },
  '本地生活': { conversion: 4.2, refund: 3.5, roi: 3.0, activeRate: 60, service: 92, privateShare: 16, topSkuMax: 65 }
};

const categoryStrategies = {
  default: {
    focus: '先看 GMV 拆解、商品承接、渠道效率和复购资产，避免只按平台后台提示做泛化优化。',
    conversion: '重点检查首图/详情页前三屏、价格解释、评价证据和客服异议处理是否给足购买理由。',
    refund: '把退款原因按 SKU、页面承诺、客服话术和履约体验做矩阵，先处理金额最高的 TOP3 原因。',
    product: '用销售额、访客、转化、退款和毛利给 SKU 分层，确定主推款、潜力款、利润款和清仓款。',
    channel: '按搜索、推荐、内容、付费、私域拆入口效率，判断增长来自自然势能还是预算拉动。',
    action: '先完成核心 SKU 四象限，再决定是改页面、补内容、调投放还是做复购。',
    priorityBoost: {}
  },
  '美妆个护': {
    focus: '美妆个护优先看功效可信度、肤质/场景匹配、评价证据和客服异议，报告要判断“为什么用户敢不敢买”。',
    conversion: '重点检查功效卖点是否有成分、适用人群、使用周期、前后对比和评价证据支撑。',
    refund: '退款要按功效不符、肤感不适、规格预期、物流破损和使用方法误解拆分，避免单纯归因售后。',
    product: '商品分层应区分引流单品、套组、复购装和利润装，关注套组承接与复购周期。',
    channel: '内容渠道要看种草素材到搜索成交的联动，搜索词应围绕功效、人群和场景沉淀。',
    action: '为 TOP SKU 补齐“成分/功效/人群/评价/用法”五段证据链，并同步客服异议话术。',
    priorityBoost: { 转化: 8, 承接: 5, 复购: 4 }
  },
  '服装鞋包': {
    focus: '服装鞋包优先看上新节奏、尺码/版型预期、主图穿搭表达、退款原因和单品动销，报告要判断“款式有没有被正确表达”。',
    conversion: '重点检查主图是否讲清版型、面料、厚薄、弹力、适穿身材和搭配场景。',
    refund: '退款要按尺码不合适、面料预期、色差、版型不符和物流体验拆分，并回写页面与客服推荐。',
    product: '动销诊断要区分新品、爆款、长尾和滞销款，重点看上新后 7/14 天访客与加购承接。',
    channel: '内容和推荐流量要看穿搭场景、上身效果和人群匹配，搜索流量要看品类词/风格词承接。',
    action: '围绕 TOP 款建立尺码建议、模特信息、面料说明、买家秀和退款 TOP 原因修复清单。',
    priorityBoost: { 利润: 10, 货品: 8, 转化: 4 }
  },
  '食品茶饮': {
    focus: '食品茶饮优先看复购周期、礼盒/自饮分层、口味信任、内容种草和老客贡献，报告要判断“买一次后能不能持续买”。',
    conversion: '重点检查产地、口味、规格、饮用场景、送礼理由和评价证据是否形成购买理由。',
    refund: '退款要按口味预期、包装破损、规格误解、发货时效和保质期疑虑拆分。',
    product: '商品分层应区分试饮/引流款、礼盒款、自饮复购款和高客单组合款。',
    channel: '私域和会员贡献要重点看，内容渠道应承接到礼盒场景、节令场景和复购提醒。',
    action: '建立“新客试饮-礼盒转化-老客复购”的 7/14/30 天触达 SOP。',
    priorityBoost: { 复购: 10, 渠道: 5, 转化: 4 }
  },
  '母婴营养': {
    focus: '母婴营养优先看安全信任、适龄/适用阶段、专业背书、客服解释和复购周期，报告要判断“信任门槛有没有被跨过”。',
    conversion: '重点检查适用月龄/阶段、成分安全、资质背书、使用方法和常见顾虑是否讲清。',
    refund: '退款要按适用阶段误解、过敏/不适担忧、规格预期、物流破损和客服解释不足拆分。',
    product: '商品分层应区分试用装、阶段款、复购装和组合装，关注阶段迁移与会员沉淀。',
    channel: '内容要更重信任和解释，私域要承接复购提醒、阶段升级和高频问答。',
    action: '为核心 SKU 建立“适用人群-禁忌提醒-使用方法-妈妈问答-复购周期”诊断表。',
    priorityBoost: { 转化: 8, 承接: 8, 复购: 6 }
  },
  '家居百货': {
    focus: '家居百货优先看场景展示、规格参数、安装/使用门槛、履约体验和组合销售，报告要判断“用户是否看懂并买对”。',
    conversion: '重点检查尺寸、材质、安装方式、适用空间、对比图和使用场景是否清楚。',
    refund: '退款要按尺寸不符、材质预期、安装困难、破损和物流时效拆分。',
    product: '商品分层应看主推规格、组合装、替换装和低动销长尾，减少无效 SKU 占用。',
    channel: '搜索承接要覆盖规格词/场景词，推荐和内容要突出空间效果与解决问题。',
    action: '补齐 TOP SKU 的尺寸示意、场景图、安装说明和售前问答，降低买错退货。',
    priorityBoost: { 转化: 6, 利润: 6, 货品: 4 }
  },
  '产业带工厂': {
    focus: '产业带工厂优先看商品标准化、价格带、供货稳定、内容包装和爆款复制，报告要判断“供应链优势有没有转成线上表达”。',
    conversion: '重点检查价格优势、规格选择、品质证明、交付能力和差异化卖点是否表达出来。',
    refund: '退款要按品质不符、规格误解、发货时效、包装问题和客服承诺拆分。',
    product: '商品分层要先砍长尾、保主推、测潜力款，把供应链 SKU 转成线上可成交 SKU。',
    channel: '付费和活动不能只冲低价，要看自然搜索词和内容素材是否沉淀可复用资产。',
    action: '把核心 10-20 个 SKU 做成标准化卖点卡、价格带表和供应链交付承诺表。',
    priorityBoost: { 货品: 10, 渠道: 5, 转化: 4 }
  },
  '本地生活': {
    focus: '本地生活优先看到店/预约转化、区域流量、评价口碑、履约体验和私域复访，报告要判断“线上线下承接是否闭环”。',
    conversion: '重点检查套餐权益、门店距离、预约规则、评价口碑、使用限制和客服承接。',
    refund: '退款要按预约失败、权益理解偏差、到店体验、服务时效和核销限制拆分。',
    product: '商品分层应区分引流套餐、利润套餐、复购套餐和节日活动套餐。',
    channel: '区域推荐、搜索和私域复访要联动，重点看核销、复购和评价回流。',
    action: '建立“下单-预约-到店-核销-评价-复访”的链路诊断和话术 SOP。',
    priorityBoost: { 承接: 8, 复购: 10, 转化: 6 }
  }
};

const samples = [
  {
    storeName: '某美妆旗舰店',
    industry: '美妆个护',
    platform: '天猫',
    reportType: '月报',
    period: '2026-04-15 至 2026-05-14',
    compareType: '上一个周期',
    dataSource: '示例数据',
    sales: 285670,
    prevSales: 312456,
    visitors: 186543,
    prevVisitors: 210234,
    conversion: 2.35,
    aov: 156.8,
    refundRate: 4.21,
    roi: 2.85,
    productCount: 86,
    activeProductCount: 54,
    topSkuShare: 41.8,
    serviceRate: 86.5,
    searchShare: 34,
    recommendShare: 18,
    contentShare: 21,
    paidShare: 19,
    privateShare: 8,
    notes: '近30天投放预算缩减，访客下滑明显；爆款 SKU 评价里多次提到色差和发货慢。'
  },
  {
    storeName: '某茶叶品牌店',
    industry: '食品茶饮',
    platform: '抖音',
    reportType: '月报',
    period: '2026-04-15 至 2026-05-14',
    compareType: '上一个周期',
    dataSource: '示例数据',
    sales: 418920,
    prevSales: 351400,
    visitors: 148300,
    prevVisitors: 126800,
    conversion: 3.12,
    aov: 238,
    refundRate: 2.18,
    roi: 3.7,
    productCount: 42,
    activeProductCount: 31,
    topSkuShare: 58.4,
    serviceRate: 92.2,
    searchShare: 19,
    recommendShare: 25,
    contentShare: 33,
    paidShare: 15,
    privateShare: 8,
    notes: '直播间成交提升，但商品分层不清晰，礼盒款和自饮款承接路径混在一起。'
  },
  {
    storeName: '某服饰集合店',
    industry: '服装鞋包',
    platform: '小红书',
    reportType: '月报',
    period: '2026-04-15 至 2026-05-14',
    compareType: '上一个周期',
    dataSource: '示例数据',
    sales: 168240,
    prevSales: 221600,
    visitors: 94600,
    prevVisitors: 121900,
    conversion: 1.42,
    aov: 189,
    refundRate: 12.4,
    roi: 1.62,
    productCount: 126,
    activeProductCount: 52,
    topSkuShare: 67.2,
    serviceRate: 73.6,
    searchShare: 22,
    recommendShare: 18,
    contentShare: 37,
    paidShare: 18,
    privateShare: 5,
    notes: '内容互动还可以，但进店转化弱；尺码、面料和适穿人群表达不足，退货集中在两个新款。'
  }
];

function blankFormData() {
  return {
    brandName: '',
    storeName: '',
    industry: '美妆个护',
    platform: '天猫',
    reportType: '周报',
    reportPurpose: '品牌方正式版',
    periodStart: '',
    periodEnd: '',
    period: '',
    compareType: '上一个周期',
    dataSource: '',
    sales: 0,
    prevSales: 0,
    visitors: 0,
    prevVisitors: 0,
    conversion: 0,
    aov: 0,
    refundRate: 0,
    roi: 0,
    productCount: 0,
    activeProductCount: 0,
    topSkuShare: 0,
    serviceRate: 0,
    searchShare: 0,
    recommendShare: 0,
    contentShare: 0,
    paidShare: 0,
    privateShare: 0,
    notes: ''
  };
}

let selectedPlatform = '天猫';
let history = loadJson(storageKey, []);
let actionLedger = loadJson(actionStorageKey, []);
if (!Array.isArray(actionLedger)) actionLedger = [];
let latestDiagnosis = null;
let importedDetails = null;
let importedSummary = null;
let importedAux = null;
let importedLineage = null;
let pendingImportMeta = null;
let importSessionRows = [];
let importSessionFileNames = [];
let importSessionSkippedFiles = [];
let queuedImportFiles = [];
let isImportingFiles = false;
let isGeneratingReport = false;
let formRecomputeTimer = null;
let actionEditTimer = null;

const $ = (selector) => document.querySelector(selector);

function readNumber(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function clamp(value, min = 0, max = 100) {
  return Math.max(min, Math.min(max, value));
}

function yuan(value) {
  return '¥ ' + Math.round(readNumber(value)).toLocaleString('zh-CN');
}

function percent(value, digits = 2) {
  return readNumber(value).toFixed(digits) + '%';
}

function loadJson(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
  } catch {
    return fallback;
  }
}

function limitArray(items, limit = 20) {
  return Array.isArray(items) ? items.slice(0, limit) : items;
}

function compactImportedDetails(details = {}) {
  if (!details || typeof details !== 'object') return details;
  return {
    ...details,
    products: limitArray(details.products, 12),
    productsAll: limitArray(details.productsAll, 30),
    categories: limitArray(details.categories, 16),
    daily: limitArray(details.daily, 40),
    refundReasons: limitArray(details.refundReasons, 12),
    live: limitArray(details.live, 16),
    content: limitArray(details.content, 16),
    service: limitArray(details.service, 16),
    traffic: limitArray(details.traffic, 20),
    promotion: limitArray(details.promotion, 24),
    activity: limitArray(details.activity, 16)
  };
}

function compactDataForHistory(data = {}) {
  const sourceNames = String(data.dataSource || '').split(' + ');
  return {
    ...data,
    dataSource: sourceNames.length > 6
      ? `${sourceNames.slice(0, 6).join(' + ')} 等${sourceNames.length}个文件`
      : data.dataSource,
    importedDetails: compactImportedDetails(data.importedDetails),
    importSummary: limitArray(data.importSummary, 80),
    importedLineage: limitArray(data.importedLineage, 36)
  };
}

function compactDiagnosisForHistory(diagnosis) {
  if (!diagnosis || typeof diagnosis !== 'object') return diagnosis;
  return {
    ...diagnosis,
    data: compactDataForHistory(diagnosis.data),
    issues: limitArray(diagnosis.issues, 12),
    actions: limitArray(diagnosis.actions, 6),
    metrics: limitArray(diagnosis.metrics, 12)
  };
}

function minimalDiagnosisForHistory(diagnosis) {
  return {
    id: diagnosis.id,
    createdAt: diagnosis.createdAt,
    totalScore: diagnosis.totalScore,
    summary: diagnosis.summary,
    issues: limitArray(diagnosis.issues, 6),
    actions: limitArray(diagnosis.actions, 3),
    metrics: limitArray(diagnosis.metrics, 8),
    data: {
      storeName: diagnosis.data?.storeName || '',
      brandName: diagnosis.data?.brandName || '',
      industry: diagnosis.data?.industry || '',
      platform: diagnosis.data?.platform || '',
      reportType: diagnosis.data?.reportType || '',
      reportPurpose: diagnosis.data?.reportPurpose || '',
      period: diagnosis.data?.period || '',
      periodStart: diagnosis.data?.periodStart || '',
      periodEnd: diagnosis.data?.periodEnd || '',
      sales: diagnosis.data?.sales || 0,
      prevSales: diagnosis.data?.prevSales || 0,
      visitors: diagnosis.data?.visitors || 0,
      prevVisitors: diagnosis.data?.prevVisitors || 0,
      conversion: diagnosis.data?.conversion || 0,
      aov: diagnosis.data?.aov || 0,
      refundRate: diagnosis.data?.refundRate || 0,
      roi: diagnosis.data?.roi || 0,
      productCount: diagnosis.data?.productCount || 0,
      activeProductCount: diagnosis.data?.activeProductCount || 0,
      topSkuShare: diagnosis.data?.topSkuShare || 0,
      serviceRate: diagnosis.data?.serviceRate || 0,
      searchShare: diagnosis.data?.searchShare || 0,
      recommendShare: diagnosis.data?.recommendShare || 0,
      contentShare: diagnosis.data?.contentShare || 0,
      paidShare: diagnosis.data?.paidShare || 0,
      privateShare: diagnosis.data?.privateShare || 0,
      importedDetails: compactImportedDetails(diagnosis.data?.importedDetails),
      importedAux: diagnosis.data?.importedAux || null,
      importSummary: limitArray(diagnosis.data?.importSummary, 30),
      importedLineage: limitArray(diagnosis.data?.importedLineage, 20),
      notes: diagnosis.data?.notes || ''
    }
  };
}

function saveHistory() {
  const attempts = [
    history.slice(0, 200).map(compactDiagnosisForHistory),
    history.slice(0, 80).map(compactDiagnosisForHistory),
    history.slice(0, 30).map(minimalDiagnosisForHistory),
    history.slice(0, 10).map(minimalDiagnosisForHistory)
  ];
  for (const payload of attempts) {
    try {
      localStorage.setItem(storageKey, JSON.stringify(payload));
      return true;
    } catch (error) {
      try {
        localStorage.removeItem(storageKey);
      } catch {}
    }
  }
  return false;
}

function saveActionLedger() {
  try {
    localStorage.setItem(actionStorageKey, JSON.stringify(actionLedger.slice(0, 600)));
    return true;
  } catch {
    return false;
  }
}

function actionStatusLabel(status) {
  return status === 'done' ? '已完成' : status === 'doing' ? '进行中' : '待开始';
}

function actionStatusClass(status) {
  return status === 'done' ? 'done' : status === 'doing' ? 'doing' : 'pending';
}

function normalizedStoreKey(data = {}) {
  return `${String(data.storeName || data.brandName || '').trim().toLowerCase()}|${String(data.platform || '').trim().toLowerCase()}`;
}

function normalizedPeriodKey(data = {}) {
  const range = [data.periodStart, data.periodEnd].filter(Boolean).join('~');
  return String(range || data.period || '').trim().toLowerCase();
}

function stableHash(value) {
  let hash = 2166136261;
  const text = String(value || '');
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function actionMatchesDiagnosis(entry, diagnosis) {
  return Boolean(entry && diagnosis?.data &&
    entry.storeKey === normalizedStoreKey(diagnosis.data) &&
    (entry.periodKey || String(entry.period || '').trim().toLowerCase()) === normalizedPeriodKey(diagnosis.data));
}

function dateValue(value) {
  const text = String(value || '').trim();
  const direct = Date.parse(text.replace(/\//g, '-'));
  if (Number.isFinite(direct)) return direct;
  const dates = text.match(/\d{4}[-/.]\d{1,2}[-/.]\d{1,2}/g) || [];
  if (!dates.length) return 0;
  const stamp = Date.parse(dates[dates.length - 1].replace(/[/.]/g, '-'));
  return Number.isFinite(stamp) ? stamp : 0;
}

function addDaysText(value, days) {
  const base = dateValue(value) || Date.now();
  const date = new Date(base + days * 86400000);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function actionEntriesForDiagnosis(diagnosis) {
  if (!diagnosis?.data) return [];
  const deadlines = [7, 14, 30];
  const storeKey = normalizedStoreKey(diagnosis.data);
  const periodKey = normalizedPeriodKey(diagnosis.data);
  return (diagnosis.issues || []).slice(0, 3).map((item, index) => {
    const id = `action-${stableHash(`${storeKey}|${periodKey}|${item.lever || '经营'}|${index + 1}`)}`;
    const saved = actionLedger.find((entry) => entry.id === id) || actionLedger.find((entry) =>
      entry.storeKey === storeKey &&
      (entry.periodKey || String(entry.period || '').trim().toLowerCase()) === periodKey &&
      entry.lever === (item.lever || '经营') &&
      (entry.position === index + 1 || String(entry.id || '').endsWith(`-${index + 1}`)));
    const base = {
      id,
      reportId: diagnosis.id,
      storeKey,
      periodKey,
      storeName: diagnosis.data.storeName || diagnosis.data.brandName || '待确认店铺',
      platform: diagnosis.data.platform || '',
      period: diagnosis.data.period || '',
      position: index + 1,
      lever: item.lever || '经营',
      title: item.title,
      task: item.action,
      evidence: item.evidence,
      validation: item.validation,
      owner: item.owner || '运营',
      dueDate: addDaysText(diagnosis.data.periodEnd, deadlines[index]),
      status: 'pending',
      createdAt: diagnosis.createdAt,
      completedAt: ''
    };
    if (!saved) return base;
    return {
      ...base,
      ...saved,
      id,
      reportId: diagnosis.id,
      storeKey,
      periodKey,
      storeName: base.storeName,
      platform: base.platform,
      period: base.period,
      lever: base.lever,
      title: base.title,
      task: base.task,
      evidence: base.evidence,
      validation: base.validation,
      dueDate: saved.dueDate || base.dueDate
    };
  });
}

function syncActionLedger(diagnosis) {
  const entries = actionEntriesForDiagnosis(diagnosis);
  const currentIds = new Set(entries.map((entry) => entry.id));
  actionLedger = actionLedger.filter((entry) => !actionMatchesDiagnosis(entry, diagnosis) || currentIds.has(entry.id));
  entries.forEach((entry) => {
    const saved = actionLedger.find((item) => item.id === entry.id) || actionLedger.find((item) =>
      item.storeKey === entry.storeKey &&
      (item.periodKey || String(item.period || '').trim().toLowerCase()) === entry.periodKey &&
      item.lever === entry.lever &&
      (item.position === entry.position || String(item.id || '').endsWith(`-${entry.position}`)));
    if (saved) Object.assign(saved, entry);
    else actionLedger.unshift(entry);
  });
  saveActionLedger();
  return entries;
}

function previousDiagnosisFor(diagnosis) {
  if (!diagnosis?.data) return null;
  const storeKey = normalizedStoreKey(diagnosis.data);
  if (!storeKey.split('|')[0]) return null;
  const currentPeriod = dateValue(diagnosis.data.periodEnd || diagnosis.data.periodStart || diagnosis.data.period);
  const candidates = history.filter((item) => item?.id !== diagnosis.id && normalizedStoreKey(item.data) === storeKey);
  const earlier = currentPeriod
    ? candidates.filter((item) => {
      const stamp = dateValue(item.data?.periodEnd || item.data?.periodStart || item.data?.period);
      return stamp && stamp < currentPeriod;
    })
    : candidates;
  const pool = currentPeriod ? earlier : candidates;
  return pool
    .sort((a, b) => dateValue(b.data?.periodEnd || b.data?.periodStart || b.data?.period) - dateValue(a.data?.periodEnd || a.data?.periodStart || a.data?.period))[0] || null;
}

function leverMetric(lever, data = {}) {
  const contentShare = readNumber(data.contentShare) + readNumber(data.recommendShare);
  if (/利润|退款/.test(lever)) return { label: '退款率', value: readNumber(data.refundRate), inverse: true, format: (value) => percent(value) };
  if (/转化/.test(lever)) return { label: '转化率', value: readNumber(data.conversion), format: (value) => percent(value) };
  if (/流量/.test(lever)) return { label: '访客数', value: readNumber(data.visitors), format: (value) => Math.round(value).toLocaleString('zh-CN') };
  if (/投放/.test(lever)) return { label: 'ROI', value: readNumber(data.roi), format: (value) => value ? value.toFixed(2) : '-' };
  if (/货品/.test(lever)) {
    const activeRate = readNumber(data.activeProductRate) || (readNumber(data.productCount) ? readNumber(data.activeProductCount) / readNumber(data.productCount) * 100 : 0);
    return { label: '动销率', value: activeRate, format: (value) => percent(value) };
  }
  if (/客服/.test(lever)) return { label: '客服承接率', value: readNumber(data.serviceRate), format: (value) => percent(value, 1) };
  if (/渠道/.test(lever)) return { label: '内容与推荐占比', value: contentShare, format: (value) => percent(value, 1) };
  return { label: '销售额', value: readNumber(data.sales), format: (value) => yuan(value) };
}

function reviewVerificationRows(diagnosis) {
  const previous = previousDiagnosisFor(diagnosis);
  if (!previous) return { previous: null, rows: [] };
  const savedActions = actionLedger
    .filter((entry) => actionMatchesDiagnosis(entry, previous))
    .sort((a, b) => readNumber(a.position) - readNumber(b.position));
  const fallbackActions = (previous.issues || []).slice(0, 3).map((item, index) => ({
    id: `${previous.id}-${index + 1}`,
    lever: item.lever || '经营',
    title: item.title,
    task: item.action,
    owner: item.owner || '运营',
    status: 'pending',
    validation: item.validation
  }));
  const actions = savedActions.length ? savedActions : fallbackActions;
  const rows = actions.slice(0, 3).map((entry) => {
    const currentMetric = leverMetric(entry.lever, diagnosis.data);
    const previousMetric = leverMetric(entry.lever, previous.data);
    const currentValue = currentMetric.value;
    const previousValue = previousMetric.value;
    const comparable = previousValue > 0 && Number.isFinite(currentValue);
    const rawChange = comparable ? (currentValue - previousValue) / previousValue * 100 : 0;
    const effectiveChange = currentMetric.inverse ? -rawChange : rawChange;
    const outcome = !comparable ? 'unknown' : effectiveChange > 2 ? 'improved' : effectiveChange < -2 ? 'worse' : 'flat';
    const conclusion = entry.status === 'done'
      ? outcome === 'improved' ? '动作完成后指标改善，建议保留并继续验证。' : outcome === 'worse' ? '动作已完成但指标尚未改善，需复核执行质量或原判断。' : outcome === 'flat' ? '动作已完成，指标暂未出现明显变化。' : '动作已完成，但缺少可比指标。'
      : entry.status === 'doing'
        ? '动作执行中，本期先观察指标变化，不提前归因。'
        : '尚未确认执行，指标变化不能归因于该动作。';
    return {
      ...entry,
      metric: currentMetric.label,
      previousValue: previousMetric.format(previousValue),
      currentValue: currentMetric.format(currentValue),
      change: comparable ? `${rawChange >= 0 ? '+' : ''}${rawChange.toFixed(1)}%` : '不可比',
      outcome,
      conclusion
    };
  });
  return { previous, rows };
}

function getBenchmark(industry) {
  return benchmarks[industry] || benchmarks.default;
}

function getCategoryStrategy(industry) {
  return categoryStrategies[industry] || categoryStrategies.default;
}

function getFormData() {
  const data = {};
  fieldIds.forEach((id) => {
    const element = $('#' + id);
    data[id] = element ? element.value : '';
  });
  if (!data.period && (data.periodStart || data.periodEnd)) {
    data.period = [data.periodStart, data.periodEnd].filter(Boolean).join(' 至 ');
  }
  data.platform = selectedPlatform;
  [
    'sales', 'prevSales', 'visitors', 'prevVisitors', 'conversion', 'aov', 'refundRate', 'roi',
    'productCount', 'activeProductCount', 'topSkuShare', 'serviceRate',
    'searchShare', 'recommendShare', 'contentShare', 'paidShare', 'privateShare'
  ].forEach((id) => {
    data[id] = readNumber(data[id]);
  });
  data.activeProductRate = data.productCount ? clamp((data.activeProductCount / data.productCount) * 100) : 0;
  data.orderCount = data.aov ? Math.round(data.sales / data.aov) : 0;
  data.channelTotal = data.searchShare + data.recommendShare + data.contentShare + data.paidShare + data.privateShare;
  data.importedDetails = importedDetails;
  data.importSummary = importedSummary;
  data.importedAux = importedAux;
  data.importedLineage = importedLineage;
  data.refundAmount = readNumber(importedAux?.refundAmount || 0);
  data.prevRefundAmount = readNumber(importedAux?.prevRefundAmount || 0);
  data.netSales = readNumber(importedAux?.netSales || Math.max(0, data.sales - data.refundAmount));
  data.prevNetSales = readNumber(importedAux?.prevNetSales || Math.max(0, data.prevSales - data.prevRefundAmount));
  data.oldBuyerSales = readNumber(importedAux?.oldBuyerSales || 0);
  return data;
}

function hasMeaningfulData(data) {
  const details = data?.importedDetails || {};
  const hasImportedRows = Object.values(details).some((items) => Array.isArray(items) && items.length > 0);
  return Boolean(
    hasImportedRows ||
    data?.sales > 0 ||
    data?.visitors > 0 ||
    data?.prevSales > 0 ||
    data?.refundAmount > 0 ||
    data?.productCount > 0
  );
}

function getReportName(diagnosis) {
  const type = diagnosis?.data?.reportType || '诊断';
  return `${type === '月报' ? '月经营复盘报告' : type === '周报' ? '周经营复盘报告' : `店铺经营${type}`}`;
}

function compactDateText(value) {
  const stamp = parseDateToken(value);
  if (stamp) return formatDateStamp(stamp).replace(/-/g, '');
  return String(value || '').replace(/[^\d]/g, '').slice(0, 8);
}

function exportFileBaseName(data) {
  const brandOrStore = data.brandName || data.storeName || '电商店铺';
  const typeName = data.reportType === '月报' ? '月经营复盘报告' : '周经营复盘报告';
  const purpose = /正式/.test(data.reportPurpose || '') ? '品沐咨询正式版' : '品沐咨询经营诊断版';
  const start = compactDateText(data.periodStart) || compactDateText(data.period?.split('至')?.[0]);
  const end = compactDateText(data.periodEnd) || compactDateText(data.period?.split('至')?.[1]);
  const range = start && end ? `_${start}-${end}` : '';
  return `${brandOrStore}_${data.platform || ''}_${typeName}_${purpose}${range}`.replace(/[\\/:*?"<>|]/g, '').replace(/_+/g, '_');
}

function setFormData(data) {
  importedDetails = data.importedDetails || null;
  importedSummary = data.importSummary || null;
  importedAux = data.importedAux || null;
  importedLineage = data.importedLineage || null;
  fieldIds.forEach((id) => {
    const element = $('#' + id);
    if (data[id] !== undefined && element) element.value = data[id];
  });
  selectedPlatform = data.platform || '天猫';
  document.querySelectorAll('#platformTabs button').forEach((button) => {
    button.classList.toggle('selected', button.dataset.platform === selectedPlatform);
  });
}

function trend(current, previous, inverse = false) {
  if (!previous) return { value: 0, label: '无对比', className: 'delta-flat' };
  const value = ((current - previous) / previous) * 100;
  const good = inverse ? value <= 0 : value >= 0;
  return {
    value,
    label: (value >= 0 ? '+' : '') + value.toFixed(2) + '%',
    className: Math.abs(value) < 0.01 ? 'delta-flat' : good ? 'delta-up' : 'delta-down'
  };
}

function scoreClass(score) {
  if (score >= 78) return 'good';
  if (score >= 60) return 'warn';
  return 'risk';
}

function scoreColor(score) {
  if (score >= 78) return 'var(--green)';
  if (score >= 60) return 'var(--amber)';
  return 'var(--red)';
}

function levelFromPriority(priority) {
  if (priority >= 82) return 'high';
  if (priority >= 58) return 'medium';
  return 'low';
}

function rankFromLevel(level) {
  return level === 'high' ? '高' : level === 'medium' ? '中' : '低';
}

function issue(issues, item) {
  const priority = Math.round(clamp(item.priority));
  const level = item.level || levelFromPriority(priority);
  issues.push({
    level,
    rank: rankFromLevel(level),
    priority,
    title: item.title,
    evidence: item.evidence,
    diagnosis: item.diagnosis,
    impactText: item.impactText,
    action: item.action,
    validation: item.validation,
    owner: item.owner || '运营',
    lever: item.lever || '经营'
  });
}

function gapDecomposition(data) {
  const prevVisitors = data.prevVisitors || data.visitors;
  const prevConversion = prevVisitors && data.prevSales && data.aov ? (data.prevSales / data.aov / prevVisitors) * 100 : data.conversion;
  const prevAov = data.prevSales && prevVisitors && prevConversion ? data.prevSales / (prevVisitors * prevConversion / 100) : data.aov;
  const trafficOnlySales = data.visitors * (prevConversion / 100) * prevAov;
  const conversionOnlySales = data.visitors * (data.conversion / 100) * prevAov;
  const salesGap = data.sales - data.prevSales;
  return {
    salesGap,
    trafficImpact: trafficOnlySales - data.prevSales,
    conversionImpact: conversionOnlySales - trafficOnlySales,
    aovImpact: data.sales - conversionOnlySales,
    prevConversion,
    prevAov
  };
}

function addImportedDetailIssues(data, issues, category, bench) {
  const details = data.importedDetails || {};
  const products = (details.productsAll?.length ? details.productsAll : details.products || [])
    .filter((item) => item && item.name && (item.sales || item.visitors || item.orders));
  if (products.length) {
    const medianVisitors = median(products.map((item) => item.visitors || 0));
    const medianSales = median(products.map((item) => item.sales || 0));
    const conversionBase = data.conversion || median(products.map((item) => item.conversion || 0)) || bench.conversion;
    const highVisitorLowConvert = products
      .filter((item) => (item.visitors || 0) >= Math.max(medianVisitors * 1.35, data.visitors * 0.02) && (item.conversion || 0) > 0 && (item.conversion || 0) <= Math.max(conversionBase * 0.75, 0.8))
      .sort((a, b) => (b.visitors || 0) - (a.visitors || 0));
    const lowTrafficHighConvert = products
      .filter((item) => (item.sales || 0) < Math.max(medianSales * 1.35, data.sales * 0.04) && (item.conversion || 0) >= Math.max(conversionBase * 1.15, 1) && (item.visitors || 0) <= Math.max(medianVisitors * 1.8, 1))
      .sort((a, b) => (b.conversion || 0) - (a.conversion || 0));
    const refundRiskProducts = products
      .filter((item) => (item.refundRate || 0) >= bench.refund * 1.2 || (item.refundAmount || 0) >= Math.max((item.sales || 0) * 0.06, 1))
      .sort((a, b) => (b.refundAmount || 0) - (a.refundAmount || 0));

    if (highVisitorLowConvert.length) {
      const top = highVisitorLowConvert[0];
      issue(issues, {
        title: '存在高访低转商品，当前流量没有被有效承接',
        evidence: `${top.name} 访客 ${Math.round(top.visitors || 0).toLocaleString('zh-CN')}，转化率 ${percent(top.conversion || 0)}，低于店铺/类目承接参考。`,
        diagnosis: '这类商品不是缺曝光，而是页面、价格理由、评价信任、规格选择或客服异议处理没有把流量接住。',
        impactText: `优先影响商品转化，当前成交 ${yuan(top.sales || 0)}`,
        action: '先针对高访低转 TOP3 商品做主图五连、详情首屏、价格锚点、评价证据和客服话术修复。',
        validation: '下周期按 SKU 对比访客、加购、咨询、成交和退款，转化率至少提升 0.2-0.5 个点再放量。',
        priority: 86,
        owner: '内容/运营',
        lever: 'SKU承接'
      });
    }

    if (refundRiskProducts.length) {
      const top = refundRiskProducts[0];
      issue(issues, {
        title: '部分商品售后风险偏高，继续放量会吞噬利润',
        evidence: `${top.name} 退款金额 ${yuan(top.refundAmount || 0)}，退款率 ${percent(top.refundRate || 0)}。`,
        diagnosis: category.refund,
        impactText: `商品退款风险 ${yuan(top.refundAmount || 0)}`,
        action: '先暂停对高退款商品的新增放量，拆退款原因后回写页面承诺、规格说明和客服确认话术。',
        validation: '核查该 SKU 近30天退款原因、差评关键词、客服聊天记录和发货批次。',
        priority: 84,
        owner: '售后/商品',
        lever: '利润'
      });
    }

    if (lowTrafficHighConvert.length) {
      const top = lowTrafficHighConvert[0];
      issue(issues, {
        title: '存在低访高转潜力款，值得小预算验证放量',
        evidence: `${top.name} 转化率 ${percent(top.conversion || 0)}，但访客 ${Math.round(top.visitors || 0).toLocaleString('zh-CN')} 未进入头部。`,
        diagnosis: '这类商品已经证明有承接能力，下一步不是大改页面，而是用小预算和内容素材验证可放量边界。',
        impactText: '潜在新增成交来源',
        action: '给潜力款配置小额搜索词、人群和内容曝光测试，观察加购、收藏、成交和退款是否同步健康。',
        validation: '连续 7 天跟踪曝光、点击率、转化率、ROI、退款率，达标后进入第二梯队主推。',
        priority: 66,
        owner: '运营/投放',
        lever: '货品'
      });
    }
  }

  const refundReasons = details.refundReasons || [];
  if (refundReasons.length) {
    const topReason = refundReasons[0];
    issue(issues, {
      title: '退款原因已经可定位，应进入原因矩阵治理',
      evidence: `${topReason.reason || '未标明原因'} 退款金额 ${topReason.refundAmount ? yuan(topReason.refundAmount) : '待补充'}，关联商品 ${topReason.topProduct || '待补充'}。`,
      diagnosis: '平台自带报告通常停留在退款率，本报告需要把原因、商品、页面承诺、客服话术和履约动作连起来。',
      impactText: topReason.refundAmount ? `已识别退款金额 ${yuan(topReason.refundAmount)}` : '影响利润与复购信任',
      action: '按退款原因 TOP3 建立治理表：原因、SKU、页面问题、客服话术、履约责任、完成时间。',
      validation: '下周期比较同原因退款金额和退款笔数是否下降，并复核差评关键词是否减少。',
      priority: 82,
      owner: '售后/商品',
      lever: '利润'
    });
  }
}

function analyze(data) {
  const bench = getBenchmark(data.industry);
  const category = getCategoryStrategy(data.industry);
  const salesTrend = trend(data.sales, data.prevSales);
  const visitorTrend = trend(data.visitors, data.prevVisitors);
  const decomposition = gapDecomposition(data);
  const channelBalance = Math.abs(100 - data.channelTotal) <= 5 ? 100 : clamp(100 - Math.abs(100 - data.channelTotal) * 3);
  const contentBase = data.contentShare + data.recommendShare;
  const paidPressure = data.paidShare >= 28;
  const categoryBoost = (lever) => category.priorityBoost?.[lever] || 0;
  const opportunity = {
    conversion: Math.max(0, data.visitors * ((bench.conversion - data.conversion) / 100) * data.aov),
    refund: Math.max(0, data.sales * ((data.refundRate - bench.refund) / 100)),
    active: Math.max(0, data.sales * ((bench.activeRate - data.activeProductRate) / 100) * 0.35),
    service: Math.max(0, data.sales * ((bench.service - data.serviceRate) / 100) * 0.18),
    private: Math.max(0, data.sales * ((bench.privateShare - data.privateShare) / 100) * 0.22)
  };
  const refundScore = clamp(100 - Math.max(0, data.refundRate - bench.refund) * 9);
  const roiScore = data.roi > 0 ? clamp((data.roi / bench.roi) * 100) : null;
  const profitScore = roiScore === null ? refundScore : refundScore * 0.58 + roiScore * 0.42;

  const metricScores = [
    { key: 'sales', name: '销售增长', value: yuan(data.sales), detail: salesTrend.label, score: clamp(70 + salesTrend.value * 1.35) },
    { key: 'traffic', name: '流量质量', value: Math.round(data.visitors).toLocaleString('zh-CN'), detail: visitorTrend.label, score: clamp(70 + visitorTrend.value * 1.2) },
    { key: 'conversion', name: '转化效率', value: percent(data.conversion), detail: `${data.industry}参考 ${bench.conversion}%`, score: clamp((data.conversion / bench.conversion) * 100) },
    { key: 'profit', name: '利润风险', value: '退款 ' + percent(data.refundRate), detail: data.roi > 0 ? `ROI ${data.roi.toFixed(2)}` : 'ROI 未提供', score: clamp(profitScore) },
    { key: 'product', name: '货品动销', value: percent(data.activeProductRate), detail: `TOP SKU ${percent(data.topSkuShare, 1)}`, score: clamp((data.activeProductRate / bench.activeRate) * 74 + (100 - Math.max(0, data.topSkuShare - bench.topSkuMax) * 2) * 0.26) },
    { key: 'channel', name: '渠道结构', value: data.channelTotal.toFixed(1) + '%', detail: contentBase >= 35 ? '内容基础较好' : '内容基础偏弱', score: clamp(channelBalance * 0.52 + (paidPressure ? 48 : 78) * 0.2 + clamp(contentBase * 1.45) * 0.28) },
    { key: 'service', name: '客服承接', value: percent(data.serviceRate, 1), detail: `参考 ${bench.service}%`, score: clamp((data.serviceRate / bench.service) * 100) }
  ].map((item) => ({ ...item, score: Math.round(item.score) }));

  const issues = [];
  if (decomposition.salesGap < 0) {
    const biggest = [
      ['流量', decomposition.trafficImpact],
      ['转化', decomposition.conversionImpact],
      ['客单', decomposition.aovImpact]
    ].sort((a, b) => a[1] - b[1])[0];
    issue(issues, {
      title: 'GMV 下滑需要先做杠杆拆解，不应直接归因到流量',
      evidence: `本期销售较对比周期少 ${yuan(Math.abs(decomposition.salesGap))}；测算中${biggest[0]}项对缺口贡献最大。`,
      diagnosis: '平台后台通常只提示销售下降，但顾问诊断要先拆 GMV = 访客 × 转化率 × 客单价，避免把预算投到错误环节。',
      impactText: `短期缺口 ${yuan(Math.abs(decomposition.salesGap))}`,
      action: '先按渠道和 SKU 拆访客、转化率、客单价，再决定是补流量、改页面还是调商品结构。',
      validation: '导出近30天渠道/SKU明细，计算每个渠道的访客变化、成交变化和客单变化。',
      priority: 92,
      owner: '运营',
      lever: 'GMV'
    });
  }
  if (visitorTrend.value < -8 && decomposition.trafficImpact < -data.sales * 0.04) {
    issue(issues, {
      title: '流量入口衰退，需要判断是自然流量掉线还是付费缩量',
      evidence: `访客环比 ${visitorTrend.label}，按上期转化和客单测算，流量因素约影响 ${yuan(Math.abs(decomposition.trafficImpact))}。`,
      diagnosis: '如果自然搜索和推荐同时下降，说明商品权重或内容效率在掉；如果只因付费缩量，不能简单用加预算解决。',
      impactText: `流量缺口约 ${yuan(Math.abs(decomposition.trafficImpact))}`,
      action: '分搜索、推荐、活动、内容、付费五类入口做流量差异表，先找最大下滑入口。',
      validation: '看搜索词排名、推荐曝光、内容点击率、活动入口和付费消耗是否同步变化。',
      priority: 88,
      owner: '运营/投放',
      lever: '流量'
    });
  }
  if (data.conversion < bench.conversion) {
    const gap = bench.conversion - data.conversion;
    issue(issues, {
      title: '转化率低于行业参考线，页面和客服承接是优先修复项',
      evidence: `当前转化率 ${percent(data.conversion)}，低于${data.industry}参考线 ${bench.conversion}%；按当前流量和客单，转化提升到参考线约增加 ${yuan(opportunity.conversion)}。`,
      diagnosis: category.conversion,
      impactText: `转化机会约 ${yuan(opportunity.conversion)}`,
      action: category.action,
      validation: `对比核心 SKU 的点击-加购-咨询-成交链路，并按${data.industry}重点校验：${category.conversion}`,
      priority: clamp(74 + gap * 10 + opportunity.conversion / Math.max(data.sales, 1) * 20 + categoryBoost('转化')),
      owner: '内容/客服',
      lever: '转化'
    });
  }
  if (data.refundRate > bench.refund) {
    issue(issues, {
      title: '退款率高于健康线，正在吞噬真实增长',
      evidence: `当前退款率 ${percent(data.refundRate)}，高于参考线 ${bench.refund}%；按销售额估算，超额退款风险约 ${yuan(opportunity.refund)}。`,
      diagnosis: category.refund,
      impactText: `利润风险约 ${yuan(opportunity.refund)}`,
      action: '建立退款原因矩阵：SKU × 原因 × 页面表达 × 客服话术 × 履约/供应链问题，先处理 TOP3 原因。',
      validation: `拉取近30天退款原因和评价负反馈，按 SKU 聚合，并按${data.industry}重点校验：${category.refund}`,
      priority: clamp(68 + (data.refundRate - bench.refund) * 6 + opportunity.refund / Math.max(data.sales, 1) * 24 + categoryBoost('利润')),
      owner: '售后/商品',
      lever: '利润'
    });
  }
  if (data.roi > 0 && data.roi < bench.roi) {
    issue(issues, {
      title: '投放 ROI 低于参考线，预算可能在放大低效承接',
      evidence: `当前 ROI ${data.roi.toFixed(2)}，低于参考线 ${bench.roi.toFixed(2)}；付费占比 ${percent(data.paidShare, 1)}。`,
      diagnosis: 'ROI 低不一定是投手问题，要同时检查人群、素材、关键词、落地 SKU 和页面转化。若转化也低，优先修承接再放预算。',
      impactText: '影响投放放量确定性',
      action: '把计划按 ROI、点击率、转化率、成交 SKU 分层，暂停低效消耗，保留能成交的人群和词包。',
      validation: '输出计划级报表：消耗、点击率、加购率、转化率、成交金额、退款率。',
      priority: clamp(62 + (bench.roi - data.roi) * 13 + (paidPressure ? 10 : 0)),
      owner: '投放',
      lever: '投放'
    });
  }
  if (data.activeProductRate < bench.activeRate) {
    issue(issues, {
      title: '货品动销不足，SKU 多但有效供给不够',
      evidence: `当前动销率 ${percent(data.activeProductRate)}，参考线 ${bench.activeRate}%；有成交商品 ${data.activeProductCount}/${data.productCount}。`,
      diagnosis: category.product,
      impactText: `动销改善机会约 ${yuan(opportunity.active)}`,
      action: '按销售额、访客、转化、毛利、退款率给 SKU 打标签，确定未来两周只优化核心 10-20 个 SKU。',
      validation: `导出 SKU 明细，按访客高低和转化高低做四象限，并补充${data.industry}商品分层字段。`,
      priority: clamp(55 + (bench.activeRate - data.activeProductRate) * 1.1 + opportunity.active / Math.max(data.sales, 1) * 20 + categoryBoost('货品')),
      owner: '商品',
      lever: '货品'
    });
  }
  if (data.topSkuShare > bench.topSkuMax) {
    issue(issues, {
      title: '销售过度依赖单一或少数 SKU，增长稳定性不足',
      evidence: `TOP SKU 销售占比 ${percent(data.topSkuShare, 1)}，高于参考上限 ${bench.topSkuMax}%。`,
      diagnosis: '爆款集中不是坏事，但如果第二梯队没有接力，活动、库存、差评或退款都会直接冲击整店 GMV。',
      impactText: '影响活动稳定性和库存安全',
      action: '围绕爆款建立关联款、组合款和利润款，把详情页、客服和内容入口导向第二梯队商品。',
      validation: '查看 TOP5 SKU 的库存、退款、评价、流量来源和关联购买数据。',
      priority: clamp(54 + (data.topSkuShare - bench.topSkuMax) * 1.4),
      owner: '商品/内容',
      lever: '货品'
    });
  }
  if (paidPressure && data.roi > 0 && data.roi < bench.roi) {
    issue(issues, {
      title: '付费依赖偏高且效率不足，容易形成“花钱有单、停投下滑”',
      evidence: `付费渠道占比 ${percent(data.paidShare, 1)}，ROI ${data.roi.toFixed(2)}，内容+推荐占比 ${percent(contentBase, 1)}。`,
      diagnosis: category.channel,
      impactText: '影响获客成本和利润稳定性',
      action: '降低低效付费消耗，把预算转向能沉淀搜索词、内容素材和复购人群的商品。',
      validation: `比较付费访客与自然访客的转化率、客单价、退款率和复购率，并按${data.industry}看渠道承接差异。`,
      priority: clamp(70 + categoryBoost('渠道')),
      owner: '投放/内容',
      lever: '渠道'
    });
  }
  if (data.serviceRate < bench.service) {
    issue(issues, {
      title: '客服承接未达标，咨询流量可能没有被充分转化',
      evidence: `客服响应达标率 ${percent(data.serviceRate, 1)}，参考线 ${bench.service}%；按销售额估算，承接改善机会约 ${yuan(opportunity.service)}。`,
      diagnosis: '客服不是成本岗位，而是转化节点。响应慢、异议处理不统一、售后安抚不足，会同时影响成交和退款。',
      impactText: `承接机会约 ${yuan(opportunity.service)}`,
      action: '沉淀高频咨询、异议处理、退货挽留、尺码/功效解释话术，并设置每日抽检。',
      validation: '抽取咨询未成交样本，标注用户问题、客服回复、是否催单、是否流失。',
      priority: clamp(56 + (bench.service - data.serviceRate) * 1.4 + categoryBoost('承接')),
      owner: '客服',
      lever: '承接'
    });
  }
  if (data.privateShare < bench.privateShare) {
    issue(issues, {
      title: '私域和老客贡献偏弱，复购资产没有被经营起来',
      evidence: `私域占比 ${percent(data.privateShare, 1)}，参考线 ${bench.privateShare}%；按当前销售估算，复购提升机会约 ${yuan(opportunity.private)}。`,
      diagnosis: `${category.channel} 私域占比低时，还要补看老客复购、沉默激活和会员权益是否形成经营机制。`,
      impactText: `复购机会约 ${yuan(opportunity.private)}`,
      action: '先选择高复购商品设计 7/14/30 天触达 SOP，再扩展会员权益和沉默客户激活。',
      validation: `补充新客/老客成交占比、复购周期、会员人数和沉默客户数量，并按${data.industry}拆复购场景。`,
      priority: clamp(46 + (bench.privateShare - data.privateShare) * 2.5 + categoryBoost('复购')),
      owner: '私域',
      lever: '复购'
    });
  }
  if (Math.abs(100 - data.channelTotal) > 5) {
    issue(issues, {
      title: '渠道占比合计异常，诊断数据口径需要先校准',
      evidence: `当前渠道占比合计 ${percent(data.channelTotal, 1)}，与 100% 偏差超过 5 个点。`,
      diagnosis: '数据口径不准会让后续判断失真。顾问交付前必须先统一渠道归因口径。',
      impactText: '影响诊断可信度',
      action: '统一渠道分类口径，明确搜索、推荐、内容、付费、私域是否互斥。',
      validation: '重新导出平台后台渠道来源表，核对是否存在重复归因或漏填。',
      priority: 52,
      owner: '数据',
      lever: '数据'
    });
  }
  addImportedDetailIssues(data, issues, category, bench);
  if (!issues.length) {
    issue(issues, {
      title: '核心经营指标暂无明显短板，建议进入二级增长诊断',
      evidence: '销售、转化、退款、动销、ROI 和客服承接均未触发高风险阈值。',
      diagnosis: `当前不应继续做基础经营诊断，而应进入${data.industry}的二级增长诊断：${category.focus}`,
      impactText: '下一阶段增长空间',
      action: category.action,
      validation: `补充用户评价、竞品页面、内容素材和复购数据，按${data.industry}诊断方向复核。`,
      priority: 35,
      owner: '顾问',
      lever: '增长'
    });
  }

  issues.sort((a, b) => b.priority - a.priority);

  const totalScore = Math.round(metricScores.reduce((sum, item) => sum + item.score, 0) / metricScores.length);
  const summary = createSummary(totalScore, issues, salesTrend, visitorTrend, decomposition, category);
  const actions = createActions(issues, data, category);
  const targetPlan = buildTargetPlan(data, issues, decomposition, bench);
  const now = new Date();

  return {
    id: String(now.getTime()),
    createdAt: now.toLocaleString('zh-CN', { hour12: false }),
    data,
    metrics: metricScores,
    issues,
    actions,
    targetPlan,
    categoryStrategy: category,
    weeklySections: buildWeeklySections(data, issues),
    dataQuality: buildDataQuality(data),
    salesTrend,
    visitorTrend,
    decomposition,
    totalScore,
    summary
  };
}

function createSummary(score, issues, salesTrend, visitorTrend, decomposition, category) {
  const highCount = issues.filter((item) => item.level === 'high').length;
  if (score >= 80 && highCount === 0) {
    return {
      title: '经营状态健康，适合进入二级增长诊断',
      text: `基础经营指标较稳定，下一步应围绕类目方向寻找增量：${category.focus}`
    };
  }
  if (score >= 65) {
    return {
      title: '存在明确优化空间，需要按经营杠杆排序',
      text: `销售变化 ${salesTrend.label}，访客变化 ${visitorTrend.label}。本次诊断优先处理 ${issues[0]?.lever || '经营'} 问题；类目方向为：${category.focus}`
    };
  }
  if (decomposition.salesGap >= 0) {
    return {
      title: '销售增长但结构风险明显，需要先修复经营短板',
      text: `销售变化 ${salesTrend.label}，访客变化 ${visitorTrend.label}，但退款、转化、动销或渠道结构存在高优先级问题。建议先处理 ${issues[0]?.lever || '经营'}，并按类目重点复核：${category.focus}`
    };
  }
  return {
    title: '经营压力明显，需要先止损再增长',
    text: `销售缺口约 ${yuan(Math.abs(Math.min(0, decomposition.salesGap)))}，存在多个高优先级问题。建议先完成数据归因和承接修复，再按类目方向放大：${category.focus}`
  };
}

function createActions(issues, data, category = getCategoryStrategy(data.industry)) {
  const topIssues = issues.slice(0, 3);
  return [
    {
      period: '7天',
      title: '诊断校准与止损',
      tasks: [
        topIssues[0]?.validation || '校准销售、流量、转化、退款和渠道数据口径。',
        topIssues[0]?.action || '围绕最大影响项建立问题清单。',
        '输出一张“问题-证据-影响金额-责任人”表，避免只凭感觉开会。'
      ]
    },
    {
      period: '14天',
      title: '核心链路修复',
      tasks: [
        topIssues[1]?.action || '修复主图、详情页、评价、客服和投放承接链路。',
        '选择 3-5 个核心 SKU 做前后对照，跟踪访客、加购、咨询、成交、退款。',
        data.refundRate > 5 ? `把退款 TOP3 原因写入页面提醒和客服话术：${category.refund}` : `建立${data.industry}高频问答和异议处理模板。`
      ]
    },
    {
      period: '30天',
      title: '复盘与增长机制',
      tasks: [
        topIssues[2]?.action || '建立每周经营复盘机制。',
        `固定周报指标：销售、访客、转化、客单、退款、ROI、动销、客服承接，并加上${data.industry}专属复盘项。`,
        '把本次诊断沉淀为行业模板，下一步扩展到商品卖点和内容生产诊断。'
      ]
    }
  ];
}

function buildTargetPlan(data, issues, decomposition, bench) {
  const isMonth = data.reportType === '月报';
  const periodName = isMonth ? '下月' : '下周';
  const topIssue = issues[0];
  const salesGap = Math.abs(Math.min(0, decomposition.salesGap || 0));
  const recoveryMode = salesGap > 0 && data.prevSales > data.sales;
  const baseVisitors = Math.max(data.visitors || 0, 1);
  const baseConversion = Math.max(data.conversion || 0, 0.1);
  const baseAov = Math.max(data.aov || 0, 1);
  const formulaBaseline = baseVisitors * baseConversion / 100 * baseAov;
  const formulaRatio = data.sales > 0 ? formulaBaseline / data.sales : 1;
  const formulaReliable = formulaRatio >= 0.75 && formulaRatio <= 1.25;
  const settings = isMonth
    ? [
      { level: '保守', visitorLift: 3, conversionLift: 0.12, aovLift: 1.0, recover: 0.25, maxGrowth: 6 },
      { level: '建议', visitorLift: 6, conversionLift: 0.28, aovLift: 2.0, recover: 0.50, maxGrowth: 12 },
      { level: '冲刺', visitorLift: 10, conversionLift: 0.45, aovLift: 3.0, recover: 0.75, maxGrowth: 20 }
    ]
    : [
      { level: '保守', visitorLift: 2, conversionLift: 0.08, aovLift: 0.5, recover: 0.20, maxGrowth: 4 },
      { level: '建议', visitorLift: 4, conversionLift: 0.18, aovLift: 1.0, recover: 0.40, maxGrowth: 8 },
      { level: '冲刺', visitorLift: 7, conversionLift: 0.30, aovLift: 1.8, recover: 0.60, maxGrowth: 14 }
    ];

  const rows = settings.map((item) => {
    const visitors = Math.round(baseVisitors * (1 + item.visitorLift / 100));
    const conversion = Math.min(bench.conversion * 1.18, baseConversion + item.conversionLift);
    const aov = baseAov * (1 + item.aovLift / 100);
    const formulaSales = visitors * conversion / 100 * aov;
    const directionalSales = recoveryMode
      ? data.sales + salesGap * item.recover
      : data.sales * (1 + item.maxGrowth / 200);
    const candidateSales = formulaReliable ? Math.max(formulaSales, directionalSales) : directionalSales;
    const cappedSales = data.sales > 0
      ? Math.min(Math.max(candidateSales, data.sales * 1.01), data.sales * (1 + item.maxGrowth / 100))
      : formulaSales;
    const sales = Math.round(cappedSales);
    return {
      level: item.level,
      sales,
      visitors,
      conversion,
      aov,
      growth: data.sales ? (sales - data.sales) / data.sales * 100 : 0
    };
  });

  return {
    periodName,
    baseline: `当前基准：销售额 ${yuan(data.sales)}，访客 ${Math.round(data.visitors).toLocaleString('zh-CN')}，转化率 ${percent(data.conversion)}，客单价 ${yuan(data.aov)}。`,
    basis: formulaReliable
      ? '目标同时参考销售缺口、访客、转化率和客单价，建议在执行中按实际数据滚动校准。'
      : '支付金额与“访客 × 转化率 × 客单价”的测算结果存在较大口径差异，本次目标销售额按历史缺口回收测算，访客、转化率和客单价仅作为方向指标。',
    focus: topIssue ? `优先杠杆：${topIssue.lever}。${topIssue.action}` : '优先杠杆：商品、内容和复购路径的二级增长诊断。',
    rows
  };
}

function renderSummary(diagnosis) {
  const score = diagnosis.totalScore;
  $('#totalScore').textContent = score;
  $('#scoreRing').style.setProperty('--score-deg', `${score * 3.6}deg`);
  $('#scoreRing').style.setProperty('--score-color', scoreColor(score));
  $('#summaryTitle').textContent = diagnosis.summary.title;
  $('#summaryText').textContent = diagnosis.summary.text;
  $('#summaryKpis').innerHTML = [
    ['订单数', diagnosis.data.orderCount.toLocaleString('zh-CN')],
    ['销售变化', diagnosis.salesTrend.label],
    ['访客变化', diagnosis.visitorTrend.label],
    ['TOP问题', diagnosis.issues[0]?.lever || '经营']
  ].map(([label, value]) => `<div><span>${label}</span><strong>${value}</strong></div>`).join('');
}

function renderHealth(diagnosis) {
  $('#healthGrid').innerHTML = diagnosis.metrics.map((item) => `
    <article class="health-card ${scoreClass(item.score)}">
      <span>${item.name}</span>
      <strong>${item.value}</strong>
      <em>${item.detail}</em>
      <div class="score-line">
        <b>${item.score}</b>
        <span class="score-track"><i style="--score:${item.score}%;--score-color:${scoreColor(item.score)}"></i></span>
      </div>
    </article>
  `).join('');
}

function renderIssues(diagnosis) {
  const visibleIssues = diagnosis.issues.slice(0, 3);
  $('#issueCount').textContent = `聚焦 ${visibleIssues.length} 个关键异常${diagnosis.issues.length > visibleIssues.length ? `，其余 ${diagnosis.issues.length - visibleIssues.length} 项收入正式报告` : ''}`;
  $('#issueList').innerHTML = visibleIssues.map((item, index) => `
    <article class="issue-item issue-item-rich">
      <span class="issue-rank ${item.level}">${item.rank}</span>
      <div class="issue-copy">
        <strong>${index + 1}. ${item.title}</strong>
        <span class="issue-meta">${item.lever} · 优先级 ${item.priority} · ${item.owner}</span>
        <p><b>证据</b>${item.evidence}</p>
        <p><b>判断</b>${item.diagnosis}</p>
        <p><b>动作</b>${item.action}</p>
      </div>
      <small>${item.impactText}</small>
    </article>
  `).join('');
}

function renderActions(diagnosis) {
  const entries = actionEntriesForDiagnosis(diagnosis);
  const done = entries.filter((entry) => entry.status === 'done').length;
  const doing = entries.filter((entry) => entry.status === 'doing').length;
  const summary = $('#actionLedgerSummary');
  if (summary) summary.textContent = entries.length ? `${done} 项完成 · ${doing} 项进行中 · ${entries.length - done - doing} 项待开始` : '生成报告后自动建立关键动作';
  $('#actionList').innerHTML = entries.map((entry, index) => `
    <article class="ledger-card ${actionStatusClass(entry.status)}">
      <div class="ledger-rank">${index + 1}</div>
      <div class="ledger-copy">
        <header>
          <strong>${escapeHtml(entry.title)}</strong>
          <span>${escapeHtml(entry.lever)}</span>
        </header>
        <p>${escapeHtml(entry.task)}</p>
        <small><b>验收</b>${escapeHtml(entry.validation)}</small>
        <footer>
          <label>
            <span>责任人</span>
            <input type="text" value="${escapeHtml(entry.owner)}" data-action-owner="${entry.id}" aria-label="编辑第 ${index + 1} 项行动责任人" />
          </label>
          <label>
            <span>截止日期</span>
            <input type="date" value="${escapeHtml(entry.dueDate)}" data-action-due="${entry.id}" aria-label="编辑第 ${index + 1} 项行动截止日期" />
          </label>
        </footer>
      </div>
      <label class="ledger-status ${actionStatusClass(entry.status)}">
        <span>执行状态</span>
        <select data-action-status="${entry.id}" aria-label="更新第 ${index + 1} 项行动状态">
          <option value="pending" ${entry.status === 'pending' ? 'selected' : ''}>待开始</option>
          <option value="doing" ${entry.status === 'doing' ? 'selected' : ''}>进行中</option>
          <option value="done" ${entry.status === 'done' ? 'selected' : ''}>已完成</option>
        </select>
      </label>
    </article>
  `).join('');
}

function renderReviewVerification(diagnosis) {
  const container = $('#reviewGrid');
  const summary = $('#reviewSummary');
  if (!container || !summary) return;
  const verification = reviewVerificationRows(diagnosis);
  if (!verification.previous) {
    summary.textContent = '暂无同店铺上一周期报告';
    container.innerHTML = `
      <div class="review-empty">
        <strong>下一周期自动验证本次动作</strong>
        <p>完成本期行动状态更新后，下次导入同店铺报表，系统会自动比较对应指标，并区分“已执行有效、已执行未改善、未确认执行”。</p>
      </div>`;
    return;
  }
  const improved = verification.rows.filter((row) => row.outcome === 'improved' && row.status === 'done').length;
  summary.textContent = `对比 ${verification.previous.data?.period || verification.previous.createdAt || '上一周期'} · ${improved} 项已验证改善`;
  container.innerHTML = verification.rows.map((row, index) => `
    <article class="review-card ${row.status === 'done' ? row.outcome : 'unverified'}">
      <header>
        <span>${index + 1}</span>
        <strong>${escapeHtml(row.title)}</strong>
        <em class="status-${actionStatusClass(row.status)}">${actionStatusLabel(row.status)}</em>
      </header>
      <div class="review-metric">
        <span>${escapeHtml(row.metric)}</span>
        <b>${escapeHtml(row.previousValue)}</b>
        <i>→</i>
        <b>${escapeHtml(row.currentValue)}</b>
        <strong>${escapeHtml(row.change)}</strong>
      </div>
      <p>${escapeHtml(row.conclusion)}</p>
    </article>
  `).join('');
}

function actionLedgerReportHtml(diagnosis) {
  const entries = actionEntriesForDiagnosis(diagnosis);
  return `
    <table class="report-table">
      <thead><tr><th>优先动作</th><th>责任人</th><th>截止时间</th><th>状态</th><th>验收标准</th></tr></thead>
      <tbody>
        ${entries.map((entry) => `<tr><td>${escapeHtml(entry.task)}</td><td>${escapeHtml(entry.owner)}</td><td>${escapeHtml(entry.dueDate)}</td><td>${actionStatusLabel(entry.status)}</td><td>${escapeHtml(entry.validation)}</td></tr>`).join('')}
      </tbody>
    </table>`;
}

function reviewVerificationReportHtml(diagnosis) {
  const verification = reviewVerificationRows(diagnosis);
  if (!verification.previous) return '<p class="report-note">暂无同店铺上一周期报告。本期行动状态完成后，下一周期将自动验证对应指标。</p>';
  return `
    <p class="report-note">对比周期：${escapeHtml(verification.previous.data?.period || verification.previous.createdAt || '上一周期')}。仅在动作标记为已完成时，系统才会进一步判断动作后指标是否改善。</p>
    <table class="report-table">
      <thead><tr><th>上一期动作</th><th>状态</th><th>验证指标</th><th>上期</th><th>本期</th><th>变化</th><th>结论</th></tr></thead>
      <tbody>
        ${verification.rows.map((row) => `<tr><td>${escapeHtml(row.task)}</td><td>${actionStatusLabel(row.status)}</td><td>${escapeHtml(row.metric)}</td><td>${escapeHtml(row.previousValue)}</td><td>${escapeHtml(row.currentValue)}</td><td>${escapeHtml(row.change)}</td><td>${escapeHtml(row.conclusion)}</td></tr>`).join('')}
      </tbody>
    </table>`;
}

function setReportActionsEnabled(enabled) {
  ['copyExecutive', 'copyWechat', 'copyReport', 'exportWord', 'exportReport', 'printReport'].forEach((id) => {
    const button = $('#' + id);
    if (button) button.disabled = !enabled;
  });
}

function setManualFieldsVisible(visible, focus = false) {
  const fields = $('#manualFields');
  if (!fields) return;
  fields.hidden = !visible;
  const toggle = $('#toggleManualFieldsTop');
  if (toggle) toggle.textContent = visible ? '收起手动录入' : '手动录入';
  if (visible && focus) {
    fields.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => $('#storeName')?.focus(), 260);
  }
}

function renderEmptyWorkspace() {
  latestDiagnosis = null;
  $('#totalScore').textContent = '--';
  $('#scoreRing').style.setProperty('--score-deg', '0deg');
  $('#scoreRing').style.setProperty('--score-color', 'var(--blue)');
  $('#summaryTitle').textContent = '上传报表，生成第一份经营周报';
  $('#summaryText').textContent = '系统会自动识别经营概览、商品、流量、退款和推广等模块；缺失数据会明确标记，不会默认按 0 判断。';
  $('#summaryKpis').innerHTML = [
    ['第一步', '选择报表'],
    ['第二步', '确认识别'],
    ['第三步', '核实报告'],
    ['交付', '导出 Word']
  ].map(([label, value]) => `<div><span>${label}</span><strong>${value}</strong></div>`).join('');
  $('#healthGrid').innerHTML = `
    <div class="empty-readiness">
      <article><b>核心</b><strong>经营概览</strong><span>支付金额、访客、转化、客单</span></article>
      <article><b>核心</b><strong>商品明细</strong><span>TOP商品、动销、退款风险</span></article>
      <article><b>核心</b><strong>流量来源</strong><span>搜索、推荐、内容、付费</span></article>
      <article><b>增强</b><strong>退款与推广</strong><span>净销售额、计划ROI、控质建议</span></article>
    </div>`;
  $('#issueCount').textContent = '上传后自动按影响度排序';
  $('#issueList').innerHTML = `
    <div class="empty-step-list">
      <div><b>1</b><span>先识别增长来自流量、转化、客单还是老客回访。</span></div>
      <div><b>2</b><span>再定位高贡献商品、高退款商品和高花费低成交计划。</span></div>
      <div><b>3</b><span>最后落到商品、页面、客服、推广、直播和老客动作。</span></div>
    </div>`;
  $('#actionList').innerHTML = `
    <div class="empty-step-list">
      <div><b>7</b><span>7天：校准口径并处理最高优先级问题。</span></div>
      <div><b>14</b><span>14天：修复核心商品和成交承接链路。</span></div>
      <div><b>30</b><span>30天：复盘指标变化并沉淀增长机制。</span></div>
    </div>`;
  if ($('#actionLedgerSummary')) $('#actionLedgerSummary').textContent = '生成报告后自动建立关键动作';
  if ($('#reviewSummary')) $('#reviewSummary').textContent = '暂无同店铺上一周期报告';
  if ($('#reviewGrid')) $('#reviewGrid').innerHTML = `
    <div class="review-empty">
      <strong>完成两期经营复盘后自动验证</strong>
      <p>系统会把上一期动作、执行状态和本期指标放在一起判断，避免每期只生成一份新报告。</p>
    </div>`;
  $('#reportTime').textContent = '尚未生成报告';
  $('#reportPaper').innerHTML = `
    <div class="workspace-empty">
      <div>
        <span class="empty-icon">+</span>
        <h3>上传经营报表后，这里生成经营复盘</h3>
        <p>建议先选首页数据概览、商品明细和流量来源。系统会定位关键异常、建立行动台账，并保留下一周期的验证依据。</p>
        <button class="primary-btn" type="button" data-trigger-import>上传报表开始复盘</button>
      </div>
    </div>`;
  setReportActionsEnabled(false);
}

function executiveSummary(diagnosis) {
  const { data } = diagnosis;
  const topIssue = diagnosis.issues[0];
  const topAction = diagnosis.actions?.[0]?.tasks?.[1] || topIssue?.action || '先完成数据校准和核心链路排查。';
  const suggestTarget = diagnosis.targetPlan?.rows?.find((item) => item.level === '建议');
  const targetText = suggestTarget ? ` 建议目标销售额 ${yuan(suggestTarget.sales)}，较本期 ${suggestTarget.growth >= 0 ? '+' : ''}${suggestTarget.growth.toFixed(1)}%。` : '';
  const salesDirection = diagnosis.salesTrend.value >= 0 ? '增长' : '下滑';
  const trafficDirection = diagnosis.visitorTrend.value >= 0 ? '增长' : '下滑';
  return {
    result: `本期${data.reportType || '报告'}销售额 ${yuan(data.sales)}，较对比周期${salesDirection} ${diagnosis.salesTrend.label}；访客${trafficDirection} ${diagnosis.visitorTrend.label}，综合健康度 ${diagnosis.totalScore} 分。`,
    reason: topIssue ? `核心原因优先看「${topIssue.title}」：${topIssue.evidence}` : '核心经营指标暂无明显短板，建议进入商品和内容二级诊断。',
    action: `下周期先做一件事：${topAction}${targetText}`
  };
}

function executiveSummaryText(diagnosis) {
  const summary = executiveSummary(diagnosis);
  return [
    `${diagnosis.data.storeName}${getReportName(diagnosis)}老板摘要`,
    `1. 结果：${summary.result}`,
    `2. 原因：${summary.reason}`,
    `3. 动作：${summary.action}`
  ].join('\n');
}

function dataQualityLabel(score) {
  if (score >= 84) return '可直接交付';
  if (score >= 60) return '可初步交付，建议补齐明细';
  return '仅适合内部初判，需补数据';
}

const missingDataGuideCatalog = {
  overall: {
    file: '首页-数据概览 / 店铺经营核心报表',
    path: '生意参谋 > 首页 > 数据概览，或店铺经营核心月报/周报',
    improves: '校准支付金额、访客、转化率、客单价和经营总览',
    reason: '缺少大盘口径时，报告只能依赖明细表推算，正式交付可信度会下降。'
  },
  product: {
    file: '商品_全部 / 商品明细 / 宝贝排行',
    path: '生意参谋 > 商品 > 商品效果，按统计周期导出全部商品',
    improves: '增强宝贝排行、SKU四象限、动销判断和主推款优化建议',
    reason: '商品明细决定报告能否从“店铺整体”落到具体商品动作。'
  },
  category: {
    file: '品类-标准类目报表',
    path: '生意参谋 > 品类 > 标准类目，选择同一统计周期导出',
    improves: '增强类目结构、价格带/品类贡献和类目方向判断',
    reason: '类目数据能帮助判断增长来自哪个品类，而不是只看单品。'
  },
  traffic: {
    file: '无线店铺流量来源 / 流量看板总览',
    path: '生意参谋 > 流量 > 来源分析 / 流量看板，导出所有终端或无线端',
    improves: '增强搜索、推荐、内容、付费、私域结构和转化质量判断',
    reason: '流量来源决定问题是缺曝光、缺承接，还是渠道结构不健康。'
  },
  promotion: {
    file: '计划报表 / 关键词报表 / 单元报表 / 创意报表',
    path: '万相台/直通车/引力魔方 > 报表 > 计划/单元/关键词维度导出',
    improves: '增强推广计划级拆解、ROI四象限、预算调整和控质建议',
    reason: '没有计划级数据时，只能判断投放整体，无法给到具体预算动作。'
  },
  live: {
    file: '直播业绩-成交拆解 / 点击转化分析',
    path: '直播中控台 / 生意参谋直播模块 > 直播业绩，导出观看、点击、成交数据',
    improves: '增强直播曝光、商品点击、点击成交和播后回访判断',
    reason: '直播不能只看观看人数，需要看商品点击和成交承接。'
  },
  content: {
    file: '光合内容资产 / 内容种草报表',
    path: '光合平台 / 内容资产 > 数据总览，导出曝光、浏览、互动、点击、成交',
    improves: '增强内容种草漏斗、内容贡献和主动回访结合建议',
    reason: '内容数据能判断种草是否真的带来商品点击和后续成交。'
  },
  serviceDetail: {
    file: '客服团队概览 / 客服绩效 / 店铺绩效',
    path: '千牛/客户服务平台 > 客服绩效，导出咨询、响应、成交、询单转化数据',
    improves: '增强客服承接、询单转化、售前预期管理和退款治理建议',
    reason: '客服数据能解释转化和退款背后的承接问题。'
  },
  activity: {
    file: '活动效果 / 营销场景报表',
    path: '生意参谋/营销中心 > 活动/营销场景，导出活动成交、访客、订单',
    improves: '增强活动复盘、活动流量质量和下周期活动节奏建议',
    reason: '活动数据能区分日销增长和活动拉动，避免误判常态经营能力。'
  },
  refund: {
    file: '退款分析-退款商品 / 退款原因 / 已完结退款',
    path: '生意参谋/交易/退款分析 > 按商品和原因导出成功退款明细',
    improves: '增强退款金额TOP、退款原因矩阵、历史订单退款口径说明',
    reason: '退款明细决定报告能否从“退款偏高”落到SKU和原因治理。'
  },
  lineage: {
    file: '带原始字段的核心经营报表',
    path: '优先导出平台原始Excel，不要截图或二次汇总复制表',
    improves: '增强支付金额、净销售额、退款、转化等指标口径说明',
    reason: '口径可追溯后，正式报告更适合给品牌方归档。'
  },
  confidence: {
    file: '核心经营 + 商品 + 流量 + 退款组合包',
    path: '至少补齐首页数据概览、商品_全部、无线流量来源、退款分析四类文件',
    improves: '提升报告交付等级，减少“待核实”判断',
    reason: '核心数据越完整，系统越能给出具体动作，而不是泛化建议。'
  }
};

function buildDeliveryGrade(diagnosis) {
  const quality = diagnosis.dataQuality || { score: 0, checks: [], missing: [] };
  const checks = quality.checks || [];
  const has = (key) => Boolean(checks.find((item) => item.key === key)?.ok);
  const coreReady = has('overall') && has('product') && has('traffic');
  const riskReady = has('refund') || diagnosis.data.refundRate > 0;
  const actionReady = has('promotion') || has('serviceDetail') || has('live') || has('content');
  const missingCore = ['overall', 'product', 'traffic', 'refund'].filter((key) => !has(key)).length;
  if (quality.score >= 82 && coreReady && riskReady && actionReady && missingCore <= 1) {
    return {
      level: 'A',
      className: 'grade-a',
      title: 'A级：品牌方正式版，可直接交付',
      summary: '核心经营、商品、流量和风险数据较完整，可作为品牌方正式周/月报基础。',
      action: '建议导出 Word 后，再人工核对标题、周期、金额口径和下周期重点动作。'
    };
  }
  if (quality.score >= 58 && has('overall') && (has('product') || has('traffic'))) {
    return {
      level: 'B',
      className: 'grade-b',
      title: 'B级：内部诊断版，建议补数后再正式发送',
      summary: '本报告已能形成经营判断，但部分明细不足，适合内部会议或给运营先看。',
      action: '建议优先补齐右侧橙色清单中的前3项，再重新生成正式版。'
    };
  }
  return {
    level: 'C',
    className: 'grade-c',
    title: 'C级：数据不足，仅适合作为草稿参考',
    summary: '当前数据不足以支撑完整经营判断，正文结论需要谨慎使用。',
    action: '建议先补齐首页经营、商品明细、流量来源和退款明细，再生成报告。'
  };
}

function missingDataGuides(diagnosis) {
  const missing = diagnosis.dataQuality?.missing || [];
  const guides = missing
    .map((item) => ({ ...item, ...(missingDataGuideCatalog[item.key] || {}) }))
    .filter((item) => item.file || item.tip);
  if (guides.length) return guides.slice(0, 8);
  return [{
    key: 'next-check',
    name: '下次复盘增强包',
    file: '商品、流量、退款、推广、客服/直播/内容补充报表',
    path: '按本次报告右侧导入文件使用情况，补充未覆盖模块',
    improves: '让报告从可交付提升到可复盘、可追踪、可沉淀模板',
    reason: '本次核心数据较完整，下一步重点是增加动作验证维度。'
  }];
}

function deliveryGradeHtml(diagnosis) {
  const grade = buildDeliveryGrade(diagnosis);
  return `
    <section class="delivery-grade ${grade.className}">
      <div class="delivery-mark">${grade.level}</div>
      <div>
        <strong>${escapeHtml(grade.title)}</strong>
        <p>${escapeHtml(grade.summary)}</p>
        <span>${escapeHtml(grade.action)}</span>
      </div>
    </section>
  `;
}

function actionBoardGroup(issueItem) {
  const text = `${issueItem.title || ''} ${issueItem.owner || ''} ${issueItem.lever || ''}`;
  if (/退款|售后|利润|差评|履约/.test(text)) return '退款售后';
  if (/投放|推广|ROI|付费|预算|关键词|计划/.test(text)) return '推广投放';
  if (/流量|渠道|搜索|推荐|入口/.test(text)) return '流量渠道';
  if (/客服|承接|咨询|话术|响应/.test(text)) return '客服承接';
  if (/私域|复购|老客|会员|回访/.test(text)) return '私域复购';
  if (/内容|直播|种草|素材/.test(text)) return '内容直播';
  if (/商品|SKU|货品|动销|页面|主图|详情|转化/.test(text)) return '商品页面';
  if (/数据|口径|字段/.test(text)) return '数据口径';
  return '经营动作';
}

function actionBoardKpi(issueItem) {
  const text = `${issueItem.title || ''} ${issueItem.lever || ''}`;
  if (/退款|售后|利润/.test(text)) return '退款金额 / 退款率 / 差评关键词';
  if (/投放|推广|ROI|付费/.test(text)) return '花费 / ROI / 点击成交转化率';
  if (/流量|渠道|搜索|推荐/.test(text)) return '访客 / UV价值 / 来源转化率';
  if (/客服|承接|咨询/.test(text)) return '响应时长 / 询单转化 / 催付成交';
  if (/私域|复购|老客|会员|回访/.test(text)) return '老客支付 / 主动回访 / 复购率';
  if (/内容|直播|种草/.test(text)) return '观看点击率 / 商品点击 / 种草成交';
  if (/商品|SKU|货品|动销/.test(text)) return '支付金额 / 动销率 / TOP SKU占比';
  if (/数据|口径/.test(text)) return '字段来源 / 口径一致性 / 文件使用率';
  return '销售额 / 转化率 / 净销售额';
}

function actionBoardRows(diagnosis) {
  const seen = new Set();
  return (diagnosis.issues || [])
    .filter((item) => item && item.action)
    .map((item) => ({
      group: actionBoardGroup(item),
      title: item.title,
      owner: item.owner || '运营',
      priority: item.priority || 0,
      action: item.action,
      validation: item.validation || '下周期复盘时核实动作是否完成，并对比核心指标变化。',
      kpi: actionBoardKpi(item)
    }))
    .filter((item) => {
      const key = `${item.group}-${item.owner}-${item.action}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 8);
}

function actionBoardHtml(diagnosis) {
  const rows = actionBoardRows(diagnosis);
  if (!rows.length) return '<p class="report-note">暂无可拆解执行动作，建议先补齐核心经营数据后重新生成。</p>';
  return `
    <div class="ops-board">
      ${rows.map((item, index) => `
        <section class="ops-card">
          <header>
            <b>${index + 1}</b>
            <span>${escapeHtml(item.group)}</span>
            <em>${escapeHtml(item.owner)}</em>
          </header>
          <strong>${escapeHtml(item.title)}</strong>
          <p>${escapeHtml(item.action)}</p>
          <footer>
            <span>跟踪：${escapeHtml(item.kpi)}</span>
            <small>${escapeHtml(item.validation)}</small>
          </footer>
        </section>
      `).join('')}
    </div>
  `;
}

function missingDataGuideHtml(diagnosis) {
  const guides = missingDataGuides(diagnosis);
  return `
    <div class="missing-guide-list">
      ${guides.map((item, index) => `
        <section>
          <b>${index + 1}</b>
          <div>
            <strong>${escapeHtml(item.file || item.name || '待补充数据')}</strong>
            <p><span>下载位置</span>${escapeHtml(item.path || item.tip || '按平台后台对应模块导出')}</p>
            <p><span>增强报告</span>${escapeHtml(item.improves || item.tip || '增强对应模块判断')}</p>
            <em>${escapeHtml(item.reason || '补充后可减少待核实判断。')}</em>
          </div>
        </section>
      `).join('')}
    </div>
  `;
}

function metricChangeRows(diagnosis) {
  const { data } = diagnosis;
  const roiLabel = data.roi > 0 ? data.roi.toFixed(2) : '未提供';
  const roiJudge = data.roi > 0
    ? data.roi < getBenchmark(data.industry).roi ? '需优化投放效率' : '投放效率可观察'
    : '待补充计划明细';
  return [
    { name: '销售额', current: yuan(data.sales), previous: yuan(data.prevSales), change: diagnosis.salesTrend.label, judge: diagnosis.salesTrend.value >= 0 ? '增长' : '下滑' },
    { name: '访客数', current: Math.round(data.visitors).toLocaleString('zh-CN'), previous: Math.round(data.prevVisitors).toLocaleString('zh-CN'), change: diagnosis.visitorTrend.label, judge: diagnosis.visitorTrend.value >= 0 ? '流量增长' : '流量减少' },
    { name: '订单数', current: Math.round(data.orderCount).toLocaleString('zh-CN'), previous: '-', change: '-', judge: '看成交人数变化' },
    { name: '转化率', current: percent(data.conversion), previous: percent(diagnosis.decomposition.prevConversion), change: `${(data.conversion - diagnosis.decomposition.prevConversion).toFixed(2)}pp`, judge: data.conversion >= diagnosis.decomposition.prevConversion ? '承接改善' : '承接变弱' },
    { name: '客单价', current: yuan(data.aov), previous: yuan(diagnosis.decomposition.prevAov), change: `${data.aov >= diagnosis.decomposition.prevAov ? '+' : ''}${(data.aov - diagnosis.decomposition.prevAov).toFixed(2)}`, judge: data.aov >= diagnosis.decomposition.prevAov ? '价格带提升' : '高客单减少' },
    { name: '退款率', current: percent(data.refundRate), previous: '-', change: '-', judge: data.refundRate > getBenchmark(data.industry).refund ? '需治理退款' : '退款可控' },
    { name: '投放ROI', current: roiLabel, previous: '-', change: '-', judge: roiJudge }
  ];
}

function signedTrendLabel(current, previous, digits = 1) {
  if (!previous) return '无对比';
  const value = (current - previous) / previous * 100;
  return `${value >= 0 ? '+' : ''}${value.toFixed(digits)}%`;
}

function netSalesValue(data) {
  const refundAmount = data.refundAmount || data.importedAux?.refundAmount || 0;
  if (data.sales && refundAmount) return Math.max(0, data.sales - refundAmount);
  return data.netSales || data.importedAux?.netSales || Math.max(0, (data.sales || 0) - refundAmount);
}

function previousNetSalesValue(data) {
  const prevRefundAmount = data.prevRefundAmount || data.importedAux?.prevRefundAmount || 0;
  if (data.prevSales && prevRefundAmount) return Math.max(0, data.prevSales - prevRefundAmount);
  return data.prevNetSales || data.importedAux?.prevNetSales || Math.max(0, (data.prevSales || 0) - prevRefundAmount);
}

function refundAmountValue(data) {
  return data.refundAmount || data.importedAux?.refundAmount || 0;
}

function previousRefundAmountValue(data) {
  return data.prevRefundAmount || data.importedAux?.prevRefundAmount || 0;
}

function activeReturnSignal(data) {
  const aux = data.importedAux || {};
  return {
    sales: aux.activeReturnSales || 0,
    visitors: aux.activeReturnVisitors || 0,
    orders: aux.activeReturnOrders || 0,
    conversion: aux.activeReturnConversion || 0,
    uvValue: aux.activeReturnUvValue || 0
  };
}

function brandOneSentence(diagnosis) {
  const { data } = diagnosis;
  const netSales = netSalesValue(data);
  const refundAmount = refundAmountValue(data);
  const oldBuyerSales = data.oldBuyerSales || data.importedAux?.oldBuyerSales || 0;
  const activeReturn = activeReturnSignal(data);
  const salesWord = diagnosis.salesTrend.value >= 0 ? '支付金额环比增长' : '支付金额环比下降';
  const visitorWord = diagnosis.visitorTrend.value >= 0 ? '访客规模提升' : '访客规模下降';
  const drivers = [];
  if (data.aov >= diagnosis.decomposition.prevAov && diagnosis.decomposition.prevAov > 0) drivers.push('客单价提升');
  if (oldBuyerSales > data.sales * 0.25) drivers.push('老客复购');
  if (activeReturn.sales > data.sales * 0.15) drivers.push('主动回访承接');
  if (data.conversion >= diagnosis.decomposition.prevConversion && diagnosis.decomposition.prevConversion > 0) drivers.push('承接效率改善');
  const risk = refundAmount > data.sales * 0.18 ? '退款金额抬升' : data.roi > 0 && data.roi < getBenchmark(data.industry).roi ? '付费效率偏弱' : visitorWord;
  return `本期${salesWord}，${drivers.length ? `核心来自${drivers.slice(0, 3).join('、')}` : '需要继续拆解流量、转化和客单贡献'}；但${risk}，净销售额约 ${yuan(netSales)}，下周期应围绕“净销售额提升、退款治理、有效流量承接”推进。`;
}

function brandKpiRows(diagnosis) {
  const { data } = diagnosis;
  const refundAmount = refundAmountValue(data);
  const prevRefundAmount = previousRefundAmountValue(data);
  const netSales = netSalesValue(data);
  const prevNetSales = previousNetSalesValue(data);
  const oldBuyerSales = data.oldBuyerSales || data.importedAux?.oldBuyerSales || 0;
  const activeReturn = activeReturnSignal(data);
  return [
    { name: '支付金额', current: yuan(data.sales), previous: data.prevSales ? yuan(data.prevSales) : '-', change: signedTrendLabel(data.sales, data.prevSales), judge: diagnosis.salesTrend.value >= 0 ? '成交规模增长，看是否由客单/老客驱动' : '成交规模承压，先拆流量、转化、客单' },
    { name: '净销售额', current: yuan(netSales), previous: prevNetSales ? yuan(prevNetSales) : '-', change: signedTrendLabel(netSales, prevNetSales), judge: '品牌方周会建议作为第一经营指标' },
    { name: '成功退款金额', current: refundAmount ? yuan(refundAmount) : '-', previous: prevRefundAmount ? yuan(prevRefundAmount) : '-', change: signedTrendLabel(refundAmount, prevRefundAmount), judge: refundAmount > data.sales * 0.18 ? '正在侵蚀真实增长，需优先治理' : '关注退款商品结构' },
    { name: '访客数', current: Math.round(data.visitors).toLocaleString('zh-CN'), previous: data.prevVisitors ? Math.round(data.prevVisitors).toLocaleString('zh-CN') : '-', change: diagnosis.visitorTrend.label, judge: diagnosis.visitorTrend.value >= 0 ? '流量规模增加，继续看转化质量' : '流量收缩，增长不能只靠拉新' },
    { name: '支付买家数', current: Math.round(data.orderCount).toLocaleString('zh-CN'), previous: '-', change: '-', judge: '用于判断增长来自人数还是客单' },
    { name: '支付转化率', current: percent(data.conversion), previous: percent(diagnosis.decomposition.prevConversion), change: `${(data.conversion - diagnosis.decomposition.prevConversion).toFixed(2)}pp`, judge: data.conversion >= diagnosis.decomposition.prevConversion ? '承接效率改善' : '承接链路偏弱' },
    { name: '客单价', current: yuan(data.aov), previous: yuan(diagnosis.decomposition.prevAov), change: `${data.aov >= diagnosis.decomposition.prevAov ? '+' : ''}${(data.aov - diagnosis.decomposition.prevAov).toFixed(2)}`, judge: data.aov >= diagnosis.decomposition.prevAov ? '商品结构/组合成交改善' : '高客单商品贡献下降' },
    ...(oldBuyerSales ? [{ name: '老买家支付金额', current: yuan(oldBuyerSales), previous: '-', change: '-', judge: `老客贡献占支付金额 ${percent(oldBuyerSales / Math.max(data.sales, 1) * 100, 1)}，适合做复购SOP` }] : []),
    ...(activeReturn.sales ? [{ name: '主动回访支付金额', current: yuan(activeReturn.sales), previous: '-', change: '-', judge: `转化率 ${percent(activeReturn.conversion)}，UV价值 ${activeReturn.uvValue.toFixed(2)}，优先放大` }] : [])
  ];
}

function brandLeadHtml(diagnosis) {
  return `
    <h4>本周一句话结论</h4>
    <div class="conclusion-box brand-conclusion">
      <p>${brandOneSentence(diagnosis)}</p>
    </div>
  `;
}

function reportCoverHtml(diagnosis) {
  const data = diagnosis.data;
  const reportName = getReportName(diagnosis);
  const refundAmount = refundAmountValue(data);
  const netSales = netSalesValue(data);
  const grade = buildDeliveryGrade(diagnosis);
  const periodLabel = `${data.periodStart || ''}${data.periodEnd ? ` 至 ${data.periodEnd}` : ''}` || data.period || '统计周期待确认';
  return `
    <section class="report-cover">
      <div class="cover-brand">
        <span>Pinmoo AI</span>
        <strong>品沐咨询 · 电商增长智能体</strong>
      </div>
      <h2>${escapeHtml(data.storeName || data.brandName || '店铺')} ${escapeHtml(reportName)}</h2>
      <p>${escapeHtml(data.reportPurpose || '品牌方正式版')} · ${escapeHtml(data.platform || '平台待确认')} · ${escapeHtml(data.industry || '类目待确认')} · ${escapeHtml(periodLabel)}</p>
      <div class="cover-kpis">
        <section><span>支付金额</span><strong>${yuan(data.sales || 0)}</strong></section>
        <section><span>净销售额</span><strong>${yuan(netSales || 0)}</strong></section>
        <section><span>退款金额</span><strong>${refundAmount ? yuan(refundAmount) : '待补充'}</strong></section>
        <section><span>交付等级</span><strong>${escapeHtml(grade.level)}级</strong></section>
      </div>
      <div class="cover-conclusion">
        <b>${escapeHtml(grade.title)}</b>
        <span>${escapeHtml(brandOneSentence(diagnosis))}</span>
      </div>
    </section>
  `;
}

function reportModuleInsight(result, evidence, action) {
  return `
    <div class="module-insight">
      <section><span>本段结论</span><strong>${escapeHtml(result || '本模块数据已读取，建议结合表格明细复盘。')}</strong></section>
      <section><span>关键证据</span><strong>${escapeHtml(evidence || '需继续补充明细字段，用于增强判断依据。')}</strong></section>
      <section><span>下步动作</span><strong>${escapeHtml(action || '把本段结论纳入下周期复盘清单，跟踪是否改善。')}</strong></section>
    </div>
  `;
}

function weakTableNote(note) {
  return !note || /继续观察|看来源质量|看类目成交|看成交|需补|暂无|待补|辅助判断/.test(String(note));
}

function hasImportSummary(diagnosis) {
  return Boolean(diagnosis.data.importSummary && diagnosis.data.importSummary.length);
}

function hasImportedModule(diagnosis, moduleName) {
  if (!hasImportSummary(diagnosis)) return true;
  return diagnosis.data.importSummary.some((item) => (item.modules || []).includes(moduleName));
}

function actualImportedDetails(diagnosis, key) {
  const details = diagnosis.data.importedDetails || {};
  return Array.isArray(details[key]) ? details[key] : [];
}

function reportModuleState(diagnosis) {
  const imported = hasImportSummary(diagnosis);
  const aux = diagnosis.data.importedAux || {};
  const productItems = imported
    ? actualImportedDetails(diagnosis, 'productsAll').length || actualImportedDetails(diagnosis, 'products').length
    : diagnosis.weeklySections?.products?.length;
  const refundItems = actualImportedDetails(diagnosis, 'refundReasons').length;
  const categoryItems = actualImportedDetails(diagnosis, 'categories').length;
  const dailyItems = actualImportedDetails(diagnosis, 'daily').length;
  const liveItems = actualImportedDetails(diagnosis, 'live').length;
  const contentItems = actualImportedDetails(diagnosis, 'content').length;
  const serviceItems = actualImportedDetails(diagnosis, 'service').length;
  return {
    imported,
    importSummary: imported,
    lineage: imported && Boolean(diagnosis.data.importedLineage && diagnosis.data.importedLineage.length),
    confidence: imported && Boolean(diagnosis.data.importSummary && diagnosis.data.importSummary.length),
    aux: Boolean(aux.hasTrafficOverview || aux.hasMemberOverview),
    overall: !imported || hasImportedModule(diagnosis, '店铺整体'),
    daily: imported && Boolean(dailyItems),
    product: !imported || (hasImportedModule(diagnosis, '宝贝排行') && actualImportedDetails(diagnosis, 'products').length > 0),
    category: imported && Boolean(categoryItems),
    skuQuadrant: Boolean(productItems),
    refundMatrix: imported && Boolean(refundItems),
    live: imported && Boolean(liveItems),
    content: imported && Boolean(contentItems),
    serviceDetail: imported && Boolean(serviceItems),
    traffic: !imported || (hasImportedModule(diagnosis, '流量排行') && actualImportedDetails(diagnosis, 'traffic').length > 0),
    promotion: !imported || (hasImportedModule(diagnosis, '推广情况') && actualImportedDetails(diagnosis, 'promotion').length > 0),
    activity: !imported || (hasImportedModule(diagnosis, '活动情况') && actualImportedDetails(diagnosis, 'activity').length > 0),
    leverage: diagnosis.data.sales > 0 && diagnosis.data.visitors > 0,
    target: diagnosis.data.sales > 0 && diagnosis.data.visitors > 0,
    score: true,
    issues: true,
    actions: true
  };
}

function adaptiveReportOutline(diagnosis) {
  const state = reportModuleState(diagnosis);
  const included = ['老板先看', '数据完整度'];
  included.push('类目诊断方向');
  if (state.importSummary) included.push('导入文件使用情况');
  if (state.lineage) included.push('数据口径确认');
  if (state.confidence) included.push('指标可信度与文件使用率');
  if (state.aux) included.push('流量与客户辅助诊断');
  if (state.target) included.push('下周期目标建议');
  if (state.overall) included.push('店铺整体情况');
  if (state.daily) included.push('每日销售与退款表现');
  if (state.product) included.push('宝贝排行');
  if (state.category) included.push('品类/类目排行');
  if (state.skuQuadrant) included.push('SKU四象限诊断');
  if (state.refundMatrix) included.push('退款原因治理矩阵');
  if (state.live) included.push('直播业绩诊断');
  if (state.content) included.push('内容资产诊断');
  if (state.serviceDetail) included.push('客服绩效诊断');
  if (state.traffic) included.push('流量排行');
  if (state.promotion) included.push('推广情况');
  if (state.activity) included.push('活动情况');
  if (state.leverage) included.push('经营杠杆拆解');
  included.push('经营数据评分', '经营异常雷达', '经营行动台账', '上期动作验证', '下周期执行计划', '待确认问题', '待补充数据');

  const skipped = [];
  if (!state.overall) skipped.push('店铺整体：缺少销售额、访客、订单/转化率等大盘数据');
  if (!state.daily && hasImportSummary(diagnosis)) skipped.push('每日销售与退款：未识别到按日期拆分的店铺绩效/交易数据');
  if (!state.product) skipped.push('宝贝排行：未识别到商品/宝贝明细');
  if (!state.category && hasImportSummary(diagnosis)) skipped.push('品类/类目排行：未识别到标准类目或品类明细');
  if (!state.skuQuadrant) skipped.push('SKU四象限诊断：缺少可用于商品分层的宝贝明细');
  if (!state.refundMatrix && hasImportSummary(diagnosis)) skipped.push('退款原因治理矩阵：未识别到退款原因或售后明细');
  if (!state.live && hasImportSummary(diagnosis)) skipped.push('直播业绩诊断：未识别到直播观看、点击、成交或开播时长');
  if (!state.content && hasImportSummary(diagnosis)) skipped.push('内容资产诊断：未识别到光合/内容资产数据');
  if (!state.serviceDetail && hasImportSummary(diagnosis)) skipped.push('客服绩效诊断：未识别到客服绩效或团队概览数据');
  if (!state.traffic) skipped.push('流量排行：未识别到渠道/来源明细');
  if (!state.promotion) skipped.push('推广情况：未识别到计划、花费、点击、成交、ROI');
  if (!state.activity) skipped.push('活动情况：未识别到活动名称或活动成交数据');
  return { included, skipped };
}

function reportSection(title, body) {
  return `<h4>${title}</h4>${body}`;
}

function reportOutlineHtml(diagnosis) {
  const outline = adaptiveReportOutline(diagnosis);
  return reportSection('三、本次报告结构', `
    <div class="outline-box">
      <div><strong>已生成模块</strong><p>${outline.included.join(' / ')}</p></div>
      <div><strong>未生成模块</strong><p>${outline.skipped.length ? outline.skipped.join('；') : '本次上传数据已覆盖主要经营模块。'}</p></div>
    </div>
  `);
}

function categoryDirectionRows(diagnosis) {
  const strategy = diagnosis.categoryStrategy || getCategoryStrategy(diagnosis.data.industry);
  const boosts = Object.entries(strategy.priorityBoost || {}).map(([name, value]) => `${name}+${value}`).join('、') || '按通用经营权重排序';
  return [
    { name: '本类目优先判断', value: strategy.focus },
    { name: '问题优先级加权', value: boosts },
    { name: '转化诊断重点', value: strategy.conversion },
    { name: '退款/售后诊断重点', value: strategy.refund },
    { name: '商品结构诊断重点', value: strategy.product },
    { name: '渠道与复购诊断重点', value: strategy.channel },
    { name: '建议动作', value: strategy.action }
  ];
}

function categoryDirectionHtml(diagnosis) {
  return reportSection('类目诊断方向', `
    <table class="report-table">
      <thead><tr><th>维度</th><th>${escapeHtml(diagnosis.data.industry)}报告优化方向</th></tr></thead>
      <tbody>
        ${categoryDirectionRows(diagnosis).map((item) => `<tr><td>${item.name}</td><td>${escapeHtml(item.value)}</td></tr>`).join('')}
      </tbody>
    </table>
  `);
}

function importSummaryHtml(diagnosis) {
  return reportSection('导入文件使用情况', `
    <table class="report-table">
      <thead><tr><th>文件</th><th>识别类型</th><th>状态</th><th>使用行数</th><th>使用率</th><th>进入模块</th><th>说明</th></tr></thead>
      <tbody>
        ${tableRows(importSummaryRows(diagnosis), [
          { render: (item) => escapeHtml(item.file || '-') },
          { render: (item) => escapeHtml(item.kindLabel || '-') },
          { render: (item) => escapeHtml(item.status || '-') },
          { render: (item) => escapeHtml(item.rows || '-') },
          { render: (item) => escapeHtml(item.usage || '-') },
          { render: (item) => escapeHtml(item.modules || '-') },
          { render: (item) => escapeHtml(item.note || '-') }
        ], '暂无导入文件明细')}
      </tbody>
    </table>
  `);
}

function metricLineageSpecs() {
  return [
    { key: 'sales', name: '销售额', aliases: ['销售额', 'GMV', '成交金额', '支付金额', '总支付金额', '净支付金额', '总成交金额', '直接成交金额', '间接成交金额', '引入成交金额', '直播成交金额', '店播成交金额', '客服支付金额', '内容成交金额', 'sales'], format: (data) => yuan(data.sales), method: '优先读取平台支付金额/成交金额；若存在本店大盘行，优先采用大盘行。' },
    { key: 'prevSales', name: '对比期销售额', aliases: ['销售额-对比日', '成交金额-对比日', '支付金额-对比日', 'salesPrev', 'prevSales'], format: (data) => yuan(data.prevSales), method: '优先读取对比字段；没有对比字段时，尝试按相邻日期/月度大盘自动识别。' },
    { key: 'visitors', name: '访客数', aliases: ['访客数', '访客', 'UV', '店铺访客数', '商品访客数', '引入商详访客数', '观看人数', '内容浏览量', '咨询人数', '接待人数', 'visitors'], format: (data) => Math.round(data.visitors).toLocaleString('zh-CN'), method: '优先读取店铺大盘访客；商品/流量明细只用于排行和结构，不直接覆盖大盘。' },
    { key: 'conversion', name: '转化率', aliases: ['转化率', '支付转化率', '点击转化率', '询单转化率', '商品支付转化率', '店铺成交转化率', '成交转化率', '点击-成交转化率', '内容成交转化率', 'conversion'], format: (data) => percent(data.conversion), method: '优先使用平台原始转化率字段；没有时才用成交人数/访客数推算。' },
    { key: 'aov', name: '客单价', aliases: ['客单价', '人均成交金额', '会员客单价', 'aov'], format: (data) => yuan(data.aov), method: '优先使用平台客单价字段；没有时才用销售额/成交人数推算。' },
    { key: 'refundRate', name: '退款率', aliases: ['退款率', '退货率', '成功退款率', '金额退款率', '订单退款率', 'refundRate'], format: (data) => percent(data.refundRate), method: '百分数字段按百分比识别，小于 1 的平台小数会自动换算为百分比。' },
    { key: 'refundAmount', name: '退款金额', aliases: ['退款金额', '取消及售后退款金额', '成功退款金额', 'refundAmount'], format: (data) => (data.refundAmount || data.importedAux?.refundAmount) ? yuan(data.refundAmount || data.importedAux.refundAmount) : '-', method: '用于校验退款率和售后风险，若无大盘退款金额则只做退款原因参考。' },
    { key: 'roi', name: '投放 ROI', aliases: ['ROI', '投放ROI', '投产比', '投入产出比', '含预售投产比', 'roi'], format: (data) => data.roi > 0 ? data.roi.toFixed(2) : '未提供', method: '优先读取计划/推广报表 ROI；缺失时不按 0 判断低效。' },
    { key: 'product', name: '商品动销', aliases: ['商品名称', '宝贝名称', '商品ID', 'SPU名称', '商品总数', '商品数', '有成交商品数', '动销商品数', 'activeProductCount'], format: (data) => `${data.activeProductCount}/${data.productCount}`, method: '优先根据商品明细聚合成交商品数；有大盘商品数时用大盘值校准。' },
    { key: 'traffic', name: '渠道结构', aliases: ['一级来源', '二级来源', '三级来源', '四级来源', '流量来源', '渠道来源', '搜索占比', '推荐占比', '内容占比', '付费占比', '私域占比'], format: (data) => `${percent(data.searchShare, 1)} / ${percent(data.recommendShare, 1)} / ${percent(data.contentShare, 1)} / ${percent(data.paidShare, 1)} / ${percent(data.privateShare, 1)}`, method: '生意参谋来源表按经营优势/付费推广/主动回访等层级归类，避免父子来源重复累加。' },
    { key: 'category', name: '品类/类目', aliases: ['一级类目名称', '二级类目名称', '类目名称', '支付金额占比', '有支付商品数'], format: (data) => data.importedDetails?.categories?.length ? `${data.importedDetails.categories.length} 个类目` : '-', method: '用于判断类目成交结构、类目加购承接和类目退款金额。' },
    { key: 'live', name: '直播业绩', aliases: ['观看人数', '商品点击人数', '观看-商品点击率', '直播成交金额', '开播时长', '播后成交金额'], format: (data) => data.importedDetails?.live?.length ? `${data.importedDetails.live.length} 条直播记录` : '-', method: '用于判断直播看点、商品点击、播中成交和播后成交贡献。' },
    { key: 'content', name: '内容资产', aliases: ['内容曝光量', '内容浏览量', '内容成交金额', '内容成交转化率', '短视频发布数', '直播场次'], format: (data) => data.importedDetails?.content?.length ? `${data.importedDetails.content.length} 条内容记录` : '-', method: '用于判断光合内容资产是否带来曝光、互动和成交。' },
    { key: 'serviceRate', name: '客服/服务承接', aliases: ['客服响应达标率', '客服响应率', '旺旺满意度', '24小时揽收及时率', '48小时揽收及时率', 'serviceRate'], format: (data) => data.serviceRate ? percent(data.serviceRate, 1) : '未提供', method: '根据客服或服务体验字段读取；缺失时只提示补充，不默认判差。' }
  ];
}

function lineageRows(diagnosis) {
  const source = diagnosis.data.importedLineage || [];
  const sourceMap = new Map(source.map((item) => [item.key, item]));
  return metricLineageSpecs().map((spec) => {
    const item = sourceMap.get(spec.key) || {};
    const files = item.files && item.files.length ? item.files.join('、') : '-';
    const fields = item.fields && item.fields.length ? item.fields.join('、') : '-';
    const hasValue = !['-', '¥ 0', '0', '0.00%', '未提供', '0/0'].includes(String(spec.format(diagnosis.data)));
    const status = item.status || (hasValue ? '已计算，待确认来源' : '待补充');
    return {
      key: spec.key,
      metric: spec.name,
      value: spec.format(diagnosis.data),
      status,
      files,
      fields,
      method: spec.method
    };
  });
}

function lineageHtml(diagnosis) {
  return reportSection('数据口径确认', `
    <table class="report-table">
      <thead><tr><th>指标</th><th>本期值</th><th>口径状态</th><th>来源文件</th><th>匹配字段</th><th>计算/取数说明</th></tr></thead>
      <tbody>
        ${tableRows(lineageRows(diagnosis), [
          { render: (item) => escapeHtml(item.metric) },
          { render: (item) => escapeHtml(item.value) },
          { render: (item) => escapeHtml(item.status) },
          { render: (item) => escapeHtml(item.files) },
          { render: (item) => escapeHtml(item.fields) },
          { render: (item) => escapeHtml(item.method) }
        ], '暂无数据口径记录')}
      </tbody>
    </table>
  `);
}

function hasMetricValue(key, data) {
  if (key === 'roi') return data.roi > 0;
  if (key === 'product') return data.productCount > 0 || data.activeProductCount > 0;
  if (key === 'traffic') return data.searchShare || data.recommendShare || data.contentShare || data.paidShare || data.privateShare;
  if (key === 'category') return Boolean(data.importedDetails?.categories?.length);
  if (key === 'live') return Boolean(data.importedDetails?.live?.length);
  if (key === 'content') return Boolean(data.importedDetails?.content?.length);
  if (key === 'serviceRate') return data.serviceRate > 0;
  if (key === 'refundAmount') return Boolean(data.refundAmount || data.importedAux?.refundAmount);
  return Number(data[key] || 0) > 0;
}

function metricConfidenceRows(diagnosis) {
  const data = diagnosis.data;
  const sourceRows = lineageRows(diagnosis);
  const sourceMap = new Map(sourceRows.map((item) => [item.key, item]));
  const derivedKeys = new Set(['conversion', 'aov', 'refundRate', 'product', 'traffic']);
  return metricLineageSpecs().map((spec) => {
    const source = sourceMap.get(spec.key) || {};
    const hasValue = hasMetricValue(spec.key, data);
    const hasSource = source.files && source.files !== '-';
    const direct = hasSource && hasValue;
    const derived = hasValue && (!hasSource || derivedKeys.has(spec.key));
    let level = 'missing';
    let levelText = '待补充';
    let score = 0;
    let advice = '补充平台导出表或模板字段后再用于正式交付。';
    if (direct && !derivedKeys.has(spec.key)) {
      level = 'strong';
      levelText = '已直接取数';
      score = 96;
      advice = '可作为报告主指标使用，交付前仅需抽样核对。';
    } else if (direct && derivedKeys.has(spec.key)) {
      level = 'good';
      levelText = '已匹配并计算';
      score = 86;
      advice = '已找到来源字段，建议核对平台口径是否与报告口径一致。';
    } else if (derived) {
      level = 'weak';
      levelText = '已推算';
      score = 62;
      advice = '可用于初判，正式交付建议补充原始字段。';
    }
    if (!hasValue && hasSource) {
      level = 'weak';
      levelText = '有字段但未形成指标';
      score = 48;
      advice = '字段可能为空、格式异常或未进入当前周期聚合，需要复核文件。';
    }
    return {
      key: spec.key,
      metric: spec.name,
      value: spec.format(data),
      level,
      levelText,
      score,
      files: source.files || '-',
      fields: source.fields || '-',
      advice
    };
  });
}

function confidenceSummary(rows) {
  const score = rows.length ? Math.round(rows.reduce((sum, item) => sum + item.score, 0) / rows.length) : 0;
  return {
    score,
    strong: rows.filter((item) => item.level === 'strong' || item.level === 'good').length,
    weak: rows.filter((item) => item.level === 'weak').length,
    missing: rows.filter((item) => item.level === 'missing').length
  };
}

function dataUsageRows(diagnosis) {
  return (diagnosis.data.importSummary || []).map((item) => {
    const usageRate = item.rawRows ? item.usedRows / item.rawRows * 100 : 0;
    return {
      file: item.name,
      status: item.status,
      rawRows: item.rawRows || 0,
      usedRows: item.usedRows || 0,
      usageRate,
      modules: item.modules?.length ? item.modules.join('、') : '-',
      note: item.note || ''
    };
  }).sort((a, b) => b.usageRate - a.usageRate || b.usedRows - a.usedRows);
}

function dataConfidenceHtml(diagnosis) {
  const rows = metricConfidenceRows(diagnosis);
  const summary = confidenceSummary(rows);
  const usage = dataUsageRows(diagnosis);
  const unused = usage.filter((item) => item.rawRows > 0 && item.usedRows === 0);
  return reportSection('指标可信度与文件使用率', `
    <div class="confidence-grid">
      <section><span>可信度</span><strong>${summary.score}分</strong><p>${summary.score >= 82 ? '可交付' : summary.score >= 62 ? '需复核关键指标' : '需补齐口径'}</p></section>
      <section><span>可直接/已计算</span><strong>${summary.strong}</strong><p>能支撑报告主结论的指标数</p></section>
      <section><span>需复核/待补充</span><strong>${summary.weak + summary.missing}</strong><p>${unused.length ? `${unused.length} 个文件暂未贡献关键字段` : '导入文件已进入主要模块'}</p></section>
    </div>
    <table class="report-table confidence-table">
      <thead><tr><th>指标</th><th>本期值</th><th>可信度</th><th>来源文件</th><th>字段</th><th>交付建议</th></tr></thead>
      <tbody>
        ${tableRows(rows, [
          { render: (item) => escapeHtml(item.metric) },
          { render: (item) => escapeHtml(item.value) },
          { render: (item) => `<span class="confidence-pill ${item.level}">${escapeHtml(item.levelText)}</span>` },
          { render: (item) => escapeHtml(item.files) },
          { render: (item) => escapeHtml(item.fields) },
          { render: (item) => escapeHtml(item.advice) }
        ], '暂无可信度记录')}
      </tbody>
    </table>
    <table class="report-table usage-table">
      <thead><tr><th>文件</th><th>状态</th><th>已用/总行</th><th>使用率</th><th>进入模块</th><th>提示</th></tr></thead>
      <tbody>
        ${tableRows(usage, [
          { render: (item) => escapeHtml(item.file) },
          { render: (item) => escapeHtml(item.status) },
          { render: (item) => `${Math.round(item.usedRows).toLocaleString('zh-CN')}/${Math.round(item.rawRows).toLocaleString('zh-CN')}` },
          { render: (item) => `${percent(item.usageRate, 1)}` },
          { render: (item) => escapeHtml(item.modules) },
          { render: (item) => escapeHtml(item.usedRows ? item.note : '已读取但未匹配到报告关键字段，可作为后续模板扩展样本') }
        ], '暂无文件使用记录')}
      </tbody>
    </table>
  `);
}

function targetPlanHtml(targetPlan) {
  return reportSection('下周期目标建议', `
    <p>${targetPlan.baseline}</p>
    <p class="report-note">目标口径：${targetPlan.basis || '目标需结合实际经营口径滚动校准。'}</p>
    <p>${targetPlan.focus}</p>
    <table class="report-table">
      <thead><tr><th>目标档位</th><th>目标销售额</th><th>较本期</th><th>目标访客</th><th>目标转化率</th><th>目标客单价</th></tr></thead>
      <tbody>
        ${targetPlan.rows.map((item) => `<tr><td>${targetPlan.periodName}${item.level}</td><td>${yuan(item.sales)}</td><td>${item.growth >= 0 ? '+' : ''}${item.growth.toFixed(1)}%</td><td>${item.visitors.toLocaleString('zh-CN')}</td><td>${percent(item.conversion)}</td><td>${yuan(item.aov)}</td></tr>`).join('')}
      </tbody>
    </table>
  `);
}

function overallHtml(diagnosis) {
  return reportSection('本周经营总览：净销售额视角', `
    <ul>${operatingSummary(diagnosis).map((item) => `<li>${item}</li>`).join('')}</ul>
    <table class="report-table">
      <thead><tr><th>核心指标</th><th>本期数据</th><th>对比期</th><th>环比/说明</th><th>经营解读</th></tr></thead>
      <tbody>
        ${brandKpiRows(diagnosis).map((item) => `<tr><td>${item.name}</td><td>${item.current}</td><td>${item.previous}</td><td>${item.change}</td><td>${item.judge}</td></tr>`).join('')}
      </tbody>
    </table>
    <p class="report-note">口径说明：支付金额用于观察成交规模，净销售额用于判断真实经营质量；若导入了退款/店铺绩效数据，系统会优先把退款对经营结果的影响单独拆出。</p>
    <table class="report-table">
      <thead><tr><th>模块</th><th>状态</th><th>诊断说明</th></tr></thead>
      <tbody>
        ${moduleDiagnosis(diagnosis).map((item) => `<tr><td>${item.module}</td><td>${item.status}</td><td>${item.detail}</td></tr>`).join('')}
      </tbody>
    </table>
  `);
}

function dailyTrendChart(items) {
  const rows = [...(items || [])]
    .filter((item) => Number.isFinite(item.dateStamp) && item.dateStamp > 0)
    .sort((a, b) => a.dateStamp - b.dateStamp)
    .slice(-14);
  if (!rows.length) return '<p class="empty-text">暂无可绘制的单日趋势图。</p>';
  const width = 760;
  const height = 260;
  const pad = { top: 24, right: 34, bottom: 42, left: 62 };
  const chartWidth = width - pad.left - pad.right;
  const chartHeight = height - pad.top - pad.bottom;
  const series = [
    { key: 'sales', label: '支付金额', color: '#2563eb' },
    { key: 'refundAmount', label: '退款金额', color: '#dc2626' },
    { key: 'netSales', label: '净销售额', color: '#16a34a' }
  ];
  const values = rows.flatMap((row) => series.map((item) => Number(row[item.key]) || 0));
  const max = Math.max(...values, 1);
  const xAt = (index) => pad.left + (rows.length === 1 ? chartWidth / 2 : index * chartWidth / (rows.length - 1));
  const yAt = (value) => pad.top + chartHeight - ((Number(value) || 0) / max * chartHeight);
  const gridValues = [max, max / 2, 0];
  const grid = gridValues.map((value) => {
    const y = yAt(value);
    return `<g><line x1="${pad.left}" y1="${y.toFixed(1)}" x2="${width - pad.right}" y2="${y.toFixed(1)}" class="trend-grid-line"></line><text x="12" y="${(y + 4).toFixed(1)}" class="trend-axis">${escapeHtml(yuan(value))}</text></g>`;
  }).join('');
  const lines = series.map((item) => {
    const points = rows.map((row, index) => `${xAt(index).toFixed(1)},${yAt(row[item.key]).toFixed(1)}`).join(' ');
    const circles = rows.map((row, index) => {
      const x = xAt(index).toFixed(1);
      const y = yAt(row[item.key]).toFixed(1);
      return `<g><circle cx="${x}" cy="${y}" r="3.5" fill="${item.color}"><title>${escapeHtml(`${row.date || row.name} ${item.label} ${yuan(row[item.key] || 0)}`)}</title></circle></g>`;
    }).join('');
    return `<polyline points="${points}" fill="none" stroke="${item.color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></polyline>${circles}`;
  }).join('');
  const labels = rows.map((row, index) => {
    const show = rows.length <= 8 || index === 0 || index === rows.length - 1 || index % 2 === 0;
    if (!show) return '';
    return `<text x="${xAt(index).toFixed(1)}" y="${height - 14}" text-anchor="middle" class="trend-axis">${escapeHtml(String(row.date || row.name).slice(5))}</text>`;
  }).join('');
  return `
    <div class="daily-trend-card">
      <div class="daily-trend-head">
        <strong>单日支付 / 退款 / 净销售趋势</strong>
        <div class="daily-trend-legend">
          ${series.map((item) => `<span><b style="background:${item.color}"></b>${item.label}</span>`).join('')}
        </div>
      </div>
      <svg class="daily-trend-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="单日支付退款净销售趋势图">
        ${grid}
        <line x1="${pad.left}" y1="${height - pad.bottom}" x2="${width - pad.right}" y2="${height - pad.bottom}" class="trend-axis-line"></line>
        ${lines}
        ${labels}
      </svg>
    </div>
  `;
}

function dailyHtml(items) {
  const topSales = [...(items || [])].sort((a, b) => (b.sales || 0) - (a.sales || 0))[0];
  const topRefund = [...(items || [])].sort((a, b) => (b.refundAmount || 0) - (a.refundAmount || 0))[0];
  const result = topSales ? `${topSales.date || topSales.name} 是本周期销售峰值日，需判断峰值是否来自活动、直播、老客回访或付费拉动。` : '本周期暂未识别到按日期拆分的数据。';
  const evidence = topSales ? `峰值销售 ${yuan(topSales.sales || 0)}${topRefund?.refundAmount ? `；最高退款日 ${topRefund.date || topRefund.name}，退款 ${yuan(topRefund.refundAmount)}` : ''}` : '建议补充店铺绩效/交易概览的分日数据。';
  const action = topRefund?.refundAmount ? '把高销售日和高退款日交叉复盘，确认是否存在活动承诺、发货或页面预期问题。' : '下周期继续补齐分日退款金额，用于判断销售峰值质量。';
  return reportSection('每日销售与退款表现', `
    <p class="report-note">口径说明：本模块仅展示统计周期内按“日期”拆分的单日经营数据；“同行同层优秀 / 同行同层均值 / 全店平均值”等平台参考值不作为某一天展示，避免与单日趋势混淆。</p>
    ${reportModuleInsight(result, evidence, action)}
    ${dailyTrendChart(items)}
    <table class="report-table">
      <thead><tr><th>日期</th><th>访客数</th><th>销售额</th><th>订单数</th><th>转化率</th><th>退款金额</th><th>净销售额</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(item.date || item.name || '-') },
          { render: (item) => Math.round(item.visitors || 0).toLocaleString('zh-CN') },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => Math.round(item.orders || 0).toLocaleString('zh-CN') },
          { render: (item) => percent(item.conversion || 0) },
          { render: (item) => item.refundAmount ? yuan(item.refundAmount) : '-' },
          { render: (item) => yuan(item.netSales || Math.max(0, (item.sales || 0) - (item.refundAmount || 0))) }
        ], '暂无按日期拆分的店铺绩效数据')}
      </tbody>
    </table>
    <p class="report-note">经营观察：${topSales ? `${escapeHtml(topSales.date || topSales.name)}为本周期内单日销售额最高，达到 ${yuan(topSales.sales || 0)}。` : ''}${topRefund && topRefund.refundAmount ? `${escapeHtml(topRefund.date || topRefund.name)}单日退款金额最高，达到 ${yuan(topRefund.refundAmount)}，下周需要把“高销售日是否伴随高退款”作为复盘重点。` : '建议后续补充按日期拆分的退款金额，用于判断单日爆发是否被售后抵消。'}</p>
  `);
}

function productHtml(items) {
  const rows = items || [];
  const topSales = [...rows].sort((a, b) => (b.sales || 0) - (a.sales || 0))[0];
  const topRefund = [...rows].sort((a, b) => (b.refundAmount || 0) - (a.refundAmount || 0))[0];
  const highRisk = rows.filter((item) => (item.refundAmount || 0) > 0 || (item.refundRate || 0) >= 15).length;
  return reportSection('宝贝排行', `
    ${reportModuleInsight(
      topSales ? `成交核心集中在 ${topSales.name || '头部商品'}，商品复盘需同时看成交贡献和退款风险。` : '暂未识别到有效商品明细。',
      topSales ? `TOP商品支付金额 ${yuan(topSales.sales || 0)}${topRefund?.refundAmount ? `；退款最高商品 ${topRefund.name || '-'}，退款 ${yuan(topRefund.refundAmount)}` : ''}` : '建议补充商品_全部或宝贝明细。',
      highRisk ? `先处理 ${highRisk} 个存在退款风险的商品，再决定是否放大流量。` : '优先稳定主推款页面、价格理由、评价证据和客服异议话术。'
    )}
    <table class="report-table">
      <thead><tr><th>宝贝/商品</th><th>支付金额</th><th>访客</th><th>支付买家</th><th>转化率</th><th>退款金额</th><th>退款率</th><th>经营判断</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => Math.round(item.visitors || 0).toLocaleString('zh-CN') },
          { render: (item) => Math.round(item.orders || 0).toLocaleString('zh-CN') },
          { render: (item) => percent(item.conversion || 0) },
          { render: (item) => item.refundAmount ? yuan(item.refundAmount) : '-' },
          { render: (item) => item.refundRate ? percent(item.refundRate) : '-' },
          { render: (item) => escapeHtml(productDiagnosis(item, rows)) }
        ])}
      </tbody>
    </table>
  `);
}

function productDiagnosis(item, peers = []) {
  if (!item) return '-';
  const sales = Number(item.sales || 0);
  const visitors = Number(item.visitors || 0);
  const orders = Number(item.orders || 0);
  const conversion = Number(item.conversion || 0);
  const refundAmount = Number(item.refundAmount || 0);
  const refundRate = Number(item.refundRate || 0);
  const medianSales = median((peers || []).map((sku) => Number(sku.sales || 0)));
  const medianVisitors = median((peers || []).map((sku) => Number(sku.visitors || 0)));
  if (refundAmount > sales && sales > 0) return '退款金额高于当期成交，可能包含历史订单退款，需按订单和退款原因复核。';
  if (refundRate >= 30 || refundAmount >= Math.max(sales * 0.2, 1000)) return '成交贡献同时伴随售后风险，短期不建议单纯加量，先核查页面承诺和客服确认。';
  if (sales >= Math.max(medianSales * 1.4, 1000) && conversion >= 3 && refundAmount <= Math.max(sales * 0.08, 500)) return '主力成交款，建议稳定资源位，并围绕评价、赠品和套装做轻优化。';
  if (visitors >= Math.max(medianVisitors * 1.4, 500) && conversion > 0 && conversion < 1) return '高访低转，优先检查首图、价格理由、规格选择和评价信任。';
  if (visitors < Math.max(medianVisitors * 0.7, 80) && conversion >= 3 && sales > 0) return '小流量高转化，可小预算测试搜索词、内容种草或老客回访。';
  if (orders <= 1 && visitors >= 200) return '有曝光但成交弱，需判断流量是否精准，并补充加购/收藏数据。';
  if (!weakTableNote(item.note)) return item.note;
  return '按销售、访客、转化和退款综合观察，下周期重点验证页面承接和售后反馈。';
}

function median(values) {
  const usable = values.filter((value) => Number.isFinite(value) && value > 0).sort((a, b) => a - b);
  if (!usable.length) return 0;
  const mid = Math.floor(usable.length / 2);
  return usable.length % 2 ? usable[mid] : (usable[mid - 1] + usable[mid]) / 2;
}

function shortProductNames(items) {
  if (!items.length) return '暂无明确商品';
  return items.slice(0, 3).map((item) => item.name || '-').join('、');
}

function skuQuadrantRows(diagnosis) {
  const data = diagnosis.data;
  const benchmark = getBenchmark(data.industry);
  const importedItems = actualImportedDetails(diagnosis, 'productsAll');
  const fallbackItems = actualImportedDetails(diagnosis, 'products');
  const sourceItems = importedItems.length ? importedItems : fallbackItems.length ? fallbackItems : diagnosis.weeklySections?.products || [];
  const products = sourceItems
    .filter((item) => item && item.name && (item.sales || item.visitors || item.orders || item.refundAmount || item.addCarts))
    .map((item) => ({
      ...item,
      sales: Number(item.sales || 0),
      visitors: Number(item.visitors || 0),
      orders: Number(item.orders || 0),
      conversion: Number(item.conversion || 0),
      refundRate: Number(item.refundRate || 0),
      refundAmount: Number(item.refundAmount || 0),
      addCarts: Number(item.addCarts || 0)
    }));
  if (!products.length) return [];

  const medianSales = median(products.map((item) => item.sales));
  const medianVisitors = median(products.map((item) => item.visitors));
  const medianConversion = median(products.map((item) => item.conversion));
  const conversionBase = data.conversion || medianConversion || benchmark.conversion;
  const refundBase = benchmark.refund || data.refundRate || 8;
  const topSalesFloor = Math.max(medianSales * 1.35, data.sales ? data.sales * 0.04 : 0);
  const highVisitorFloor = Math.max(medianVisitors * 1.35, data.visitors ? data.visitors * 0.02 : 0);
  const highConversionFloor = Math.max(conversionBase * 1.15, medianConversion * 1.15, 1);
  const lowConversionCeil = Math.max(conversionBase * 0.75, 0.8);

  const bySales = [...products].sort((a, b) => b.sales - a.sales);
  const byRefund = [...products].sort((a, b) => (b.refundAmount || 0) - (a.refundAmount || 0));
  const main = bySales.filter((item) => item.sales >= topSalesFloor || item.sales === bySales[0]?.sales);
  const lowConvert = products
    .filter((item) => item.visitors >= highVisitorFloor && item.conversion > 0 && item.conversion <= lowConversionCeil)
    .sort((a, b) => b.visitors - a.visitors);
  const scaleCandidate = products
    .filter((item) => item.sales < topSalesFloor && item.conversion >= highConversionFloor && item.visitors > 0 && item.visitors <= Math.max(highVisitorFloor, medianVisitors * 1.8))
    .sort((a, b) => b.conversion - a.conversion || b.sales - a.sales);
  const refundRisk = products
    .filter((item) => item.refundAmount > 0 || item.refundRate > 0)
    .filter((item) => item.refundRate >= refundBase * 1.2 || item.refundAmount >= Math.max(median(products.map((sku) => sku.refundAmount)) * 1.5, item.sales * 0.06))
    .sort((a, b) => (b.refundAmount || 0) - (a.refundAmount || 0));
  const longTail = products
    .filter((item) => item.sales <= Math.max(medianSales * 0.45, 1) && item.visitors <= Math.max(medianVisitors * 0.7, 1) && item.orders <= Math.max(median(products.map((sku) => sku.orders)) * 0.7, 1))
    .sort((a, b) => a.sales - b.sales || a.visitors - b.visitors);

  return [
    {
      type: '主力款',
      count: main.length,
      items: main.slice(0, 3),
      criteria: `销售额高于中位数 ${yuan(medianSales)}，或贡献接近头部成交`,
      diagnosis: `${shortProductNames(main)} 是当前成交基本盘，重点看库存、价格带和评价稳定性。`,
      action: '保持流量供给和页面稳定，围绕评价、赠品、套装做轻优化，避免大幅改动影响成交。'
    },
    {
      type: '高访低转',
      count: lowConvert.length,
      items: lowConvert.slice(0, 3),
      criteria: `访客高于 ${Math.round(highVisitorFloor).toLocaleString('zh-CN')}，转化低于 ${percent(lowConversionCeil)}`,
      diagnosis: `${shortProductNames(lowConvert)} 有流量但承接偏弱，通常问题在首图卖点、价格理由、评价信任或规格选择。`,
      action: '优先做主图五连、详情首屏、价格锚点和客服异议话术；下周期验证转化率是否提升。'
    },
    {
      type: '低访高转',
      count: scaleCandidate.length,
      items: scaleCandidate.slice(0, 3),
      criteria: `转化高于 ${percent(highConversionFloor)}，但流量未进入头部`,
      diagnosis: `${shortProductNames(scaleCandidate)} 具备放量潜力，适合小预算测试搜索词、人群和内容种草。`,
      action: '给小额预算和内容曝光测试，不先大幅降价；看加购、收藏、询单和退款是否同步健康。'
    },
    {
      type: '售后风险',
      count: refundRisk.length,
      items: refundRisk.slice(0, 3),
      criteria: `退款率高于类目警戒线 ${percent(refundBase * 1.2)}，或退款金额显著偏高`,
      diagnosis: `${shortProductNames(refundRisk)} 需要先拆退款原因，避免继续放大有售后缺口的流量。`,
      action: '核查尺码/功效/口味/破损/发货等原因，调整页面承诺和客服确认话术，再决定是否继续推广。'
    },
    {
      type: '长尾清理',
      count: longTail.length,
      items: longTail.slice(0, 3),
      criteria: '销售、访客、订单均低于商品中位水平',
      diagnosis: `${shortProductNames(longTail)} 对经营贡献偏弱，容易占用视觉、库存和投放注意力。`,
      action: '合并为组合装、清仓款或内容测试款；连续两周期无改善则降低资源位。'
    }
  ].filter((row) => row.count > 0);
}

function skuQuadrantHtml(diagnosis) {
  const rows = skuQuadrantRows(diagnosis);
  return reportSection('SKU四象限诊断', `
    <div class="quadrant-grid">
      ${rows.length ? rows.map((row) => `
        <section>
          <div><strong>${escapeHtml(row.type)}</strong><span>${row.count} 个</span></div>
          <p>${escapeHtml(row.diagnosis)}</p>
          <small>${escapeHtml(row.criteria)}</small>
          <ol class="sku-ranked-list">
            ${row.items.map((item, index) => `
              <li>
                <b>${index + 1}</b>
                <div>
                  <strong>${escapeHtml(item.name || '-')}</strong>
                  <span>${yuan(item.sales || 0)} · ${Math.round(item.visitors || 0).toLocaleString('zh-CN')}访客 · 转化${percent(item.conversion || 0)}${item.refundRate ? ` · 退款${percent(item.refundRate)}` : ''}</span>
                </div>
              </li>
            `).join('')}
          </ol>
          <em>${escapeHtml(row.action)}</em>
        </section>
      `).join('') : '<p>暂无足够商品明细生成四象限。</p>'}
    </div>
  `);
}

function refundMatrixRows(diagnosis) {
  const rows = actualImportedDetails(diagnosis, 'refundReasons');
  if (!rows.length) return [];
  const totalAmount = rows.reduce((sum, item) => sum + (item.refundAmount || 0), 0);
  const category = getCategoryStrategy(diagnosis.data.industry);
  return rows.slice(0, 8).map((item) => {
    const share = totalAmount ? item.refundAmount / totalAmount * 100 : 0;
    const reason = item.reason || '未标明原因';
    const product = item.topProduct || '需补充商品';
    let action = '补充售后备注和客服记录，确认真实退款触发点。';
    if (/尺码|大小|规格|尺寸|型号/.test(reason)) action = '把规格/尺码/尺寸前置到主图和详情首屏，客服下单前二次确认。';
    else if (/质量|破损|瑕疵|坏|漏|碎/.test(reason)) action = '核查供应链、包装和质检批次，先暂停放大高风险 SKU。';
    else if (/效果|功效|口味|不好吃|不符|描述/.test(reason)) action = '修正页面承诺和卖点证据，降低过度承诺带来的预期落差。';
    else if (/发货|物流|慢|未收到/.test(reason)) action = '检查发货时效、仓配承诺和客服安抚话术，活动期单独设预警。';
    else if (/拍错|不想要|无理由/.test(reason)) action = '优化规格默认项、优惠表达和下单确认，减少误拍与冲动退款。';
    return {
      reason,
      refundAmount: item.refundAmount || 0,
      refundOrders: item.refundOrders || item.rows || 0,
      share,
      topProduct: product,
      diagnosis: `${reason}集中在 ${product}，${share ? `占已识别退款金额 ${percent(share, 1)}` : '需要继续补充金额口径'}。${category.refund}`,
      action
    };
  });
}

function refundMatrixHtml(diagnosis) {
  const rows = refundMatrixRows(diagnosis);
  return reportSection('退款原因治理矩阵', `
    <table class="report-table">
      <thead><tr><th>退款原因</th><th>退款金额</th><th>退款笔数</th><th>金额占比</th><th>关联商品</th><th>顾问判断</th><th>优先动作</th></tr></thead>
      <tbody>
        ${tableRows(rows, [
          { render: (item) => escapeHtml(item.reason) },
          { render: (item) => item.refundAmount ? yuan(item.refundAmount) : '-' },
          { render: (item) => item.refundOrders ? Math.round(item.refundOrders).toLocaleString('zh-CN') : '-' },
          { render: (item) => item.share ? percent(item.share, 1) : '-' },
          { render: (item) => escapeHtml(item.topProduct) },
          { render: (item) => escapeHtml(item.diagnosis) },
          { render: (item) => escapeHtml(item.action) }
        ], '暂无退款原因明细')}
      </tbody>
    </table>
  `);
}

function categoryHtml(items) {
  const rows = items || [];
  const top = [...rows].sort((a, b) => (b.sales || 0) - (a.sales || 0))[0];
  const emptyTraffic = rows.filter((item) => (item.visitors || 0) > 0 && !(item.sales || 0)).length;
  return reportSection('品类/类目排行', `
    ${reportModuleInsight(
      top ? `${top.name || '头部类目'} 是当前主要成交类目，需要判断是否与主推货盘一致。` : '暂未识别到有效品类/类目数据。',
      top ? `头部类目支付金额 ${yuan(top.sales || 0)}，访客 ${Math.round(top.visitors || 0).toLocaleString('zh-CN')}，转化 ${percent(top.conversion || 0)}` : '建议补充标准类目或品类明细。',
      emptyTraffic ? `${emptyTraffic} 个类目存在访客但无成交，优先检查货盘匹配和入口承接。` : '围绕头部类目继续拆主推 SKU、价格带、内容素材和退款原因。'
    )}
    <table class="report-table">
      <thead><tr><th>类目</th><th>支付金额</th><th>访客</th><th>支付买家</th><th>转化率</th><th>退款金额</th><th>判断</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => Math.round(item.visitors || 0).toLocaleString('zh-CN') },
          { render: (item) => Math.round(item.orders || 0).toLocaleString('zh-CN') },
          { render: (item) => percent(item.conversion || 0) },
          { render: (item) => item.refundAmount ? yuan(item.refundAmount) : '-' },
          { render: (item) => escapeHtml(categoryDiagnosis(item, rows)) }
        ], '暂无类目明细')}
      </tbody>
    </table>
  `);
}

function categoryDiagnosis(item, peers = []) {
  const sales = Number(item.sales || 0);
  const visitors = Number(item.visitors || 0);
  const conversion = Number(item.conversion || 0);
  const refundAmount = Number(item.refundAmount || 0);
  const medianSales = median((peers || []).map((row) => Number(row.sales || 0)));
  if (refundAmount > sales && sales > 0) return '退款高于本期成交，需核查是否为历史订单退款。';
  if (refundAmount >= Math.max(sales * 0.12, 1000)) return '类目成交有贡献但退款偏高，先拆退款原因和关联 SKU。';
  if (sales >= Math.max(medianSales * 1.4, 1000) && conversion >= 1) return '当前核心成交类目，建议继续围绕主推 SKU 和价格带做资源聚焦。';
  if (visitors > 0 && !sales) return '有流量无成交，需检查入口商品、价格带和首屏卖点匹配。';
  if (visitors >= 300 && conversion < 0.8) return '类目承接偏弱，建议补主图、详情页和客服高频异议。';
  if (!weakTableNote(item.note)) return item.note;
  return '需结合类目内 SKU、加购、退款和复购数据进一步判断。';
}

function liveHtml(items) {
  const rows = items || [];
  const top = [...rows].sort((a, b) => (b.sales || 0) - (a.sales || 0))[0];
  const weakClick = rows.filter((item) => (item.liveVisitors || item.visitors || 0) > 0 && (item.liveClickRate || 0) > 0 && (item.liveClickRate || 0) < 3).length;
  return reportSection('直播业绩诊断', `
    ${reportModuleInsight(
      top ? `直播成交集中在 ${top.name || '头部场次'}，需判断是观看不足还是点击/成交承接不足。` : '暂未识别到直播明细。',
      top ? `最高成交 ${yuan(top.sales || 0)}，观看 ${Math.round(top.liveVisitors || top.visitors || 0).toLocaleString('zh-CN')}，商品点击率 ${top.liveClickRate ? percent(top.liveClickRate) : '待补充'}` : '建议补充直播观看、商品点击、播中成交和播后成交。',
      weakClick ? '优先优化讲解顺序、购物车引导和利益点表达。' : '把成交较好的场次沉淀为直播脚本和货盘排序模板。'
    )}
    <table class="report-table">
      <thead><tr><th>直播/日期</th><th>成交金额</th><th>观看人数</th><th>商品点击</th><th>观看点击率</th><th>成交人数/笔数</th><th>开播时长</th><th>判断</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => Math.round(item.liveVisitors || item.visitors || 0).toLocaleString('zh-CN') },
          { render: (item) => item.liveClickUsers ? Math.round(item.liveClickUsers).toLocaleString('zh-CN') : '-' },
          { render: (item) => item.liveClickRate ? percent(item.liveClickRate) : '-' },
          { render: (item) => Math.round(item.orders || 0).toLocaleString('zh-CN') },
          { render: (item) => item.liveHours ? Number(item.liveHours).toFixed(1) : '-' },
          { render: (item) => item.liveVisitors && item.liveClickRate < 3 ? '直播看点到商品点击偏弱，需优化讲解和货盘' : item.sales ? '已有直播成交，建议复盘货盘与讲解节奏' : '需继续补充直播成交数据' }
        ], '暂无直播明细')}
      </tbody>
    </table>
  `);
}

function contentHtml(items) {
  const rows = items || [];
  const top = [...rows].sort((a, b) => (b.sales || 0) - (a.sales || 0))[0];
  const exposureOnly = rows.filter((item) => (item.visitors || item.contentVisitors || item.shortVideoVisitors || 0) > 0 && !(item.sales || 0)).length;
  return reportSection('内容资产诊断', `
    ${reportModuleInsight(
      top ? `${top.name || '头部内容'} 已形成成交贡献，适合提炼素材方向。` : '内容数据暂未形成明确成交贡献。',
      top ? `内容成交 ${yuan(top.sales || 0)}，浏览/曝光 ${Math.round(top.visitors || top.contentVisitors || top.shortVideoVisitors || 0).toLocaleString('zh-CN')}` : `${exposureOnly} 条内容偏曝光/互动，成交链路仍需验证。`,
      '把高互动内容与高转化 SKU、主动回访和客服话术串联，形成种草到成交闭环。'
    )}
    <table class="report-table">
      <thead><tr><th>内容资产</th><th>成交金额</th><th>曝光/浏览</th><th>点击/互动</th><th>成交</th><th>转化率</th><th>判断</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => item.sales ? yuan(item.sales) : '-' },
          { render: (item) => Math.round(item.visitors || item.contentVisitors || item.shortVideoVisitors || 0).toLocaleString('zh-CN') },
          { render: (item) => Math.round(item.clicks || item.liveClickUsers || item.addCarts || 0).toLocaleString('zh-CN') },
          { render: (item) => Math.round(item.orders || 0).toLocaleString('zh-CN') },
          { render: (item) => item.conversion ? percent(item.conversion) : '-' },
          { render: (item) => item.sales ? '内容已有成交贡献，建议沉淀可复用素材方向' : '内容偏曝光/互动，需看引导进店和成交链路' }
        ], '暂无内容资产明细')}
      </tbody>
    </table>
  `);
}

function serviceDetailHtml(items) {
  const rows = items || [];
  const refundTop = [...rows].sort((a, b) => (b.refundAmount || 0) - (a.refundAmount || 0))[0];
  const lowConversion = rows.filter((item) => (item.visitors || 0) >= 500 && (item.conversion || 0) > 0 && (item.conversion || 0) < 1).length;
  return reportSection('客服绩效诊断', `
    ${reportModuleInsight(
      lowConversion ? '客服承接偏弱，不能只看接待量，需要复盘咨询到成交的关键断点。' : '客服数据已可用于辅助判断售前承接和售后风险。',
      refundTop?.refundAmount ? `退款最高项 ${formatGroupLabel(refundTop.name)}，退款金额 ${yuan(refundTop.refundAmount)}` : '建议补充响应时长、询单人数、催付成交和客服维度退款。',
      '把高频咨询问题、退款原因和页面承诺打通，形成售前预期管理话术。'
    )}
    <table class="report-table">
      <thead><tr><th>客服/日期</th><th>咨询/接待</th><th>成交金额</th><th>成交人数/笔数</th><th>转化/响应</th><th>退款金额</th><th>判断</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(formatGroupLabel(item.name)) },
          { render: (item) => Math.round(item.visitors || 0).toLocaleString('zh-CN') },
          { render: (item) => item.sales ? yuan(item.sales) : '-' },
          { render: (item) => Math.round(item.orders || 0).toLocaleString('zh-CN') },
          { render: (item) => item.conversion ? percent(item.conversion) : '-' },
          { render: (item) => item.refundAmount ? yuan(item.refundAmount) : '-' },
          { render: (item) => escapeHtml(serviceDiagnosis(item)) }
        ], '暂无客服绩效明细')}
      </tbody>
    </table>
  `);
}

function serviceDiagnosis(item) {
  const name = String(item.name || '');
  const conversion = item.conversion || 0;
  const refundAmount = item.refundAmount || 0;
  const sales = item.sales || 0;
  const visitors = item.visitors || 0;
  const orders = item.orders || 0;
  if (/平均/.test(name)) return '仅作均值参考，不作为单日客服表现判断';
  if (/汇总/.test(name) && refundAmount > Math.max(sales * 0.2, 1000)) return '整体退款侵蚀偏高，需按客服/日期拆退款原因';
  if (sales > 0 && orders <= 0) return '成交金额有记录但成交人数为0，需核对客服绩效字段口径';
  if (refundAmount > sales && sales > 0) return '退款高于成交，疑似历史订单退款，先核查售后归属';
  if (refundAmount > Math.max(sales * 0.25, 1000)) return '退款侵蚀明显，优先复盘售前承诺和售后安抚话术';
  if (visitors >= 1000 && conversion < 0.8) return '接待量较大但询单转化偏弱，需抽查响应时长和异议处理';
  if (conversion > 0 && conversion < 1) return '询单承接偏弱，需复盘高频问题、报价和催付话术';
  if (conversion >= 1.2 && refundAmount <= Math.max(sales * 0.12, 500)) return '承接效率相对健康，可沉淀为客服话术样板';
  if (orders >= 10 && refundAmount > 0) return '有成交也有退款，需把退款原因回写到售前提醒';
  if (visitors > 0 && !orders) return '有接待无成交，需核查咨询问题是否集中在价格/规格/发货';
  return '数据不足，建议补响应时长、询单人数和客服维度退款原因';
}

function trafficHtml(items) {
  const rows = items || [];
  const top = [...rows].sort((a, b) => (b.sales || 0) - (a.sales || 0))[0];
  const weak = rows.filter((item) => (item.visitors || 0) >= 1000 && (item.conversion || 0) < 1).length;
  return reportSection('流量排行', `
    ${reportModuleInsight(
      top ? `${top.name || '头部来源'} 是本周期主要成交入口，需判断是否可复制到其他入口。` : '暂未识别到有效流量来源明细。',
      top ? `支付金额 ${yuan(top.sales || 0)}，访客 ${Math.round(top.visitors || 0).toLocaleString('zh-CN')}，转化 ${percent(top.conversion || 0)}` : '建议补充无线店铺流量来源或流量总览。',
      weak ? `${weak} 个入口存在大流量低转化，先优化承接页和商品匹配，不建议直接扩量。` : '保留高意向入口，低效率入口补加购、跳失和承接页面数据再判断。'
    )}
    <table class="report-table">
      <thead><tr><th>流量来源</th><th>支付金额</th><th>访客</th><th>转化率</th><th>UV价值</th><th>经营判断</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => Math.round(item.visitors || 0).toLocaleString('zh-CN') },
          { render: (item) => percent(item.conversion || 0) },
          { render: (item) => item.uvValue ? item.uvValue.toFixed(2) : item.visitors ? (item.sales / item.visitors).toFixed(2) : '-' },
          { render: (item) => escapeHtml(trafficDiagnosis(item)) }
        ])}
      </tbody>
    </table>
  `);
}

function trafficDiagnosis(item) {
  const name = String(item.name || '');
  const visitors = item.visitors || 0;
  const sales = item.sales || 0;
  const conversion = item.conversion || 0;
  const uvValue = item.uvValue || (visitors ? sales / visitors : 0);
  if (/购物车|我的淘宝|收藏|站内沟通|消息|主动回访|老客/.test(name)) {
    if (conversion >= 5 || uvValue >= 20) return '高意向/私域入口，优先做催付、回访和复购承接';
    return '私域入口有价值但成交弱，需优化触达话术和利益点';
  }
  if (/无界|万相台|直通车|引力魔方|付费|推广/.test(name)) {
    if (visitors >= 1000 && conversion < 1) return '付费流量大但转化弱，先控预算并排查落地页';
    if (conversion >= 3 && uvValue >= 5) return '付费质量可用，可保留预算并小幅测试扩量';
    return '付费入口需结合花费和ROI判断，不建议只按访客放量';
  }
  if (/推荐|猜你喜欢|手淘推荐/.test(name)) {
    if (conversion < 1) return '推荐流量承接偏弱，优先优化首图点击后的详情页';
    return '推荐流量可保留，需持续测试内容素材和主推款';
  }
  if (/搜索|关键词/.test(name)) {
    if (conversion >= 3) return '搜索成交意图较强，优先保核心词排名和主推款库存';
    return '搜索有流量但成交弱，需核查标题词与页面卖点是否匹配';
  }
  if (visitors >= 1000 && conversion < 1) return '流量规模大但成交弱，先查来源质量和承接页';
  if (sales >= 5000 && conversion >= 2) return '成交贡献较好，可作为重点流量入口维护';
  if (uvValue >= 20) return 'UV价值较高，适合优先承接高客单商品或老客链路';
  if (sales > 0 && visitors < 200) return '小流量有成交，可补内容或搜索入口做验证';
  return item.note || '需补来源层级、加购和跳失数据后判断';
}

function promotionHtml(items) {
  const totalSpend = (items || []).reduce((sum, item) => sum + (item.spend || 0), 0);
  const totalSales = (items || []).reduce((sum, item) => sum + (item.sales || 0), 0);
  const totalImpressions = (items || []).reduce((sum, item) => sum + (item.impressions || 0), 0);
  const totalClicks = (items || []).reduce((sum, item) => sum + (item.clicks || 0), 0);
  const totalOrders = (items || []).reduce((sum, item) => sum + (item.orders || 0), 0);
  const overallRoi = totalSpend ? totalSales / totalSpend : 0;
  const overallCtr = totalImpressions ? totalClicks / totalImpressions * 100 : 0;
  const overallCpc = totalClicks ? totalSpend / totalClicks : 0;
  const overallClickConversion = totalClicks ? totalOrders / totalClicks * 100 : 0;
  const best = [...(items || [])].filter((item) => item.spend && item.sales).sort((a, b) => (b.sales / b.spend) - (a.sales / a.spend))[0];
  const worst = [...(items || [])].filter((item) => item.spend).sort((a, b) => (a.roi || (a.spend ? a.sales / a.spend : 0)) - (b.roi || (b.spend ? b.sales / b.spend : 0)))[0];
  return reportSection('推广投放表现（含计划报表专项分析）', `
    ${reportModuleInsight(
      totalSpend ? `本期推广需先判断投放质量，再决定预算调整。整体ROI为 ${overallRoi ? overallRoi.toFixed(2) : '待补充'}。` : '暂未识别到推广计划级花费和成交。',
      totalSpend ? `花费 ${yuan(totalSpend)}，成交 ${yuan(totalSales)}，点击 ${totalClicks ? Math.round(totalClicks).toLocaleString('zh-CN') : '待补充'}，点击转化 ${overallClickConversion ? percent(overallClickConversion) : '待补充'}` : '建议补充计划报表、关键词/创意/单元报表。',
      worst ? `先处理 ${worst.name || '低效计划'} 的人群、关键词、出价或落地页，再考虑放大预算。` : '有ROI但缺点击和加购时，不建议只按ROI加预算。'
    )}
    <div class="summary-grid compact">
      <section><span>总花费</span><strong>${totalSpend ? yuan(totalSpend) : '-'}</strong><p>计划报表合计</p></section>
      <section><span>总成交金额</span><strong>${totalSales ? yuan(totalSales) : '-'}</strong><p>推广带来支付金额</p></section>
      <section><span>整体ROI</span><strong>${overallRoi ? overallRoi.toFixed(2) : '-'}</strong><p>按成交/花费测算</p></section>
      <section><span>点击 / CTR</span><strong>${totalClicks ? Math.round(totalClicks).toLocaleString('zh-CN') : '-'} / ${overallCtr ? percent(overallCtr) : '-'}</strong><p>CPC ${overallCpc ? yuan(overallCpc) : '-'}</p></section>
    </div>
    <p class="report-note">投放建议：先看净销售和退款，再决定是否放量。${totalSpend ? `本期识别推广花费 ${yuan(totalSpend)}，带来成交 ${yuan(totalSales)}，整体ROI ${overallRoi.toFixed(2)}，点击转化率 ${overallClickConversion ? percent(overallClickConversion) : '待补充'}。` : ''}${best ? `效率较好的计划是 ${escapeHtml(best.name || '高效计划')}，可优先保留并小幅倾斜预算。` : ''}${worst && worst !== best ? `低效计划是 ${escapeHtml(worst.name || '低效计划')}，建议先收窄人群/关键词/出价，再考虑放量。` : ''}</p>
    <table class="report-table">
      <thead><tr><th>推广计划/渠道</th><th>花费</th><th>带来支付金额</th><th>ROI</th><th>展现/点击</th><th>点击率</th><th>点击转化率</th><th>加购</th><th>经营判断</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => yuan(item.spend || 0) },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => item.roi ? Number(item.roi).toFixed(2) : '-' },
          { render: (item) => `${item.impressions ? Math.round(item.impressions).toLocaleString('zh-CN') : '-'} / ${item.clicks ? Math.round(item.clicks).toLocaleString('zh-CN') : '-'}` },
          { render: (item) => item.impressions && item.clicks ? percent(item.clicks / item.impressions * 100) : '-' },
          { render: (item) => item.clicks && item.orders ? percent(item.orders / item.clicks * 100) : item.conversion ? percent(item.conversion) : '-' },
          { render: (item) => item.addCarts ? Math.round(item.addCarts).toLocaleString('zh-CN') : '-' },
          { render: (item) => escapeHtml(promotionPlanDiagnosis(item)) }
        ])}
      </tbody>
    </table>
  `);
}

function promotionPlanDiagnosis(item) {
  const spend = Number(item.spend || 0);
  const sales = Number(item.sales || 0);
  const roi = Number(item.roi || (spend ? sales / spend : 0));
  const impressions = Number(item.impressions || 0);
  const clicks = Number(item.clicks || 0);
  const orders = Number(item.orders || 0);
  const ctr = impressions ? clicks / impressions * 100 : 0;
  const clickCvr = clicks ? orders / clicks * 100 : 0;
  if (spend && !sales) return '有花费无成交，建议暂停或降低预算，先排查关键词、人群和承接页。';
  if (roi >= 4 && ctr > 0 && ctr < 0.5) return 'ROI较高但点击率偏低，可能依赖高意向人群，适合稳投不宜盲目扩量。';
  if (roi >= 3 && clickCvr >= 2) return '成交效率较好，可保留预算并小幅测试扩量，需同步观察退款和加购。';
  if (roi > 0 && roi < 1.5 && spend >= 200) return '低ROI计划，优先收窄关键词/人群、降低出价或暂停低效词包。';
  if (clicks >= 300 && clickCvr > 0 && clickCvr < 1) return '点击较多但成交承接弱，优先优化落地页、主推款和价格理由。';
  if (!weakTableNote(item.note)) return item.note;
  return '需结合点击率、点击成交转化率、加购和退款后再判断预算方向。';
}

function activityHtml(items) {
  return reportSection('活动情况', `
    <table class="report-table">
      <thead><tr><th>活动/动作</th><th>成交金额</th><th>访客</th><th>订单</th><th>判断/下步</th></tr></thead>
      <tbody>
        ${tableRows(items, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => item.sales ? yuan(item.sales) : '-' },
          { render: (item) => item.visitors ? Math.round(item.visitors).toLocaleString('zh-CN') : '-' },
          { render: (item) => item.orders ? Math.round(item.orders).toLocaleString('zh-CN') : '-' },
          { render: (item) => escapeHtml(item.note || '-') }
        ])}
      </tbody>
    </table>
  `);
}

function chartRows(items, options = {}) {
  const rows = (items || []).filter((item) => item && item.name && Number.isFinite(Number(item.value)));
  const max = Math.max(...rows.map((item) => Math.abs(Number(item.value) || 0)), 1);
  const format = options.format || ((value) => value.toLocaleString('zh-CN'));
  return rows.map((item) => {
    const value = Number(item.value) || 0;
    const width = Math.max(3, Math.min(100, Math.abs(value) / max * 100));
    const color = item.color || options.color || '#2563eb';
    return `
      <div class="chart-row">
        <div class="chart-row-head"><span>${escapeHtml(item.name)}</span><strong>${escapeHtml(format(value, item))}</strong></div>
        <div class="chart-bar"><i style="width:${width.toFixed(1)}%;background:${color}"></i></div>
        ${item.note ? `<p>${escapeHtml(item.note)}</p>` : ''}
      </div>
    `;
  }).join('') || '<p class="empty-text">暂无可绘制数据</p>';
}

function stackedTrafficChart(data) {
  const items = [
    { name: '搜索', value: data.searchShare || 0, color: '#2563eb' },
    { name: '推荐', value: data.recommendShare || 0, color: '#16a34a' },
    { name: '内容', value: data.contentShare || 0, color: '#7c3aed' },
    { name: '付费', value: data.paidShare || 0, color: '#f97316' },
    { name: '私域', value: data.privateShare || 0, color: '#0f766e' }
  ].filter((item) => item.value > 0);
  const total = items.reduce((sum, item) => sum + item.value, 0) || 1;
  const stack = items.map((item) => `<i title="${escapeHtml(item.name)} ${percent(item.value, 1)}" style="width:${Math.max(2, item.value / total * 100).toFixed(1)}%;background:${item.color}"></i>`).join('');
  const legend = items.map((item) => `<span><b style="background:${item.color}"></b>${escapeHtml(item.name)} ${percent(item.value, 1)}</span>`).join('');
  return `<div class="stacked-chart">${stack}</div><div class="chart-legend">${legend || '<span>暂无渠道结构数据</span>'}</div>`;
}

function chartCard(title, body, note = '') {
  return `
    <section class="chart-card">
      <h5>${escapeHtml(title)}</h5>
      ${body}
      ${note ? `<p class="chart-note">${escapeHtml(note)}</p>` : ''}
    </section>
  `;
}

function visualKpiCard(label, value, note, color, ratio) {
  const width = Math.max(4, Math.min(100, Number.isFinite(ratio) ? ratio : 0));
  return `
    <section class="visual-kpi-card" style="--accent:${color}">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
      <i><b style="width:${width.toFixed(1)}%"></b></i>
      <p>${escapeHtml(note)}</p>
    </section>
  `;
}

function reportVisualSummaryHtml(diagnosis) {
  const data = diagnosis.data;
  const refundAmount = refundAmountValue(data);
  const netSales = netSalesValue(data);
  const activeReturn = activeReturnSignal(data);
  const maxAmount = Math.max(data.sales || 0, refundAmount || 0, netSales || 0, activeReturn.sales || 0, 1);
  const salesChange = data.prevSales ? ((data.sales - data.prevSales) / data.prevSales * 100) : 0;
  const visitorChange = data.prevVisitors ? ((data.visitors - data.prevVisitors) / data.prevVisitors * 100) : 0;
  return `
    <section class="visual-summary">
      <div class="visual-score">
        <div class="visual-score-ring" style="--score:${Math.max(0, Math.min(100, diagnosis.totalScore || 0))}">
          <strong>${diagnosis.totalScore}</strong>
          <span>健康度</span>
        </div>
        <p>${escapeHtml(brandOneSentence(diagnosis))}</p>
      </div>
      <div class="visual-kpis">
        ${visualKpiCard('支付金额', yuan(data.sales || 0), data.prevSales ? `较对比期 ${salesChange >= 0 ? '+' : ''}${salesChange.toFixed(1)}%` : '对比期待补充', '#2563eb', (data.sales || 0) / maxAmount * 100)}
        ${visualKpiCard('净销售额', yuan(netSales || 0), refundAmount ? `已扣减退款 ${yuan(refundAmount)}` : '退款金额待补充', '#16a34a', (netSales || 0) / maxAmount * 100)}
        ${visualKpiCard('成功退款金额', refundAmount ? yuan(refundAmount) : '待补充', refundAmount ? '需结合历史订单退款判断' : '建议补充退款明细', '#dc2626', (refundAmount || 0) / maxAmount * 100)}
        ${visualKpiCard('访客 / 转化', `${Math.round(data.visitors || 0).toLocaleString('zh-CN')} / ${percent(data.conversion || 0)}`, data.prevVisitors ? `访客变化 ${visitorChange >= 0 ? '+' : ''}${visitorChange.toFixed(1)}%` : '流量对比待补充', '#7c3aed', Math.min(100, (data.conversion || 0) / 5 * 100))}
        ${visualKpiCard('主动回访', activeReturn.sales ? yuan(activeReturn.sales) : '待补充', activeReturn.sales ? `转化率 ${percent(activeReturn.conversion || 0)}` : '可补充老客/回访数据', '#0f766e', (activeReturn.sales || 0) / maxAmount * 100)}
      </div>
    </section>
  `;
}

function chartSnapshotHtml(diagnosis) {
  const data = diagnosis.data;
  const details = data.importedDetails || {};
  const weekly = diagnosis.weeklySections || {};
  const refundAmount = refundAmountValue(data);
  const netSales = netSalesValue(data);
  const productRows = (details.products?.length ? details.products : weekly.products || [])
    .slice(0, 8)
    .map((item) => ({
      name: item.name || '-',
      value: item.sales || 0,
      color: (item.refundAmount || 0) > Math.max((item.sales || 0) * 0.08, 0) ? '#dc2626' : '#2563eb',
      note: item.refundAmount ? `退款 ${yuan(item.refundAmount)}${item.refundRate ? `，退款率 ${percent(item.refundRate)}` : ''}` : ''
    }));
  const promotionRows = (details.promotion?.length ? details.promotion : weekly.promotion || [])
    .slice(0, 8)
    .map((item) => ({
      name: item.name || '-',
      value: item.roi || 0,
      color: (item.roi || 0) >= 3 ? '#16a34a' : (item.roi || 0) > 0 ? '#f97316' : '#94a3b8',
      note: `${item.spend ? `花费 ${yuan(item.spend)}，` : ''}${item.sales ? `成交 ${yuan(item.sales)}` : '成交待补充'}`
    }));
  const dailyRows = (details.daily || [])
    .slice(0, 10)
    .map((item) => ({
      name: item.date || item.name || '-',
      value: item.sales || 0,
      color: item.refundAmount > Math.max((item.sales || 0) * 0.18, 0) ? '#dc2626' : '#2563eb',
      note: item.refundAmount ? `退款 ${yuan(item.refundAmount)}，净销售额 ${yuan(item.netSales || Math.max(0, (item.sales || 0) - item.refundAmount))}` : ''
    }));
  return reportSection('图表快照', `
    <div class="chart-grid">
      ${chartCard('支付 / 退款 / 净销售额', chartRows([
        { name: '支付金额', value: data.sales || 0, color: '#2563eb' },
        { name: '成功退款金额', value: refundAmount || 0, color: '#dc2626' },
        { name: '净销售额', value: netSales || 0, color: '#16a34a' }
      ], { format: (value) => yuan(value) }), '用于区分成交规模与真实经营质量，避免只看支付增长。')}
      ${chartCard('流量来源结构', stackedTrafficChart(data), '按搜索、推荐、内容、付费、私域归类，后续可接入更细来源层级。')}
      ${chartCard('单日销售趋势', chartRows(dailyRows, { format: (value) => yuan(value), color: '#2563eb' }), '每个柱子代表统计周期内某一天的支付金额；同行同层、全店平均等平台参考值不计入单日趋势。')}
      ${chartCard('商品 TOP 销售与退款风险', chartRows(productRows, { format: (value) => yuan(value), color: '#2563eb' }), '红色条目表示销售贡献同时存在退款风险，需要优先核查页面与客服预期管理。')}
      ${chartCard('推广计划 ROI', chartRows(promotionRows, { format: (value) => value ? Number(value).toFixed(2) : '-', color: '#16a34a' }), '不按 ROI 直接加预算，需结合点击率、点击转化率、加购和退款承接判断。')}
    </div>
  `);
}

function leverageHtml(diagnosis) {
  return reportSection('经营杠杆拆解', `
    <table class="report-table">
      <thead><tr><th>项目</th><th>测算结果</th><th>顾问判断</th></tr></thead>
      <tbody>
        <tr><td>销售缺口</td><td>${yuan(diagnosis.decomposition.salesGap)}</td><td>${diagnosis.decomposition.salesGap < 0 ? '需要先定位拖累项' : '销售较对比周期增长'}</td></tr>
        <tr><td>流量影响</td><td>${yuan(diagnosis.decomposition.trafficImpact)}</td><td>按上期转化率和客单价测算</td></tr>
        <tr><td>转化影响</td><td>${yuan(diagnosis.decomposition.conversionImpact)}</td><td>按本期访客和上期客单价测算</td></tr>
        <tr><td>客单影响</td><td>${yuan(diagnosis.decomposition.aovImpact)}</td><td>用于判断商品结构和价格带变化</td></tr>
      </tbody>
    </table>
  `);
}

function showReportRenderPlaceholder(diagnosis) {
  const paper = $('#reportPaper');
  if (!paper) return;
  $('#reportTime').textContent = '正在生成：' + diagnosis.createdAt;
  paper.innerHTML = `
    <div class="report-render-loading">
      <strong>正在生成${getReportName(diagnosis)}</strong>
      <p>系统正在组装图表、经营结论、补数建议和微信群话术。数据量较大时请稍候，页面仍会持续更新进度。</p>
      <i><em></em></i>
    </div>
  `;
}

function renderReport(diagnosis) {
  const { data } = diagnosis;
  const reportName = getReportName(diagnosis);
  const weekly = diagnosis.weeklySections;
  const boss = executiveSummary(diagnosis);
  const quality = diagnosis.dataQuality;
  const targetPlan = diagnosis.targetPlan || buildTargetPlan(data, diagnosis.issues || [], diagnosis.decomposition || gapDecomposition(data), getBenchmark(data.industry));
  const state = reportModuleState(diagnosis);
  const details = data.importedDetails || {};
  const dynamicSections = [];
  const auditSections = [
    reportOutlineHtml(diagnosis),
    categoryDirectionHtml(diagnosis),
    state.importSummary ? importSummaryHtml(diagnosis) : '',
    state.lineage ? lineageHtml(diagnosis) : '',
    state.confidence ? dataConfidenceHtml(diagnosis) : '',
    state.aux ? reportSection('流量与客户辅助诊断', `<ul>${auxiliaryDiagnosis(diagnosis).map((item) => `<li>${item}</li>`).join('')}</ul>`) : '',
    state.target ? targetPlanHtml(targetPlan) : ''
  ].filter(Boolean);
  if (state.overall) dynamicSections.push(overallHtml(diagnosis));
  dynamicSections.push(chartSnapshotHtml(diagnosis));
  if (state.daily) dynamicSections.push(dailyHtml(details.daily));
  if (state.product) dynamicSections.push(productHtml(state.imported ? details.products : weekly.products));
  if (state.category) dynamicSections.push(categoryHtml(details.categories));
  if (state.skuQuadrant) dynamicSections.push(skuQuadrantHtml(diagnosis));
  if (state.refundMatrix) dynamicSections.push(refundMatrixHtml(diagnosis));
  if (state.live) dynamicSections.push(liveHtml(details.live));
  if (state.content) dynamicSections.push(contentHtml(details.content));
  if (state.serviceDetail) dynamicSections.push(serviceDetailHtml(details.service));
  if (state.traffic) dynamicSections.push(trafficHtml(state.imported ? details.traffic : weekly.traffic));
  if (state.promotion) dynamicSections.push(promotionHtml(state.imported ? details.promotion : weekly.promotion));
  if (state.activity) dynamicSections.push(activityHtml(state.imported ? details.activity : weekly.activity));
  if (state.leverage) dynamicSections.push(leverageHtml(diagnosis));
  dynamicSections.push(reportSection('经营数据评分', `
    <table class="report-table">
      <thead><tr><th>指标</th><th>表现</th><th>判断</th><th>评分</th></tr></thead>
      <tbody>
        ${diagnosis.metrics.map((item) => `<tr><td>${item.name}</td><td>${item.value}</td><td>${item.detail}</td><td>${item.score}</td></tr>`).join('')}
      </tbody>
    </table>
  `));
  $('#reportTime').textContent = '最近生成：' + diagnosis.createdAt;
  // Legacy flat preview is intentionally skipped; the visual two-column report below is the active report.
  if (false) $('#reportPaper').innerHTML = `
    ${reportCoverHtml(diagnosis)}
    <div class="report-brand">Pinmoo AI 电商增长智能体</div>
    <h3>${reportName}</h3>
    <div class="report-meta">${data.brandName || data.storeName} · ${data.storeName} · ${data.platform} · ${data.industry} · ${data.period} · ${data.reportPurpose || '品牌方正式版'} · ${data.dataSource || '数据导入'}</div>
    <div class="conclusion-box">
      <strong>核心结论：${diagnosis.summary.title}，综合健康度 ${diagnosis.totalScore} 分</strong>
      <p>${diagnosis.summary.text}</p>
    </div>

    ${reportVisualSummaryHtml(diagnosis)}
    ${deliveryGradeHtml(diagnosis)}
    ${brandLeadHtml(diagnosis)}

    <h4>一、老板先看</h4>
    <div class="boss-summary">
      <section><span>结果</span><p>${boss.result}</p></section>
      <section><span>原因</span><p>${boss.reason}</p></section>
      <section><span>动作</span><p>${boss.action}</p></section>
    </div>

    <h4>二、数据完整度</h4>
    <div class="quality-box">
      <div>
        <strong>${quality.score}分</strong>
        <span>${dataQualityLabel(quality.score)}</span>
      </div>
      <ul>
        ${quality.checks.map((item) => `<li class="${item.ok ? 'ok' : 'missing'}"><b>${item.ok ? '已具备' : '待补充'}</b>${item.name}：${item.ok ? '本报告已读取该模块数据。' : item.tip}</li>`).join('')}
      </ul>
    </div>

    <h4>三、导入文件使用情况</h4>
    <table class="report-table">
      <thead><tr><th>文件</th><th>识别类型</th><th>状态</th><th>使用行数</th><th>使用率</th><th>进入模块</th><th>说明</th></tr></thead>
      <tbody>
        ${tableRows(importSummaryRows(diagnosis), [
          { render: (item) => escapeHtml(item.file || '-') },
          { render: (item) => escapeHtml(item.kindLabel || '-') },
          { render: (item) => escapeHtml(item.status || '-') },
          { render: (item) => escapeHtml(item.rows || '-') },
          { render: (item) => escapeHtml(item.usage || '-') },
          { render: (item) => escapeHtml(item.modules || '-') },
          { render: (item) => escapeHtml(item.note || '-') }
        ], '暂无导入文件明细')}
      </tbody>
    </table>

    <h4>四、流量与客户辅助诊断</h4>
    <ul>${auxiliaryDiagnosis(diagnosis).map((item) => `<li>${item}</li>`).join('')}</ul>

    <h4>五、下周期目标建议</h4>
    <p>${targetPlan.baseline}</p>
    <p>${targetPlan.focus}</p>
    <table class="report-table">
      <thead><tr><th>目标档位</th><th>目标销售额</th><th>较本期</th><th>目标访客</th><th>目标转化率</th><th>目标客单价</th></tr></thead>
      <tbody>
        ${targetPlan.rows.map((item) => `<tr><td>${targetPlan.periodName}${item.level}</td><td>${yuan(item.sales)}</td><td>${item.growth >= 0 ? '+' : ''}${item.growth.toFixed(1)}%</td><td>${item.visitors.toLocaleString('zh-CN')}</td><td>${percent(item.conversion)}</td><td>${yuan(item.aov)}</td></tr>`).join('')}
      </tbody>
    </table>

    <h4>六、店铺整体情况</h4>
    <ul>${operatingSummary(diagnosis).map((item) => `<li>${item}</li>`).join('')}</ul>
    <table class="report-table">
      <thead><tr><th>指标</th><th>本期</th><th>对比期</th><th>变化</th><th>判断</th></tr></thead>
      <tbody>
        ${metricChangeRows(diagnosis).map((item) => `<tr><td>${item.name}</td><td>${item.current}</td><td>${item.previous}</td><td>${item.change}</td><td>${item.judge}</td></tr>`).join('')}
      </tbody>
    </table>
    <table class="report-table">
      <thead><tr><th>模块</th><th>状态</th><th>诊断说明</th></tr></thead>
      <tbody>
        ${moduleDiagnosis(diagnosis).map((item) => `<tr><td>${item.module}</td><td>${item.status}</td><td>${item.detail}</td></tr>`).join('')}
      </tbody>
    </table>

    <h4>七、宝贝排行</h4>
    <table class="report-table">
      <thead><tr><th>宝贝/商品</th><th>销售额</th><th>访客</th><th>订单</th><th>转化率</th><th>判断</th></tr></thead>
      <tbody>
        ${tableRows(weekly.products, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => Math.round(item.visitors || 0).toLocaleString('zh-CN') },
          { render: (item) => Math.round(item.orders || 0).toLocaleString('zh-CN') },
          { render: (item) => percent(item.conversion || 0) },
          { render: (item) => escapeHtml(item.note || '-') }
        ])}
      </tbody>
    </table>

    <h4>八、流量排行</h4>
    <table class="report-table">
      <thead><tr><th>流量来源</th><th>销售额</th><th>访客</th><th>转化率</th><th>判断</th></tr></thead>
      <tbody>
        ${tableRows(weekly.traffic, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => Math.round(item.visitors || 0).toLocaleString('zh-CN') },
          { render: (item) => percent(item.conversion || 0) },
          { render: (item) => escapeHtml(item.note || '-') }
        ])}
      </tbody>
    </table>

    <h4>九、推广情况</h4>
    <table class="report-table">
      <thead><tr><th>推广计划/渠道</th><th>花费</th><th>成交金额</th><th>ROI</th><th>点击</th><th>判断</th></tr></thead>
      <tbody>
        ${tableRows(weekly.promotion, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => yuan(item.spend || 0) },
          { render: (item) => yuan(item.sales || 0) },
          { render: (item) => item.roi ? Number(item.roi).toFixed(2) : '-' },
          { render: (item) => item.clicks ? Math.round(item.clicks).toLocaleString('zh-CN') : '-' },
          { render: (item) => escapeHtml(item.note || '-') }
        ])}
      </tbody>
    </table>

    <h4>十、活动情况</h4>
    <table class="report-table">
      <thead><tr><th>活动/动作</th><th>成交金额</th><th>访客</th><th>订单</th><th>判断/下步</th></tr></thead>
      <tbody>
        ${tableRows(weekly.activity, [
          { render: (item) => escapeHtml(item.name || '-') },
          { render: (item) => item.sales ? yuan(item.sales) : '-' },
          { render: (item) => item.visitors ? Math.round(item.visitors).toLocaleString('zh-CN') : '-' },
          { render: (item) => item.orders ? Math.round(item.orders).toLocaleString('zh-CN') : '-' },
          { render: (item) => escapeHtml(item.note || '-') }
        ])}
      </tbody>
    </table>

    <h4>十一、经营杠杆拆解</h4>
    <table class="report-table">
      <thead><tr><th>项目</th><th>测算结果</th><th>顾问判断</th></tr></thead>
      <tbody>
        <tr><td>销售缺口</td><td>${yuan(diagnosis.decomposition.salesGap)}</td><td>${diagnosis.decomposition.salesGap < 0 ? '需要先定位拖累项' : '销售较对比周期增长'}</td></tr>
        <tr><td>流量影响</td><td>${yuan(diagnosis.decomposition.trafficImpact)}</td><td>按上期转化率和客单价测算</td></tr>
        <tr><td>转化影响</td><td>${yuan(diagnosis.decomposition.conversionImpact)}</td><td>按本期访客和上期客单价测算</td></tr>
        <tr><td>客单影响</td><td>${yuan(diagnosis.decomposition.aovImpact)}</td><td>用于判断商品结构和价格带变化</td></tr>
      </tbody>
    </table>

    <h4>十二、经营数据评分</h4>
    <table class="report-table">
      <thead><tr><th>指标</th><th>表现</th><th>判断</th><th>评分</th></tr></thead>
      <tbody>
        ${diagnosis.metrics.map((item) => `<tr><td>${item.name}</td><td>${item.value}</td><td>${item.detail}</td><td>${item.score}</td></tr>`).join('')}
      </tbody>
    </table>

    <h4>十三、关键问题与优先级</h4>
    <ol class="report-issue-list">
      ${diagnosis.issues.map((item) => `
        <li>
          <strong>[${item.rank}] ${item.title}</strong>
          <p>证据：${item.evidence}</p>
          <p>顾问判断：${item.diagnosis}</p>
          <p>下一步：${item.action}</p>
        </li>
      `).join('')}
    </ol>

    <h4>十四、下周期执行计划</h4>
    <div class="report-actions-list">
      ${diagnosis.actions.map((group) => `
        <section>
          <strong>${group.period}：${group.title}</strong>
          <ul>${group.tasks.map((task) => `<li>${task}</li>`).join('')}</ul>
        </section>
      `).join('')}
    </div>

    <h4>十五、需要品牌方/运营进一步确认的问题</h4>
    <ol>${confirmationQuestions(diagnosis).map((item) => `<li>${item.replace(/^\d+\.\s*/, '')}</li>`).join('')}</ol>

    <h4>十六、需要补充的数据</h4>
    ${missingDataGuideHtml(diagnosis)}

    <h4>十七、顾问备注</h4>
    <p>${escapeHtml(data.notes || '暂无补充说明。')}</p>
  `;
  $('#reportPaper').innerHTML = `
    ${reportCoverHtml(diagnosis)}
    ${reportVisualSummaryHtml(diagnosis)}
    ${deliveryGradeHtml(diagnosis)}

    <div class="report-layout">
      <main class="report-main">
        ${brandLeadHtml(diagnosis)}

        <h4>一、老板先看</h4>
        <div class="boss-summary">
          <section><span>结果</span><p>${boss.result}</p></section>
          <section><span>原因</span><p>${boss.reason}</p></section>
          <section><span>动作</span><p>${boss.action}</p></section>
        </div>

        ${dynamicSections.join('')}

    <h4>经营异常雷达</h4>
    <ol class="report-issue-list">
      ${diagnosis.issues.map((item) => `
        <li>
          <strong>[${item.rank}] ${item.title}</strong>
          <p>证据：${item.evidence}</p>
          <p>顾问判断：${item.diagnosis}</p>
          <p>下一步：${item.action}</p>
        </li>
      `).join('')}
    </ol>

    <h4>经营行动台账</h4>
    ${actionLedgerReportHtml(diagnosis)}

    <h4>上期动作验证</h4>
    ${reviewVerificationReportHtml(diagnosis)}

    <h4>下周期作战看板</h4>
    ${actionBoardHtml(diagnosis)}

    <h4>下周期执行计划</h4>
    <div class="report-actions-list">
      ${diagnosis.actions.map((group) => `
        <section>
          <strong>${group.period}：${group.title}</strong>
          <ul>${group.tasks.map((task) => `<li>${task}</li>`).join('')}</ul>
        </section>
      `).join('')}
    </div>

    <h4>微信群发送话术</h4>
    <div class="conclusion-box">
      <p>${wechatShareText(diagnosis).replace(/\n/g, '<br>')}</p>
    </div>

      </main>
      <aside class="report-audit">
        <div class="audit-sticky">
          <section class="audit-priority">
            <h4>需要优先补充的数据</h4>
            <p>如果要让本次报告更接近正式交付，请优先补齐以下数据后重新生成。</p>
            ${missingDataGuideHtml(diagnosis)}
          </section>

          <section class="audit-confirm">
            <h4>需要确认的问题</h4>
            <ol>${confirmationQuestions(diagnosis).map((item) => `<li>${item.replace(/^\d+\.\s*/, '')}</li>`).join('')}</ol>
          </section>

          <h4>交付审计</h4>
          <div class="quality-box audit-quality">
            <div>
              <strong>${quality.score}分</strong>
              <span>${dataQualityLabel(quality.score)}</span>
            </div>
            <ul>
              ${quality.checks.map((item) => `<li class="${item.ok ? 'ok' : 'missing'}"><b>${item.ok ? '已具备' : '待补充'}</b>${item.name}：${item.ok ? '本报告已读取该模块数据。' : item.tip}</li>`).join('')}
            </ul>
          </div>

          ${auditSections.join('')}

          <h4>顾问备注</h4>
          <p>${escapeHtml(data.notes || '暂无补充说明。')}</p>
        </div>
      </aside>
    </div>
  `;
}

function missingDataTips(data) {
  const category = getCategoryStrategy(data.industry);
  const tips = ['分 SKU 销售、访客、转化、退款原因表', '主要渠道入口明细，包括搜索、推荐、内容、活动、付费、私域', 'TOP 商品主图、详情页、评价和客服高频问答'];
  tips.push(`${data.industry}专属校验资料：${category.action}`);
  if (data.roi <= 0) tips.push('投放消耗、成交金额、ROI 和计划维度表现');
  if (data.refundRate > 5) tips.push('售后退款明细，至少按 SKU 和退款原因归类');
  if (data.privateShare < 8) tips.push('会员、老客、沉默客户和复购周期数据');
  return tips;
}

function operatingSummary(diagnosis) {
  const { data } = diagnosis;
  const salesWord = diagnosis.salesTrend.value >= 0 ? '增长' : '下滑';
  const trafficWord = diagnosis.visitorTrend.value >= 0 ? '增长' : '下滑';
  const roiText = data.roi > 0 ? data.roi.toFixed(2) : '未提供';
  return [
    `本期${data.reportType || '报告'}销售额 ${yuan(data.sales)}，较对比周期${salesWord} ${diagnosis.salesTrend.label}。`,
    `访客数 ${Math.round(data.visitors).toLocaleString('zh-CN')}，较对比周期${trafficWord} ${diagnosis.visitorTrend.label}；转化率 ${percent(data.conversion)}，客单价 ${yuan(data.aov)}。`,
    `退款率 ${percent(data.refundRate)}，投放 ROI ${roiText}，商品动销率 ${percent(data.activeProductRate)}。`,
    `本期最需要优先处理的问题是：${diagnosis.issues[0]?.title || '暂无明显短板'}。`
  ];
}

function moduleDiagnosis(diagnosis) {
  const { data } = diagnosis;
  const category = diagnosis.categoryStrategy || getCategoryStrategy(data.industry);
  return [
    {
      module: '店铺经营',
      status: diagnosis.totalScore >= 78 ? '稳定' : diagnosis.totalScore >= 60 ? '可优化' : '承压',
      detail: diagnosis.summary.text
    },
    {
      module: '流量渠道',
      status: data.paidShare >= 28 && data.roi > 0 && data.roi < 3 ? '需控费' : data.contentShare + data.recommendShare >= 35 ? '内容基础较好' : '需补内容',
      detail: `搜索 ${percent(data.searchShare, 1)}、推荐 ${percent(data.recommendShare, 1)}、内容 ${percent(data.contentShare, 1)}、付费 ${percent(data.paidShare, 1)}、私域 ${percent(data.privateShare, 1)}。${category.channel}`
    },
    {
      module: '商品结构',
      status: data.activeProductRate >= 68 ? '动销良好' : '动销不足',
      detail: `有成交商品 ${data.activeProductCount}/${data.productCount}，TOP SKU 销售占比 ${percent(data.topSkuShare, 1)}。${category.product}`
    },
    {
      module: '客服/售后',
      status: data.refundRate > getBenchmark(data.industry).refund ? '退款风险' : data.serviceRate < getBenchmark(data.industry).service ? '承接待加强' : '基本稳定',
      detail: `客服响应达标率 ${percent(data.serviceRate, 1)}，退款率 ${percent(data.refundRate)}。${category.refund}`
    }
  ];
}

function confirmationQuestions(diagnosis) {
  const questions = diagnosis.issues.slice(0, 3).map((item, index) => `${index + 1}. ${item.validation}`);
  if (questions.length < 3) {
    questions.push('补充核心 SKU 的主图、详情页、评价、客服咨询和退款原因，用于做商品级归因。');
  }
  return questions.slice(0, 3);
}

function fallbackProductRanking(data) {
  const mainShare = data.topSkuShare || 0;
  const otherShare = Math.max(0, 100 - mainShare);
  return [
    { name: 'TOP 主推宝贝', sales: data.sales * mainShare / 100, visitors: data.visitors * 0.32, orders: data.orderCount * mainShare / 100, conversion: data.conversion * 1.12, note: mainShare > 60 ? '依赖偏高，需关注库存/退款/评价' : '主推贡献稳定' },
    { name: '第二梯队宝贝', sales: data.sales * otherShare * 0.55 / 100, visitors: data.visitors * 0.28, orders: data.orderCount * otherShare * 0.55 / 100, conversion: data.conversion * 0.92, note: '建议筛选可放量款' },
    { name: '长尾宝贝', sales: data.sales * otherShare * 0.45 / 100, visitors: data.visitors * 0.4, orders: data.orderCount * otherShare * 0.45 / 100, conversion: data.conversion * 0.72, note: data.activeProductRate < 65 ? '动销偏弱，需做货品分层' : '可继续观察' }
  ];
}

function fallbackTrafficRanking(data) {
  return [
    { name: '搜索流量', visitors: data.visitors * data.searchShare / 100, sales: data.sales * data.searchShare / 100, conversion: data.conversion, note: '关注搜索词与商品承接' },
    { name: '推荐流量', visitors: data.visitors * data.recommendShare / 100, sales: data.sales * data.recommendShare / 100, conversion: data.conversion * 0.86, note: '关注点击后转化' },
    { name: '内容流量', visitors: data.visitors * data.contentShare / 100, sales: data.sales * data.contentShare / 100, conversion: data.conversion * 0.78, note: '关注种草到成交链路' },
    { name: '付费流量', visitors: data.visitors * data.paidShare / 100, sales: data.sales * data.paidShare / 100, conversion: data.conversion * 0.94, note: data.roi < 3 ? 'ROI需优化' : '可保留观察' },
    { name: '私域/老客', visitors: data.visitors * data.privateShare / 100, sales: data.sales * data.privateShare / 100, conversion: data.conversion * 1.4, note: data.privateShare < 10 ? '贡献偏弱' : '承接较好' }
  ].filter((item) => item.visitors || item.sales).sort((a, b) => b.sales - a.sales);
}

function fallbackPromotionRanking(data) {
  return [
    { name: '付费推广整体', spend: data.roi ? data.sales * data.paidShare / 100 / data.roi : 0, sales: data.sales * data.paidShare / 100, roi: data.roi, clicks: 0, note: data.roi < 3 ? '需拆计划控费' : '效率可观察' },
    { name: '内容/短视频承接', spend: 0, sales: data.sales * data.contentShare / 100, roi: 0, clicks: 0, note: '需看内容播放、点击、成交明细' }
  ];
}

function fallbackActivityRanking(data) {
  return [
    { name: '平台活动/店铺活动', sales: 0, visitors: 0, orders: 0, note: '导入活动名称和活动成交后可自动排行' },
    { name: '下周期活动准备', sales: 0, visitors: 0, orders: 0, note: '建议记录报名活动、优惠券、满减、直播/内容节奏' }
  ];
}

function buildWeeklySections(data, issues) {
  const details = data.importedDetails || {};
  return {
    products: details.products?.length ? details.products : fallbackProductRanking(data),
    traffic: details.traffic?.length ? details.traffic : fallbackTrafficRanking(data),
    promotion: details.promotion?.length ? details.promotion : fallbackPromotionRanking(data),
    activity: details.activity?.length ? details.activity : fallbackActivityRanking(data),
    nextFocus: issues.slice(0, 3).map((item) => item.action)
  };
}

function buildDataQuality(data) {
  const details = data.importedDetails || {};
  const aux = data.importedAux || {};
  const lineage = data.importedLineage || [];
  const confirmedLineage = lineage.filter((item) => item.status === '已匹配来源字段').length;
  const matchedCoreLineage = lineage.filter((item) => ['sales', 'visitors', 'conversion', 'aov', 'refundRate', 'product', 'traffic'].includes(item.key) && item.status === '已匹配来源字段').length;
  const checks = [
    { key: 'overall', name: '店铺整体', ok: data.sales > 0 && data.visitors > 0, tip: '需要销售额、访客、订单/转化率等大盘数据' },
    { key: 'product', name: '宝贝排行', ok: Boolean(details.products && details.products.length), tip: '建议导入宝贝名称、销售额、访客、订单、转化率' },
    { key: 'category', name: '品类/类目', ok: Boolean(details.categories && details.categories.length), tip: '建议导入品类标准类目，识别类目成交、访客、支付转化和退款金额' },
    { key: 'traffic', name: '流量数据', ok: Boolean((details.traffic && details.traffic.length) || aux.hasTrafficOverview), tip: '建议导入流量来源、访客、成交、转化率，或流量看板总览' },
    { key: 'promotion', name: '推广情况', ok: Boolean(details.promotion && details.promotion.length), tip: '建议导入推广计划、花费、点击、成交、ROI' },
    { key: 'live', name: '直播业绩', ok: Boolean(details.live && details.live.length), tip: '建议导入直播观看、商品点击、成交金额、开播时长和播后成交' },
    { key: 'content', name: '内容资产', ok: Boolean(details.content && details.content.length), tip: '建议导入光合/内容资产曝光、浏览、点击、成交和互动数据' },
    { key: 'serviceDetail', name: '客服绩效', ok: Boolean(details.service && details.service.length), tip: '建议导入客服团队概览、客服绩效或店铺绩效数据' },
    { key: 'activity', name: '活动情况', ok: Boolean(details.activity && details.activity.length), tip: '建议导入活动名称、活动成交、活动访客、订单' },
    { key: 'refund', name: '退款/售后', ok: data.refundRate > 0 || Boolean(data.importSummary?.some((item) => (item.modules || []).includes('退款售后'))), tip: '建议导入退款率、退款金额、退款原因或售后明细' },
    { key: 'lineage', name: '指标口径', ok: !lineage.length || confirmedLineage >= 6, tip: '需要确认销售、访客、转化、客单、退款、渠道等核心指标的来源字段' },
    { key: 'confidence', name: '核心可信度', ok: !lineage.length || matchedCoreLineage >= 5, tip: '销售、访客、转化、客单、退款、商品、渠道至少应有 5 项能追溯来源' }
  ];
  const complete = checks.filter((item) => item.ok).length;
  return {
    score: Math.round(complete / checks.length * 100),
    checks,
    missing: checks.filter((item) => !item.ok)
  };
}

function importSummaryRows(diagnosis) {
  const rows = diagnosis.data.importSummary || [];
  return rows.map((item) => {
    const usageRate = item.rawRows ? item.usedRows / item.rawRows * 100 : 0;
    return {
      file: item.name,
      status: item.status,
      rows: item.rawRows ? `${item.usedRows}/${item.rawRows}` : '-',
      usage: item.rawRows ? percent(usageRate, 1) : '-',
      modules: item.modules?.length ? item.modules.join('、') : '-',
      note: item.note,
      dominantKind: item.dominantKind || 'unknown',
      kindLabel: reportKindLabel(item.dominantKind || 'unknown')
    };
  });
}

function auxiliaryDiagnosis(diagnosis) {
  const aux = diagnosis.data.importedAux || {};
  const rows = [];
  if (aux.hasTrafficOverview) {
    rows.push(`流量总览已读取：访客 ${Math.round(aux.newVisitors + aux.oldVisitors || diagnosis.data.visitors).toLocaleString('zh-CN')}，浏览量 ${Math.round(aux.pageViews || 0).toLocaleString('zh-CN')}，跳失率 ${aux.bounceRate ? percent(aux.bounceRate * (aux.bounceRate <= 1 ? 100 : 1)) : '-'}，平均停留 ${aux.avgStay ? aux.avgStay.toFixed(1) : '-'} 秒。`);
    if (aux.shortVideoVisitors || aux.liveVisitors || aux.storePageVisitors) {
      rows.push(`内容/承接入口：短视频访客 ${Math.round(aux.shortVideoVisitors || 0).toLocaleString('zh-CN')}，直播间访客 ${Math.round(aux.liveVisitors || 0).toLocaleString('zh-CN')}，店铺页访客 ${Math.round(aux.storePageVisitors || 0).toLocaleString('zh-CN')}。`);
    }
  }
  if (aux.hasMemberOverview) {
    rows.push(`客户概况已读取：店铺客户数 ${Math.round(aux.shopCustomers || 0).toLocaleString('zh-CN')}，新访客户 ${Math.round(aux.newVisitors || 0).toLocaleString('zh-CN')}，未购回访 ${Math.round(aux.unpurchasedReturning || 0).toLocaleString('zh-CN')}，已购回访 ${Math.round(aux.purchasedReturning || 0).toLocaleString('zh-CN')}。`);
  }
  if (diagnosis.data.importedDetails?.live?.length) {
    const liveSales = diagnosis.data.importedDetails.live.reduce((sum, item) => sum + (item.sales || 0), 0);
    const liveWatch = diagnosis.data.importedDetails.live.reduce((sum, item) => sum + (item.liveVisitors || item.visitors || 0), 0);
    rows.push(`直播业绩已读取：直播成交 ${yuan(liveSales)}，观看人数 ${Math.round(liveWatch).toLocaleString('zh-CN')}，可继续拆播中/播后成交。`);
  }
  if (diagnosis.data.importedDetails?.content?.length) {
    rows.push(`内容资产已读取：共 ${diagnosis.data.importedDetails.content.length} 条光合/内容记录，可辅助判断内容曝光、互动和成交贡献。`);
  }
  if (diagnosis.data.importedDetails?.service?.length) {
    rows.push(`客服/店铺绩效已读取：共 ${diagnosis.data.importedDetails.service.length} 条绩效记录，可辅助判断询单承接、成交和退款。`);
  }
  if (!rows.length) rows.push('暂未读取到流量总览或客户概况辅助数据。');
  return rows;
}

function tableRows(items, columns, emptyText = '暂无明细数据') {
  if (!items || !items.length) return `<tr><td colspan="${columns.length}">${emptyText}</td></tr>`;
  return items.map((item) => `<tr>${columns.map((column) => `<td>${column.render(item)}</td>`).join('')}</tr>`).join('');
}

function renderHistory() {
  const keyword = $('#historySearch').value.trim().toLowerCase();
  history = Array.isArray(history) ? history.filter((item) => item && item.data) : [];
  const rows = history.filter((item) => {
    const data = item.data || {};
    const text = `${data.storeName || ''} ${data.platform || ''} ${data.industry || ''} ${item.summary?.title || ''} ${item.summary?.text || ''}`.toLowerCase();
    return !keyword || text.includes(keyword);
  });

  $('#historyBody').innerHTML = rows.length ? rows.map((item) => {
    const entries = actionLedger.filter((entry) => actionMatchesDiagnosis(entry, item));
    const total = entries.length || Math.min(3, Array.isArray(item.issues) ? item.issues.length : 0);
    const done = entries.filter((entry) => entry.status === 'done').length;
    return `
    <tr>
      <td class="store-cell"><strong>${item.data.storeName || '-'}</strong><span>${item.data.industry || '-'}</span></td>
      <td>${item.data.platform || '-'}</td>
      <td>${yuan(item.data.sales || 0)}</td>
      <td><span class="score-pill ${scoreClass(item.totalScore || 0)}">${item.totalScore || '-'}</span></td>
      <td><span class="action-progress-pill ${done === total && total ? 'complete' : ''}">${done} / ${total}</span></td>
      <td>${item.createdAt || '-'}</td>
      <td class="row-actions">
        <button type="button" data-load="${item.id}">查看</button>
        <button type="button" data-delete="${item.id}">删除</button>
      </td>
    </tr>
  `;
  }).join('') : '<tr><td colspan="7">暂无经营复盘记录。生成第一份报告后会自动保存在这里。</td></tr>';

  $('#quotaUsed').textContent = history.length;
  $('#quotaBar').style.width = Math.min(100, history.length / 2) + '%';
}

function setLatest(diagnosis, persist = false) {
  latestDiagnosis = diagnosis;
  if (persist) syncActionLedger(diagnosis);
  setReportActionsEnabled(true);
  renderSummary(diagnosis);
  renderHealth(diagnosis);
  renderIssues(diagnosis);
  renderActions(diagnosis);
  renderReviewVerification(diagnosis);
  renderReport(diagnosis);
  if (persist) {
    history = [diagnosis, ...history.filter((item) => item.id !== diagnosis.id)].slice(0, 200);
    const saved = saveHistory();
    if (!saved) toast('报告已生成，但浏览器历史空间不足，建议先导出 Word 留档');
  }
  renderHistory();
}

function scheduleFormRecompute(delay = 220) {
  clearTimeout(formRecomputeTimer);
  formRecomputeTimer = setTimeout(() => {
    if (isImportingFiles || isGeneratingReport) return;
    const data = getFormData();
    if (!hasMeaningfulData(data)) return renderEmptyWorkspace();
    setLatest(analyze(data));
  }, delay);
}

function reportTextLegacy(diagnosis) {
  if (!diagnosis) return '';
  const reportName = getReportName(diagnosis);
  const weekly = diagnosis.weeklySections || {};
  const targetPlan = diagnosis.targetPlan || buildTargetPlan(diagnosis.data, diagnosis.issues || [], diagnosis.decomposition || gapDecomposition(diagnosis.data), getBenchmark(diagnosis.data.industry));
  const state = reportModuleState(diagnosis);
  const details = diagnosis.data.importedDetails || {};
  const outline = adaptiveReportOutline(diagnosis);
  const productItems = state.imported ? details.products || [] : weekly.products || [];
  const dailyItems = details.daily || [];
  const categoryItems = details.categories || [];
  const trafficItems = state.imported ? details.traffic || [] : weekly.traffic || [];
  const promotionItems = state.imported ? details.promotion || [] : weekly.promotion || [];
  const activityItems = state.imported ? details.activity || [] : weekly.activity || [];
  const liveItems = details.live || [];
  const contentItems = details.content || [];
  const serviceItems = details.service || [];
  const refundItems = refundMatrixRows(diagnosis);
  const deliveryGrade = buildDeliveryGrade(diagnosis);
  const guideRows = missingDataGuides(diagnosis);
  const ledgerEntries = actionEntriesForDiagnosis(diagnosis);
  const verification = reviewVerificationRows(diagnosis);
  const lines = [
    `Pinmoo AI ${reportName}`,
    `${diagnosis.data.brandName || diagnosis.data.storeName} · ${diagnosis.data.storeName} · ${diagnosis.data.platform} · ${diagnosis.data.industry} · ${diagnosis.data.period} · ${diagnosis.data.reportPurpose || '品牌方正式版'} · ${diagnosis.data.dataSource || '数据导入'}`,
    `综合健康度：${diagnosis.totalScore} 分`,
    `核心结论：${diagnosis.summary.title}`,
    diagnosis.summary.text,
    '',
    `本周一句话结论：${brandOneSentence(diagnosis)}`,
    '',
    '一、老板先看',
    ...executiveSummaryText(diagnosis).split('\n').map((item) => `- ${item}`),
    '',
    '二、数据完整度',
    `- 完整度：${diagnosis.dataQuality?.score || 0}分，${dataQualityLabel(diagnosis.dataQuality?.score || 0)}`,
    ...(diagnosis.dataQuality?.checks || []).map((item) => `- ${item.ok ? '已具备' : '待补充'}：${item.name}，${item.ok ? '本报告已读取该模块数据。' : item.tip}`),
    '',
    '三、报告交付等级',
    `- ${deliveryGrade.title}`,
    `- ${deliveryGrade.summary}`,
    `- 建议：${deliveryGrade.action}`,
    '',
    '四、本次报告结构',
    `- 已生成模块：${outline.included.join(' / ')}`,
    `- 未生成模块：${outline.skipped.length ? outline.skipped.join('；') : '本次上传数据已覆盖主要经营模块。'}`
  ];
  lines.push('', '类目诊断方向', ...categoryDirectionRows(diagnosis).map((item) => `- ${item.name}：${item.value}`));
  if (state.importSummary) {
    lines.push('', '四、导入文件使用情况', ...importSummaryRows(diagnosis).map((item) => `- ${item.file}：${item.status}，使用行数 ${item.rows}，使用率 ${item.usage}，进入模块 ${item.modules}，${item.note}`));
  }
  if (state.lineage) {
    lines.push('', '数据口径确认', ...lineageRows(diagnosis).map((item) => `- ${item.metric}：${item.value}；${item.status}；来源 ${item.files}；字段 ${item.fields}；${item.method}`));
  }
  if (state.confidence) {
    const confidenceRows = metricConfidenceRows(diagnosis);
    const confidence = confidenceSummary(confidenceRows);
    lines.push('', '指标可信度与文件使用率', `- 可信度：${confidence.score}分；可直接/已计算 ${confidence.strong} 项；需复核/待补充 ${confidence.weak + confidence.missing} 项。`, ...confidenceRows.map((item) => `- ${item.metric}：${item.value}；${item.levelText}；来源 ${item.files}；建议：${item.advice}`), ...dataUsageRows(diagnosis).map((item) => `- 文件使用：${item.file}，${item.usedRows}/${item.rawRows} 行，使用率 ${percent(item.usageRate, 1)}，进入 ${item.modules}`));
  }
  if (state.aux) {
    lines.push('', '流量与客户辅助诊断', ...auxiliaryDiagnosis(diagnosis).map((item) => `- ${item}`));
  }
  if (state.target) {
    lines.push('', '下周期目标建议', `- ${targetPlan.baseline}`, `- ${targetPlan.focus}`, ...targetPlan.rows.map((item) => `- ${targetPlan.periodName}${item.level}：目标销售额 ${yuan(item.sales)}，较本期 ${item.growth >= 0 ? '+' : ''}${item.growth.toFixed(1)}%，目标访客 ${item.visitors.toLocaleString('zh-CN')}，目标转化率 ${percent(item.conversion)}，目标客单价 ${yuan(item.aov)}`));
  }
  if (state.overall) {
    lines.push('', '本周经营总览：净销售额视角', ...operatingSummary(diagnosis).map((item) => `- ${item}`), ...brandKpiRows(diagnosis).map((item) => `- ${item.name}：本期 ${item.current}，对比期 ${item.previous}，变化 ${item.change}，经营解读：${item.judge}`), '', ...moduleDiagnosis(diagnosis).map((item) => `- ${item.module}｜${item.status}：${item.detail}`));
  }
  if (state.daily) {
    lines.push('', '每日销售与退款表现（单日口径）', '说明：以下仅为按真实日期拆分的单日数据，同行同层/全店平均值不作为某一天展示。', ...dailyItems.map((item, index) => `${index + 1}. ${item.date || item.name}：销售额 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，订单 ${Math.round(item.orders || 0)}，转化率 ${percent(item.conversion || 0)}，退款 ${item.refundAmount ? yuan(item.refundAmount) : '-'}，净销售额 ${yuan(item.netSales || Math.max(0, (item.sales || 0) - (item.refundAmount || 0)))}`));
  }
  if (state.product) {
    lines.push('', '宝贝排行', ...productItems.map((item, index) => `${index + 1}. ${item.name || '-'}：支付金额 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，支付买家 ${Math.round(item.orders || 0)}，转化率 ${percent(item.conversion || 0)}，退款 ${item.refundAmount ? yuan(item.refundAmount) : '-'}，退款率 ${item.refundRate ? percent(item.refundRate) : '-'}，${item.note || ''}`));
  }
  if (state.category) {
    lines.push('', '品类/类目排行', ...categoryItems.map((item, index) => `${index + 1}. ${item.name || '-'}：支付金额 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，支付买家 ${Math.round(item.orders || 0)}，转化率 ${percent(item.conversion || 0)}，退款 ${item.refundAmount ? yuan(item.refundAmount) : '-'}`));
  }
  if (state.skuQuadrant) {
    lines.push('', 'SKU四象限诊断', ...skuQuadrantRows(diagnosis).map((item) => `- ${item.type}（${item.count}个）：${item.diagnosis} 动作：${item.action}`));
  }
  if (state.refundMatrix) {
    lines.push('', '退款原因治理矩阵', ...refundItems.map((item, index) => `${index + 1}. ${item.reason}：退款金额 ${item.refundAmount ? yuan(item.refundAmount) : '-'}，笔数 ${item.refundOrders || '-'}，关联商品 ${item.topProduct}。动作：${item.action}`));
  }
  if (state.live) {
    lines.push('', '直播业绩诊断', ...liveItems.map((item, index) => `${index + 1}. ${item.name || '-'}：成交 ${yuan(item.sales || 0)}，观看 ${Math.round(item.liveVisitors || item.visitors || 0)}，商品点击 ${Math.round(item.liveClickUsers || 0)}，观看点击率 ${item.liveClickRate ? percent(item.liveClickRate) : '-'}`));
  }
  if (state.content) {
    lines.push('', '内容资产诊断', ...contentItems.map((item, index) => `${index + 1}. ${item.name || '-'}：成交 ${item.sales ? yuan(item.sales) : '-'}，曝光/浏览 ${Math.round(item.visitors || item.contentVisitors || item.shortVideoVisitors || 0)}，转化 ${item.conversion ? percent(item.conversion) : '-'}`));
  }
  if (state.serviceDetail) {
    lines.push('', '客服绩效诊断', ...serviceItems.map((item, index) => `${index + 1}. ${item.name || '-'}：咨询/接待 ${Math.round(item.visitors || 0)}，成交 ${item.sales ? yuan(item.sales) : '-'}，转化/响应 ${item.conversion ? percent(item.conversion) : '-'}`));
  }
  if (state.traffic) {
    lines.push('', '流量排行', ...trafficItems.map((item, index) => `${index + 1}. ${item.name || '-'}：支付金额 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，转化率 ${percent(item.conversion || 0)}，UV价值 ${item.uvValue ? item.uvValue.toFixed(2) : item.visitors ? (item.sales / item.visitors).toFixed(2) : '-'}，${item.note || ''}`));
  }
  if (state.promotion) {
    lines.push('', '推广情况', ...promotionItems.map((item, index) => `${index + 1}. ${item.name || '-'}：花费 ${yuan(item.spend || 0)}，成交 ${yuan(item.sales || 0)}，ROI ${item.roi ? Number(item.roi).toFixed(2) : '-'}，点击 ${item.clicks ? Math.round(item.clicks) : '-'}，${item.note || ''}`));
  }
  if (state.activity) {
    lines.push('', '活动情况', ...activityItems.map((item, index) => `${index + 1}. ${item.name || '-'}：成交 ${item.sales ? yuan(item.sales) : '-'}，访客 ${item.visitors ? Math.round(item.visitors) : '-'}，订单 ${item.orders ? Math.round(item.orders) : '-'}，${item.note || ''}`));
  }
  if (state.leverage) {
    lines.push('', '经营杠杆拆解', `- 销售缺口：${yuan(diagnosis.decomposition.salesGap)}`, `- 流量影响：${yuan(diagnosis.decomposition.trafficImpact)}`, `- 转化影响：${yuan(diagnosis.decomposition.conversionImpact)}`, `- 客单影响：${yuan(diagnosis.decomposition.aovImpact)}`);
  }
  lines.push(
    '',
    '经营数据评分',
    ...diagnosis.metrics.map((item) => `- ${item.name}：${item.value}；${item.detail}；评分 ${item.score}`),
    '',
    '经营异常雷达',
    ...diagnosis.issues.map((item, index) => [
      `${index + 1}. [${item.rank}] ${item.title}（优先级 ${item.priority}，责任建议：${item.owner}）`,
      `   证据：${item.evidence}`,
      `   顾问判断：${item.diagnosis}`,
      `   影响：${item.impactText}`,
      `   下一步：${item.action}`,
      `   验证：${item.validation}`
    ].join('\n')),
    '',
    '经营行动台账',
    ...ledgerEntries.map((item, index) => `${index + 1}. ${item.title}｜${item.owner}｜截止 ${item.dueDate || '待确认'}｜${actionStatusLabel(item.status)}\n   动作：${item.task}\n   验收：${item.validation}`),
    '',
    '上期动作验证',
    ...(verification.previous
      ? verification.rows.map((item, index) => `${index + 1}. ${item.title}｜${actionStatusLabel(item.status)}\n   指标：${item.metric} ${item.previousValue} → ${item.currentValue}（${item.change}）\n   复盘：${item.conclusion}`)
      : ['暂无同店铺上期报告。本期行动状态保存后，下一周期导入数据即可自动验证。']),
    '',
    '下周期作战看板',
    ...actionBoardRows(diagnosis).map((item, index) => `${index + 1}. ${item.group}｜${item.owner}｜优先级 ${item.priority}\n   动作：${item.action}\n   跟踪指标：${item.kpi}\n   验收：${item.validation}`),
    '',
    '下周期执行计划',
    ...diagnosis.actions.flatMap((group) => [`${group.period}：${group.title}`, ...group.tasks.map((task) => `- ${task}`)]),
    '',
    '需要品牌方/运营进一步确认的问题',
    ...confirmationQuestions(diagnosis).map((item) => `- ${item.replace(/^\d+\.\s*/, '')}`),
    '',
    '需要补充的数据',
    ...guideRows.map((item, index) => `${index + 1}. ${item.file || item.name || '待补充数据'}\n   下载位置：${item.path || item.tip || '按平台后台对应模块导出'}\n   增强报告：${item.improves || item.tip || '增强对应模块判断'}\n   补充原因：${item.reason || '补充后可减少待核实判断。'}`),
    '',
    '微信群发送话术',
    wechatShareText(diagnosis),
    '',
    `顾问备注：${diagnosis.data.notes || '暂无'}`
  );
  return lines.join('\n');
  return [
    `Pinmoo AI ${reportName}`,
    `${diagnosis.data.storeName} · ${diagnosis.data.platform} · ${diagnosis.data.industry} · ${diagnosis.data.period} · ${diagnosis.data.dataSource || '数据导入'}`,
    `综合健康度：${diagnosis.totalScore} 分`,
    `核心结论：${diagnosis.summary.title}`,
    diagnosis.summary.text,
    '',
    '一、老板先看',
    ...executiveSummaryText(diagnosis).split('\n').map((item) => `- ${item}`),
    '',
    '二、数据完整度',
    `- 完整度：${diagnosis.dataQuality?.score || 0}分，${dataQualityLabel(diagnosis.dataQuality?.score || 0)}`,
    ...(diagnosis.dataQuality?.checks || []).map((item) => `- ${item.ok ? '已具备' : '待补充'}：${item.name}，${item.ok ? '本报告已读取该模块数据。' : item.tip}`),
    '',
    '三、导入文件使用情况',
    ...importSummaryRows(diagnosis).map((item) => `- ${item.file}：${item.status}，使用行数 ${item.rows}，使用率 ${item.usage}，进入模块 ${item.modules}，${item.note}`),
    '',
    '四、流量与客户辅助诊断',
    ...auxiliaryDiagnosis(diagnosis).map((item) => `- ${item}`),
    '',
    '五、下周期目标建议',
    `- ${targetPlan.baseline}`,
    `- ${targetPlan.focus}`,
    ...targetPlan.rows.map((item) => `- ${targetPlan.periodName}${item.level}：目标销售额 ${yuan(item.sales)}，较本期 ${item.growth >= 0 ? '+' : ''}${item.growth.toFixed(1)}%，目标访客 ${item.visitors.toLocaleString('zh-CN')}，目标转化率 ${percent(item.conversion)}，目标客单价 ${yuan(item.aov)}`),
    '',
    '六、店铺整体情况',
    ...operatingSummary(diagnosis).map((item) => `- ${item}`),
    ...metricChangeRows(diagnosis).map((item) => `- ${item.name}：本期 ${item.current}，对比期 ${item.previous}，变化 ${item.change}，判断：${item.judge}`),
    '',
    ...moduleDiagnosis(diagnosis).map((item) => `- ${item.module}｜${item.status}：${item.detail}`),
    '',
    '七、宝贝排行',
    ...(weekly.products || []).map((item, index) => `${index + 1}. ${item.name || '-'}：销售额 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，订单 ${Math.round(item.orders || 0)}，转化率 ${percent(item.conversion || 0)}，${item.note || ''}`),
    '',
    '八、流量排行',
    ...(weekly.traffic || []).map((item, index) => `${index + 1}. ${item.name || '-'}：销售额 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，转化率 ${percent(item.conversion || 0)}，${item.note || ''}`),
    '',
    '九、推广情况',
    ...(weekly.promotion || []).map((item, index) => `${index + 1}. ${item.name || '-'}：花费 ${yuan(item.spend || 0)}，成交 ${yuan(item.sales || 0)}，ROI ${item.roi ? Number(item.roi).toFixed(2) : '-'}，点击 ${item.clicks ? Math.round(item.clicks) : '-'}，${item.note || ''}`),
    '',
    '十、活动情况',
    ...(weekly.activity || []).map((item, index) => `${index + 1}. ${item.name || '-'}：成交 ${item.sales ? yuan(item.sales) : '-'}，访客 ${item.visitors ? Math.round(item.visitors) : '-'}，订单 ${item.orders ? Math.round(item.orders) : '-'}，${item.note || ''}`),
    '',
    '十一、经营杠杆拆解',
    `- 销售缺口：${yuan(diagnosis.decomposition.salesGap)}`,
    `- 流量影响：${yuan(diagnosis.decomposition.trafficImpact)}`,
    `- 转化影响：${yuan(diagnosis.decomposition.conversionImpact)}`,
    `- 客单影响：${yuan(diagnosis.decomposition.aovImpact)}`,
    '',
    '十二、经营数据评分',
    ...diagnosis.metrics.map((item) => `- ${item.name}：${item.value}；${item.detail}；评分 ${item.score}`),
    '',
    '十三、关键问题与优先级',
    ...diagnosis.issues.map((item, index) => [
      `${index + 1}. [${item.rank}] ${item.title}（优先级 ${item.priority}，责任建议：${item.owner}）`,
      `   证据：${item.evidence}`,
      `   顾问判断：${item.diagnosis}`,
      `   影响：${item.impactText}`,
      `   下一步：${item.action}`,
      `   验证：${item.validation}`
    ].join('\n')),
    '',
    '十四、下周期执行计划',
    ...diagnosis.actions.flatMap((group) => [`${group.period}：${group.title}`, ...group.tasks.map((task) => `- ${task}`)]),
    '',
    '十五、需要品牌方/运营进一步确认的问题',
    ...confirmationQuestions(diagnosis).map((item) => `- ${item.replace(/^\d+\.\s*/, '')}`),
    '',
    '十六、需要补充的数据',
    ...missingDataTips(diagnosis.data).map((tip) => `- ${tip}`),
    '',
    `十七、顾问备注：${diagnosis.data.notes || '暂无'}`
  ].join('\n');
}

function reportText(diagnosis) {
  if (!diagnosis) return '';
  const data = diagnosis.data || {};
  const state = reportModuleState(diagnosis);
  const details = data.importedDetails || {};
  const weekly = diagnosis.weeklySections || {};
  const ledgerEntries = actionEntriesForDiagnosis(diagnosis);
  const verification = reviewVerificationRows(diagnosis);
  const outline = adaptiveReportOutline(diagnosis);
  const deliveryGrade = buildDeliveryGrade(diagnosis);
  const lines = [];
  const addSection = (title, rows = []) => {
    const content = rows.filter((item) => item !== null && item !== undefined && String(item).trim());
    if (!content.length) return;
    lines.push('', title, ...content);
  };

  lines.push(
    `Pinmoo AI ${getReportName(diagnosis)}`,
    `${data.brandName || data.storeName || '待确认品牌'} · ${data.storeName || '待确认店铺'} · ${data.platform || '待确认平台'} · ${data.industry || '待确认类目'}`,
    `${data.period || [data.periodStart, data.periodEnd].filter(Boolean).join(' 至 ') || '待确认周期'} · ${data.reportPurpose || '品牌方正式版'} · ${data.dataSource || '数据导入'}`,
    '',
    `一句话结论：${brandOneSentence(diagnosis)}`,
    `综合健康度：${diagnosis.totalScore} 分`,
    `核心结论：${diagnosis.summary.title}`,
    diagnosis.summary.text
  );

  addSection('一、老板先看', executiveSummaryText(diagnosis).split('\n').map((item) => `- ${item}`));
  addSection('二、交付与数据完整度', [
    `- 交付等级：${deliveryGrade.title}`,
    `- 交付判断：${deliveryGrade.summary}`,
    `- 数据完整度：${diagnosis.dataQuality?.score || 0} 分，${dataQualityLabel(diagnosis.dataQuality?.score || 0)}`,
    `- 已生成模块：${outline.included.join(' / ')}`,
    `- 暂未生成模块：${outline.skipped.length ? outline.skipped.join(' / ') : '主要经营模块已覆盖'}`
  ]);
  addSection('三、数据口径确认', lineageRows(diagnosis).map((item) =>
    `- ${item.metric}：${item.value}；${item.status}；来源：${item.files}；字段：${item.fields}；${item.method}`));
  addSection('四、类目诊断方向', categoryDirectionRows(diagnosis).map((item) => `- ${item.name}：${item.value}`));

  if (state.overall) {
    addSection('五、本期经营总览', [
      ...operatingSummary(diagnosis).map((item) => `- ${item}`),
      ...brandKpiRows(diagnosis).map((item) => `- ${item.name}：本期 ${item.current}，对比期 ${item.previous}，变化 ${item.change}。判断：${item.judge}`)
    ]);
  }
  if (state.daily) {
    addSection('六、每日销售与退款表现', (details.daily || []).map((item, index) =>
      `${index + 1}. ${item.date || item.name || '-'}：支付 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，订单 ${Math.round(item.orders || 0)}，转化 ${percent(item.conversion || 0)}，退款 ${item.refundAmount ? yuan(item.refundAmount) : '-'}，净销售额 ${yuan(item.netSales || Math.max(0, (item.sales || 0) - (item.refundAmount || 0)))}`));
  }
  if (state.product) {
    const products = state.imported ? details.products || [] : weekly.products || [];
    addSection('七、商品销售与退款风险', products.map((item, index) =>
      `${index + 1}. ${item.name || '-'}：支付 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，买家 ${Math.round(item.orders || 0)}，转化 ${percent(item.conversion || 0)}，退款 ${item.refundAmount ? yuan(item.refundAmount) : '-'}，退款率 ${item.refundRate ? percent(item.refundRate) : '-'}。${item.note || ''}`));
  }
  if (state.traffic) {
    const traffic = state.imported ? details.traffic || [] : weekly.traffic || [];
    addSection('八、流量来源结构与质量', traffic.map((item, index) =>
      `${index + 1}. ${item.name || '-'}：支付 ${yuan(item.sales || 0)}，访客 ${Math.round(item.visitors || 0)}，转化 ${percent(item.conversion || 0)}，UV价值 ${item.uvValue ? Number(item.uvValue).toFixed(2) : item.visitors ? ((item.sales || 0) / item.visitors).toFixed(2) : '-'}。${item.note || ''}`));
  }
  if (state.promotion) {
    const promotion = state.imported ? details.promotion || [] : weekly.promotion || [];
    addSection('九、推广计划表现', promotion.map((item, index) =>
      `${index + 1}. ${item.name || '-'}：花费 ${yuan(item.spend || 0)}，成交 ${yuan(item.sales || 0)}，ROI ${item.roi ? Number(item.roi).toFixed(2) : '-'}，点击 ${item.clicks ? Math.round(item.clicks) : '-'}。${item.note || ''}`));
  }
  if (state.refundMatrix) {
    addSection('十、退款原因治理', refundMatrixRows(diagnosis).map((item, index) =>
      `${index + 1}. ${item.reason}：退款金额 ${item.refundAmount ? yuan(item.refundAmount) : '-'}，退款笔数 ${item.refundOrders || '-'}，关联商品 ${item.topProduct}。动作：${item.action}`));
  }
  if (state.live) {
    addSection('十一、直播成交承接', (details.live || []).map((item, index) =>
      `${index + 1}. ${item.name || '-'}：成交 ${yuan(item.sales || 0)}，观看 ${Math.round(item.liveVisitors || item.visitors || 0)}，商品点击 ${Math.round(item.liveClickUsers || 0)}，观看-点击率 ${item.liveClickRate ? percent(item.liveClickRate) : '-'}。`));
  }
  if (state.content) {
    addSection('十二、内容种草表现', (details.content || []).map((item, index) =>
      `${index + 1}. ${item.name || '-'}：成交 ${item.sales ? yuan(item.sales) : '-'}，曝光/浏览 ${Math.round(item.visitors || item.contentVisitors || item.shortVideoVisitors || 0)}，转化 ${item.conversion ? percent(item.conversion) : '-'}。`));
  }
  if (state.serviceDetail) {
    addSection('十三、客服承接表现', (details.service || []).map((item, index) =>
      `${index + 1}. ${item.name || '-'}：咨询/接待 ${Math.round(item.visitors || 0)}，成交 ${item.sales ? yuan(item.sales) : '-'}，转化/响应 ${item.conversion ? percent(item.conversion) : '-'}。`));
  }

  addSection('十四、经营异常雷达', diagnosis.issues.map((item, index) => [
    `${index + 1}. [${item.rank}] ${item.title}｜优先级 ${item.priority}｜建议责任人 ${item.owner}`,
    `   证据：${item.evidence}`,
    `   判断：${item.diagnosis}`,
    `   动作：${item.action}`,
    `   验收：${item.validation}`
  ].join('\n')));
  addSection('十五、经营行动台账', ledgerEntries.map((item, index) => [
    `${index + 1}. ${item.title}｜${item.owner}｜截止 ${item.dueDate || '待确认'}｜${actionStatusLabel(item.status)}`,
    `   动作：${item.task}`,
    `   验收：${item.validation}`
  ].join('\n')));
  addSection('十六、上期动作验证', verification.previous
    ? verification.rows.map((item, index) => [
      `${index + 1}. ${item.title}｜${actionStatusLabel(item.status)}`,
      `   指标：${item.metric} ${item.previousValue} → ${item.currentValue}（${item.change}）`,
      `   复盘：${item.conclusion}`
    ].join('\n'))
    : ['- 暂无同店铺上一周期报告。本期行动状态保存后，下一周期导入数据即可自动验证。']);
  addSection('十七、下周期作战看板', actionBoardRows(diagnosis).map((item, index) =>
    `${index + 1}. ${item.group}｜${item.owner}｜优先级 ${item.priority}\n   动作：${item.action}\n   跟踪指标：${item.kpi}\n   验收：${item.validation}`));
  addSection('十八、需要确认的问题', confirmationQuestions(diagnosis).map((item) => `- ${item.replace(/^\d+\.\s*/, '')}`));
  addSection('十九、需要补充的数据', missingDataGuides(diagnosis).map((item, index) =>
    `${index + 1}. ${item.file || item.name || '待补充数据'}：${item.reason || item.tip || '补充后可增强对应模块判断。'}`));
  addSection('微信群发送话术', [wechatShareText(diagnosis)]);
  addSection('顾问备注', [data.notes || '暂无补充说明。']);
  return lines.join('\n');
}

function exportReport() {
  if (!latestDiagnosis) return toast('请先生成诊断报告');
  downloadText(reportText(latestDiagnosis), `${latestDiagnosis.data.storeName}-${getReportName(latestDiagnosis)}.txt`);
  updateWorkflowStatus('exported', 'TXT 报告已导出。正式交付建议优先使用 Word，并核实数据口径。');
  toast('报告文本已导出');
}

function exportHistory() {
  const archive = {
    version: 2,
    exportedAt: new Date().toISOString(),
    history,
    actionLedger
  };
  downloadText(JSON.stringify(archive, null, 2), `pinmoo-business-review-${new Date().toISOString().slice(0, 10)}.json`);
  toast('复盘记录与行动台账已导出');
}

function downloadText(text, filename) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function exportWord() {
  if (!latestDiagnosis) return toast('请先生成诊断报告');
  const title = exportFileBaseName(latestDiagnosis.data);
  const reportHtml = $('#reportPaper').innerHTML;
  const wordHtml = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>${escapeHtml(title)}</title>
  <style>
    body { font-family: "Microsoft YaHei", "PingFang SC", Arial, sans-serif; color: #111827; line-height: 1.65; }
    h3 { text-align: center; font-size: 24px; margin: 18px 0 8px; }
    h4 { font-size: 16px; margin: 20px 0 8px; }
    p, li { font-size: 12px; color: #344054; }
    table { width: 100%; border-collapse: collapse; margin: 8px 0 14px; font-size: 11px; }
    th, td { border: 1px solid #d0d7e2; padding: 7px 8px; text-align: left; vertical-align: top; }
    th { background: #eef4ff; color: #1f2937; font-weight: 700; }
    .report-brand { color: #115df6; font-weight: 700; }
    .report-meta { text-align: center; color: #667085; font-size: 11px; }
    .conclusion-box { border: 1px solid #bfd3ff; background: #eef4ff; padding: 12px; margin: 14px 0; }
    .report-cover { border: 1px solid #bfd3ff; background: #f8fbff; padding: 20px; margin: 0 0 18px; }
    .cover-brand { color: #115df6; font-weight: 700; margin-bottom: 16px; }
    .report-cover h2 { text-align: center; font-size: 26px; margin: 8px 0; color: #111827; }
    .report-cover > p { text-align: center; color: #667085; }
    .cover-kpis { display: table; width: 100%; border-spacing: 6px; margin: 12px 0; }
    .cover-kpis section { display: table-cell; width: 25%; border: 1px solid #d0d7e2; background: #fff; padding: 9px; }
    .cover-kpis span { display: block; color: #667085; font-size: 10px; }
    .cover-kpis strong { display: block; font-size: 15px; color: #111827; }
    .cover-conclusion { border-left: 4px solid #115df6; background: #fff; padding: 10px; }
    .cover-conclusion b, .cover-conclusion span { display: block; }
    .module-insight { display: table; width: 100%; border-spacing: 6px; margin: 10px 0; }
    .module-insight section { display: table-cell; width: 33%; border: 1px solid #d0d7e2; background: #f8fbff; padding: 8px; }
    .module-insight span { display: block; color: #667085; font-size: 10px; font-weight: 700; }
    .module-insight strong { display: block; color: #111827; font-size: 11px; line-height: 1.5; }
    .visual-summary { display: table; width: 100%; margin: 14px 0; border-spacing: 8px; }
    .visual-score, .visual-kpis { display: table-cell; vertical-align: top; }
    .visual-score { width: 24%; border: 1px solid #d0d7e2; background: #f8fbff; padding: 12px; text-align: center; }
    .visual-score-ring { width: 92px; height: 92px; margin: 0 auto 8px; border: 8px solid #115df6; border-radius: 50%; display: grid; place-items: center; }
    .visual-score-ring strong { font-size: 24px; display: block; }
    .visual-score-ring span { display: block; color: #667085; font-size: 11px; }
    .visual-kpis { width: 76%; }
    .visual-kpi-card { display: inline-block; width: 18%; min-height: 102px; margin: 0 4px 8px 0; border: 1px solid #d0d7e2; border-top: 4px solid #115df6; padding: 9px; vertical-align: top; }
    .visual-kpi-card span { display: block; color: #667085; font-size: 10px; font-weight: 700; }
    .visual-kpi-card strong { display: block; font-size: 13px; margin: 4px 0; }
    .visual-kpi-card i { display: block; height: 6px; border-radius: 8px; background: #edf2f7; overflow: hidden; }
    .visual-kpi-card i b { display: block; height: 100%; background: #115df6; }
    .visual-kpi-card p { font-size: 10px; margin-top: 6px; }
    .report-actions-list section, .quality-box { border: 1px solid #d0d7e2; padding: 10px; margin: 8px 0; }
    .ops-board { display: table; width: 100%; border-spacing: 8px; margin: 8px 0 14px; }
    .ops-card { display: inline-block; width: 46%; min-height: 172px; border: 1px solid #d0d7e2; background: #f8fbff; padding: 10px; margin: 0 8px 8px 0; vertical-align: top; }
    .ops-card header b { display: inline-block; min-width: 22px; height: 22px; line-height: 22px; border-radius: 50%; background: #115df6; color: #ffffff; text-align: center; margin-right: 6px; }
    .ops-card header span, .ops-card header em { display: inline-block; color: #115df6; font-size: 10px; font-style: normal; font-weight: 700; margin-right: 5px; }
    .ops-card strong { display: block; margin: 8px 0 5px; color: #111827; }
    .ops-card p { margin: 5px 0; }
    .ops-card footer span, .ops-card footer small { display: block; color: #667085; font-size: 10px; }
    .boss-summary, .quality-box { background: #f8fbff; }
    .delivery-grade { display: table; width: 100%; border: 1px solid #d0d7e2; background: #f8fbff; padding: 12px; margin: 14px 0; }
    .delivery-grade.grade-a { border-color: #86efac; background: #f0fdf4; }
    .delivery-grade.grade-b { border-color: #fdba74; background: #fffaf0; }
    .delivery-grade.grade-c { border-color: #fca5a5; background: #fff5f5; }
    .delivery-mark { display: inline-block; width: 38px; height: 38px; border-radius: 50%; background: #115df6; color: #ffffff; text-align: center; line-height: 38px; font-size: 20px; font-weight: 800; margin-right: 10px; }
    .delivery-grade strong { font-size: 14px; color: #111827; }
    .delivery-grade p { margin: 4px 0; }
    .delivery-grade span { color: #667085; font-size: 11px; }
    .missing-guide-list section { border: 1px solid #fdba74; background: #fffaf0; padding: 9px; margin: 8px 0; }
    .missing-guide-list b { display: inline-block; min-width: 20px; height: 20px; line-height: 20px; border-radius: 50%; background: #ffedd5; color: #92400e; text-align: center; margin-right: 6px; }
    .missing-guide-list strong { color: #111827; }
    .missing-guide-list p { margin: 3px 0; }
    .missing-guide-list p span { color: #92400e; font-weight: 700; margin-right: 4px; }
    .missing-guide-list em { display: block; color: #667085; font-size: 10px; font-style: normal; margin-top: 3px; }
    .report-layout { display: block; }
    .report-audit { border-top: 1px solid #d0d7e2; margin-top: 18px; padding-top: 12px; }
  </style>
</head>
<body>${reportHtml}</body>
</html>`;
  const blob = new Blob(['\ufeff', wordHtml], { type: 'application/msword;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${title}.doc`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  updateWorkflowStatus('exported', 'Word 正式版已导出。发送前建议再核实标题、周期、净销售额和退款口径。');
  toast('Word 报告已导出');
}

async function copyReport() {
  if (!latestDiagnosis) return toast('请先生成诊断报告');
  const text = reportText(latestDiagnosis);
  try {
    await navigator.clipboard.writeText(text);
    updateWorkflowStatus('exported', '报告正文已复制。若用于正式发送，建议优先导出 Word 留档。');
    toast('报告内容已复制');
  } catch {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
    updateWorkflowStatus('exported', '报告正文已复制。若用于正式发送，建议优先导出 Word 留档。');
    toast('报告内容已复制');
  }
}

async function copyExecutiveSummary() {
  if (!latestDiagnosis) return toast('请先生成诊断报告');
  const text = executiveSummaryText(latestDiagnosis);
  try {
    await navigator.clipboard.writeText(text);
    updateWorkflowStatus('exported', '老板摘要已复制，可用于快速同步核心结论。');
    toast('老板摘要已复制');
  } catch {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
    updateWorkflowStatus('exported', '老板摘要已复制，可用于快速同步核心结论。');
    toast('老板摘要已复制');
  }
}

function wechatShareText(diagnosis) {
  const data = diagnosis.data;
  const activeReturn = activeReturnSignal(data);
  const refundAmount = refundAmountValue(data);
  const netSales = netSalesValue(data);
  const topIssues = (diagnosis.issues || []).slice(0, 3).map((item, index) => `${index + 1}. ${item.title}`).join('\n');
  return [
    `各位好，${data.brandName || data.storeName || '店铺'}${data.reportType || '周报'}已生成，周期：${data.period || '-' }。`,
    '',
    `本期支付金额 ${yuan(data.sales)}，访客 ${Math.round(data.visitors || 0).toLocaleString('zh-CN')}，转化率 ${percent(data.conversion || 0)}，客单价 ${yuan(data.aov || 0)}。`,
    `按当前口径测算，成功退款金额 ${refundAmount ? yuan(refundAmount) : '待补充'}，净销售额 ${yuan(netSales)}。`,
    activeReturn.sales ? `主动回访支付金额 ${yuan(activeReturn.sales)}，转化率 ${percent(activeReturn.conversion)}，建议作为下周期重点放大来源。` : '',
    '',
    `本期核心判断：${brandOneSentence(diagnosis)}`,
    '',
    topIssues ? `下周期优先关注：\n${topIssues}` : '',
    '',
    '详细报告已导出，建议会议中重点看净销售额、退款商品、付费计划效率和下周期动作。'
  ].filter(Boolean).join('\n');
}

async function copyWechatText() {
  if (!latestDiagnosis) return toast('请先生成诊断报告');
  const text = wechatShareText(latestDiagnosis);
  try {
    await navigator.clipboard.writeText(text);
    updateWorkflowStatus('exported', '微信群发送话术已复制。建议发送前核实周期、金额和下周重点。');
    toast('微信群发送话术已复制');
  } catch {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
    updateWorkflowStatus('exported', '微信群发送话术已复制。建议发送前核实周期、金额和下周重点。');
    toast('微信群发送话术已复制');
  }
}

function parseCsv(text) {
  const clean = text.replace(/^\uFEFF/, '');
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < clean.length; i += 1) {
    const char = clean[i];
    const next = clean[i + 1];
    if (char === '"' && quoted && next === '"') {
      cell += '"';
      i += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === ',' && !quoted) {
      row.push(cell);
      cell = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && next === '\n') i += 1;
      row.push(cell);
      if (row.some((value) => value.trim() !== '')) rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += char;
    }
  }
  row.push(cell);
  if (row.some((value) => value.trim() !== '')) rows.push(row);
  if (rows.length < 2) return [];
  const headers = rows[0].map((value) => value.trim());
  return rows.slice(1).map((values) => {
    const item = {};
    headers.forEach((header, index) => {
      item[header] = values[index] === undefined ? '' : values[index].trim();
    });
    return item;
  });
}

function parseDelimitedRows(text) {
  const clean = String(text || '').replace(/^\uFEFF/, '');
  const lines = clean.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (lines.length < 2) return [];
  const delimiter = lines[0].includes('\t') ? '\t' : lines[0].includes(';') ? ';' : ',';
  if (delimiter === ',') return parseCsv(clean);
  const rows = lines.map((line) => line.split(delimiter).map((cell) => cell.trim()));
  const headers = rows[0];
  return rows.slice(1).map((values) => {
    const item = {};
    headers.forEach((header, index) => {
      item[header || `字段${index + 1}`] = values[index] || '';
    });
    return item;
  }).filter((row) => Object.values(row).some(Boolean));
}

function normalizeKey(value) {
  return String(value || '').replace(/\s+/g, '').replace(/[()（）%％]/g, '').toLowerCase();
}

function pick(row, aliases) {
  const keys = Object.keys(row);
  for (const alias of aliases) {
    const target = normalizeKey(alias);
    const key = keys.find((item) => normalizeKey(item) === target);
    if (key !== undefined && row[key] !== '') return row[key];
  }
  return '';
}

function parseMetric(value) {
  if (value === null || value === undefined || value === '') return 0;
  const text = String(value).replace(/,/g, '').replace(/%/g, '').replace(/￥/g, '').replace(/¥/g, '').trim();
  if (!text || text === '-') return 0;
  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed : 0;
}

function parseRateMetric(value) {
  if (value === null || value === undefined || value === '') return 0;
  const raw = String(value).trim();
  const parsed = parseMetric(raw);
  if (!Number.isFinite(parsed)) return 0;
  return raw.includes('%') ? parsed : (Math.abs(parsed) > 1 ? parsed : parsed * 100);
}

function detectReportKind(row) {
  const source = String(row.来源文件 || row.sourceFile || '').toLowerCase();
  const keys = Object.keys(row).join(' ');
  if (/首页|数据概览|经营核心|交易概况|月报/.test(source) || (pick(row, ['类别']) && pick(row, ['支付金额', '支付买家数', '访客数']))) return 'overall';
  if (/品类|标准类目/.test(source) || /一级类目名称|二级类目名称|类目名称/.test(keys)) return 'category';
  if (/直播业绩|店播|直播/.test(source) || /观看人数|直播成交金额|开播时长|播后成交金额|点击-成交转化率/.test(keys)) return 'live';
  if (/光合|资产总览|内容资产/.test(source) || /内容曝光量|内容浏览量|内容成交金额|短视频发布数|直播场次/.test(keys)) return 'content';
  if (/客服绩效|客服团队|客服/.test(source) || /客服支付金额|平均响应时长|客服响应率|接待人数|咨询人数/.test(keys)) return 'service';
  if (/店铺绩效|业绩分析/.test(source) || /净支付金额|询单转化率/.test(keys)) return 'shopPerformance';
  if (/流量来源|场域来源/.test(source) || /流量来源|来源名称|来源明细|一级渠道|二级渠道/.test(keys)) return 'traffic';
  if (/流量概况|流量看板|流量总览/.test(source)) return 'trafficOverview';
  if (/退款|售后/.test(source) || /退款原因|成功退款/.test(keys)) return 'refund';
  if (/客服|旺旺/.test(source) || /响应时长|满意度|咨询人数/.test(keys)) return 'service';
  if (/会员|客户/.test(source) || /会员总数|复购率|客户新访/.test(keys)) return 'member';
  if (/营销场景|计划报表|关键词报表|创意报表|单元报表|人群报表|地域报表|内容报表|商品报表/.test(source) || pick(row, ['花费', '投入产出比', '计划名字', '场景名字'])) return 'promotion';
  if (/商品|宝贝|sku|spu/.test(source) || /商品名称|宝贝名称|SPU名称|商品概况|商品明细/.test(keys)) return 'product';
  if (/活动/.test(source) || /活动名称/.test(keys)) return 'activity';
  return 'unknown';
}

const reportKindOptions = [
  ['auto', '自动识别'],
  ['overall', '首页/经营概览'],
  ['shopPerformance', '店铺绩效'],
  ['product', '商品/宝贝'],
  ['category', '品类/类目'],
  ['traffic', '流量来源'],
  ['trafficOverview', '流量总览'],
  ['promotion', '推广计划'],
  ['refund', '退款售后'],
  ['service', '客服绩效'],
  ['member', '客户/会员'],
  ['live', '直播业绩'],
  ['content', '光合/内容'],
  ['activity', '活动情况'],
  ['unknown', '未识别'],
  ['ignored', '不参与报告']
];

function reportKindLabel(kind) {
  return (reportKindOptions.find(([value]) => value === kind) || reportKindOptions[0])[1];
}

function inferPlatform(row, reportKind) {
  const source = String(row.来源文件 || row.sourceFile || '');
  const keys = Object.keys(row).join(' ');
  if (/京东|jd|10292689|734249/.test(source.toLowerCase()) || /SPU名称|店铺成交转化率|一级渠道|二级渠道|引入商详访客数/.test(keys)) return '京东';
  if (/淘宝|天猫|生意参谋|万相台|直通车|淘宝客/.test(source + keys)) return '天猫';
  if (reportKind === 'promotion' && /主体ID|场景ID|计划ID/.test(keys)) return '天猫';
  return '';
}

function cleanTrafficLevel(value) {
  const text = String(value || '').trim();
  return text && text !== '-' && text !== '汇总' ? text : '';
}

function pickTrafficInfo(row) {
  const rawLevels = [
    pick(row, ['一级来源', '一级渠道']),
    pick(row, ['二级来源', '二级渠道']),
    pick(row, ['三级来源', '三级渠道']),
    pick(row, ['四级来源', '四级渠道'])
  ].map(cleanTrafficLevel);
  const levels = rawLevels.filter(Boolean);
  if (levels.length) return { name: levels[levels.length - 1], depth: levels.length, path: levels.join(' / '), levels: rawLevels };
  const fallback = pick(row, ['流量来源', '渠道来源', '渠道', '来源', '来源名称', '流量来源名称', 'trafficSource']);
  return { name: fallback, depth: fallback ? 1 : 0, path: fallback, levels: rawLevels };
}

function normalizeSpecialRow(row) {
  const source = String(row.来源文件 || '');
  if (/无线店铺流量来源/.test(source) && row.字段1 && row.访客数 && Number.isNaN(Number(String(row.访客数).replace(/,/g, '')))) {
    const hasUniqueDuplicateHeaders = row['支付金额__2'] !== undefined || row['商品收藏人数__2'] !== undefined;
    if (hasUniqueDuplicateHeaders) {
      return {
        ...row,
        一级来源: row.访客数,
        二级来源: row.访客数环比,
        三级来源: row.加购人数,
        四级来源: row.加购人数环比,
        访客数: row.商品收藏人数,
        访客数环比: row.商品收藏人数环比,
        浏览量: row.支付买家数,
        浏览量环比: row.支付买家数环比,
        平均停留时长: row.支付转化率,
        平均停留时长环比: row.支付转化率环比,
        商品收藏人数: row.支付金额,
        商品收藏人数环比: row.支付金额环比,
        商品加购人数: row.客单价,
        商品加购人数环比: row.客单价环比,
        商品加购件数: row.UV价值,
        商品加购件数环比: row.uv价值环比,
        支付买家数: row['支付买家数__2'],
        支付买家数环比: row['支付买家数环比__2'],
        支付转化率: row['支付转化率__2'],
        支付转化率环比: row['支付转化率环比__2'],
        支付金额: row['支付金额__2'],
        支付金额环比: row['支付金额环比__2'],
        客单价: row['客单价__2'],
        客单价环比: row['客单价环比__2'],
        UV价值: row['UV价值__2'],
        uv价值环比: row['uv价值环比__2']
      };
    }
    return {
      ...row,
      一级来源: row.访客数,
      二级来源: row.访客数环比,
      三级来源: row.加购人数,
      四级来源: row.加购人数环比,
      访客数: row.商品收藏人数,
      访客数环比: row.商品收藏人数环比,
      加购人数: row.支付买家数,
      加购人数环比: row.支付买家数环比,
      商品收藏人数: row.支付转化率,
      支付买家数: row.支付金额,
      支付转化率: row.客单价,
      支付金额: row.UV价值,
      客单价: row.加购件数
    };
  }
  return row;
}

function toImportedRow(row) {
  row = normalizeSpecialRow(row);
  const reportKind = row.__reportKindOverride || detectReportKind(row);
  if (reportKind === 'ignored') {
    return {
      reportKind,
      sourceFile: String(row.来源文件 || row.sourceFile || ''),
      rowIndex: Number.parseInt(row.__rowIndex ?? row.rowIndex ?? 0, 10) || 0
    };
  }
  const sourceCategory = pick(row, ['类别', '范围', '人群类型']);
  const sourceText = String(row.来源文件 || '');
  const trafficInfo = pickTrafficInfo(row);
  const sales = parseMetric(pick(row, ['销售额', 'GMV', '成交金额', '支付金额', '总支付金额', '净支付金额', '总成交金额', '直接成交金额', '间接成交金额', '引入成交金额', '会员成交金额', '老买家支付金额', '老客复购金额', 'sales']));
  const prevSales = parseMetric(pick(row, ['销售额-对比日', '成交金额-对比日', '支付金额-对比日', '总成交金额-对比日', '引入成交金额-对比日', 'salesPrev', 'prevSales']));
  const visitors = parseMetric(pick(row, ['访客数', '访客', 'UV', '店铺访客数', '商品访客数', '引入商详访客数', '引导访问人数', '引导访问量', '店铺客户数', '内容查看人数', 'visitors']));
  const prevVisitors = parseMetric(pick(row, ['访客数-对比日', '店铺访客数-对比日', '商品访客数-对比日', '引入商详访客数-对比日', 'visitorsPrev', 'prevVisitors']));
  const aov = parseMetric(pick(row, ['客单价', '人均成交金额', '会员客单价', 'aov']));
  const conversion = parseRateMetric(pick(row, ['转化率', '支付转化率', '点击转化率', '询单转化率', '商品支付转化率', '店铺成交转化率', '成交转化率', '访客-成交转化率', '浏览-成交转化率', 'conversion']));
  const orders = parseMetric(pick(row, ['支付买家数', '成交人数', '成交客户数', '引入成交客户数', '订单数', '支付订单数', '成交订单数', '成交单量', '引入成交单量', '支付子订单数', '总支付子订单数', '总成交笔数', 'orders'])) ||
    (aov ? sales / aov : visitors * conversion / 100);
  const periodTag = pick(row, ['周期', '期间', '本期上期', '对比周期', 'period', 'compare']);
  const periodText = String(periodTag || '').toLowerCase();
  const categoryText = String(sourceCategory || '');
  const bucket = categoryText.includes('同行') ? 'benchmark' : periodText.includes('上期') || periodText.includes('previous') || periodText.includes('prev') ? 'previous' : 'current';
  const rawItemName = pick(row, ['宝贝名称', '商品名称', '宝贝', '商品', 'SKU', 'sku', 'SPU名称', 'SPU', '商品ID', 'itemName', 'productName', '主体名称']);
  const rawPromotionName = pick(row, ['推广计划', '计划名称', '计划名字', '推广渠道', '推广名称', '推广单元', '推广场景', '场景名称', '场景名字', '原二级场景名字', '创意名字', '词名字/词包名字', 'promotionName', 'campaign']);
  const categoryName = pick(row, ['类目名称', '一级类目名称', '二级类目名称', '品类', '标准类目', 'categoryName']);
  const liveName = reportKind === 'live' ? pick(row, ['直播间名称', '主播名称', '场次名称', '统计日期', '日期']) || '直播整体' : '';
  const contentName = reportKind === 'content' ? pick(row, ['内容名称', '资产名称', '账号名称', '统计日期', '日期']) || '内容资产整体' : '';
  const serviceName = ['service', 'shopPerformance'].includes(reportKind) ? pick(row, ['客服名称', '客服', '店铺名称', '日期', '统计日期']) || (reportKind === 'service' ? '客服整体' : '店铺绩效') : '';
  return {
    bucket,
    reportKind,
    forcedReportKind: Boolean(row.__reportKindOverride),
    sourceCategory,
    sourceFile: sourceText,
    rowIndex: Number.parseInt(row.__rowIndex ?? row.rowIndex ?? 0, 10) || 0,
    date: pick(row, ['日期', '时间', '统计日期', 'date']),
    storeName: pick(row, ['店铺名称', '店铺', 'storeName', 'store']),
    industry: pick(row, ['行业', '所属行业', 'industry']),
    platform: pick(row, ['平台', '店铺平台', 'platform']) || inferPlatform(row, reportKind),
    itemName: reportKind === 'promotion' && !/商品报表|创意报表|内容报表/.test(sourceText) ? '' : rawItemName,
    categoryName,
    liveName,
    contentName,
    serviceName,
    refundReason: pick(row, ['退款原因', '退货原因', '售后原因', '原因', '退款类型', '退货类型', 'reason']),
    refundOrders: parseMetric(pick(row, ['退款订单数', '退款笔数', '退款人数', '成功退款笔数', '成功退款订单数', '退货退款订单数', 'refundOrders', 'refundCount'])),
    trafficSource: trafficInfo.name,
    trafficDepth: trafficInfo.depth,
    trafficPath: trafficInfo.path,
    trafficLevel1: trafficInfo.levels?.[0] || '',
    trafficLevel2: trafficInfo.levels?.[1] || '',
    trafficLevel3: trafficInfo.levels?.[2] || '',
    trafficLevel4: trafficInfo.levels?.[3] || '',
    promotionName: reportKind === 'promotion' ? rawPromotionName || rawItemName || '推广整体' : rawPromotionName,
    activityName: pick(row, ['活动名称', '平台活动', '活动', 'activityName']),
    sales: sales || parseMetric(pick(row, ['成交金额', '直播成交金额', '店播成交金额', '播中成交金额', '播后成交金额', '客服支付金额', '净支付金额', '内容成交金额'])),
    prevSales,
    visitors: visitors || parseMetric(pick(row, ['商品访客数', '观看人数', '内容曝光量', '内容浏览量', '咨询人数', '接待人数'])),
    prevVisitors,
    orders: orders || parseMetric(pick(row, ['成交笔数', '成交件数', '支付件数', '内容成交件数'])),
    spend: parseMetric(pick(row, ['花费', '消耗', '推广花费', '全站推广花费', '关键词推广花费', '精准人群推广花费', '智能场景花费', '淘宝客佣金', 'spend', 'cost'])),
    clicks: parseMetric(pick(row, ['点击量', '点击', 'clicks'])),
    impressions: parseMetric(pick(row, ['展现量', '曝光量', '浏览量', '店铺浏览量', '商品浏览量', '引入商详浏览量', '搜索曝光次数', '详情曝光', '自然流量曝光量', 'impressions'])),
    addCarts: parseMetric(pick(row, ['加购数', '加购', '购物车', '购物车数', '总购物车数', '加购件数', '加购人数', '加购客户数', '加购商品件数', '详情加购', 'addCarts'])),
    favorites: parseMetric(pick(row, ['商品收藏人数', '收藏人数', '内容收藏人数', 'favorites'])),
    pageViews: parseMetric(pick(row, ['浏览量', '店铺浏览量', '商品浏览量', '引入商详浏览量', 'pageViews'])),
    bounceRate: parseRateMetric(pick(row, ['跳失率', 'bounceRate'])),
    avgStay: parseMetric(pick(row, ['平均停留时长', '店铺平均停留时长', '商品平均停留时长', '商详平均停留时长', '停留时长', 'avgStay'])),
    oldVisitors: parseMetric(pick(row, ['老访客数', 'oldVisitors'])),
    newVisitors: parseMetric(pick(row, ['新访客数', '客户新访', 'newVisitors'])),
    followStoreUsers: parseMetric(pick(row, ['关注店铺人数', 'followStoreUsers'])),
    liveVisitors: parseMetric(pick(row, ['直播间访客数', '观看人数', 'liveVisitors'])),
    liveClickUsers: parseMetric(pick(row, ['商品点击人数', '直播点击人数', 'liveClickUsers'])),
    liveClickRate: parseRateMetric(pick(row, ['观看-商品点击率', 'liveClickRate'])),
    liveHours: parseMetric(pick(row, ['开播时长', 'liveHours'])),
    shortVideoVisitors: parseMetric(pick(row, ['短视频访客数', '内容曝光量', 'shortVideoVisitors'])),
    contentVisitors: parseMetric(pick(row, ['图文访客数', '内容查看人数', '内容浏览量', 'contentVisitors'])),
    storePageVisitors: parseMetric(pick(row, ['店铺页访客数', 'storePageVisitors'])),
    shopCustomers: parseMetric(pick(row, ['店铺客户数', 'shopCustomers'])),
    unpurchasedReturning: parseMetric(pick(row, ['未购客户回访', 'unpurchasedReturning'])),
    purchasedReturning: parseMetric(pick(row, ['已购客户回访', 'purchasedReturning'])),
    conversion: conversion || parseRateMetric(pick(row, ['点击-成交转化率', '观看-商品点击率', '内容成交转化率', '询单转化率', '客服响应率'])),
    aov,
    netSales: parseMetric(pick(row, ['净销售额', '净支付金额', '净成交金额', 'netSales'])),
    oldBuyerSales: parseMetric(pick(row, ['老买家支付金额', '老客复购金额', '老客成交金额', 'oldBuyerSales'])),
    uvValue: parseMetric(pick(row, ['UV价值', '访客平均价值', 'uvValue'])),
    refundAmount: parseMetric(pick(row, ['退款金额', '取消及售后退款金额', '成功退款金额', 'refundAmount'])),
    refundRate: parseRateMetric(pick(row, ['退款率', '退货率', '成功退款率', '金额退款率', '订单退款率', 'refundRate'])),
    roi: parseMetric(pick(row, ['ROI', '投放ROI', '投产比', '投入产出比', '含预售投产比', 'roi'])),
    productCount: parseMetric(pick(row, ['商品总数', '商品数', '上架spu数', '访问spu数', 'productCount'])),
    activeProductCount: parseMetric(pick(row, ['有成交商品数', '动销商品数', '动销spu数', '加购spu数', 'activeProductCount'])),
    topSkuShare: parseMetric(pick(row, ['TOPSKU销售占比', 'TOP SKU销售占比', '爆款占比', 'topSkuShare'])),
    serviceRate: parseRateMetric(pick(row, ['客服响应达标率', '客服响应率', '旺旺满意度', '24小时揽收及时率', '48小时揽收及时率', 'serviceRate'])),
    searchShare: parseMetric(pick(row, ['搜索占比', '搜索', 'searchShare'])),
    recommendShare: parseMetric(pick(row, ['推荐占比', '推荐', 'recommendShare'])),
    contentShare: parseMetric(pick(row, ['内容占比', '内容', 'contentShare'])),
    paidShare: parseMetric(pick(row, ['付费占比', '付费', 'paidShare'])),
    privateShare: parseMetric(pick(row, ['私域占比', '私域', 'privateShare']))
  };
}

function weightedAverage(rows, key, weightKey = 'sales') {
  const usable = rows.filter((row) => row[key] > 0);
  const weightTotal = usable.reduce((sum, row) => sum + Math.max(row[weightKey] || 0, 1), 0);
  if (!usable.length || !weightTotal) return 0;
  return usable.reduce((sum, row) => sum + row[key] * Math.max(row[weightKey] || 0, 1), 0) / weightTotal;
}

function dateRangeLabel(rows) {
  const stamps = rows
    .map((row) => parseDateToken(row.date))
    .filter((stamp) => Number.isFinite(stamp))
    .sort((a, b) => a - b);
  if (stamps.length) {
    const first = formatDateStamp(stamps[0]);
    const last = formatDateStamp(stamps[stamps.length - 1]);
    return first === last ? first : `${first} 至 ${last}`;
  }
  const dates = rows.map((row) => formatReportDateLabel(row.date)).filter(Boolean).sort();
  if (!dates.length) return '';
  return dates[0] === dates[dates.length - 1] ? dates[0] : `${dates[0]} 至 ${dates[dates.length - 1]}`;
}

function toDateStamp(year, month, day) {
  const date = new Date(Number(year), Number(month) - 1, Number(day));
  if (date.getFullYear() !== Number(year) || date.getMonth() !== Number(month) - 1 || date.getDate() !== Number(day)) return null;
  return date.getTime();
}

function formatDateStamp(stamp) {
  const date = new Date(stamp);
  const pad = (value) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function parseDateToken(value) {
  if (value === null || value === undefined || value === '') return null;
  const text = String(value).trim();
  const compactNumber = Number(text);
  const normalizedText = Number.isFinite(compactNumber) && compactNumber >= 20000101 && compactNumber <= 20991231
    ? String(Math.round(compactNumber))
    : text;
  const match = normalizedText.match(/(20\d{2})[-年_/.]?(1[0-2]|0?[1-9])[-月_/.]?([12]\d|3[01]|0?[1-9])日?/);
  if (!match) return null;
  return toDateStamp(match[1], match[2], match[3]);
}

function formatReportDateLabel(value) {
  if (value === null || value === undefined || value === '') return '';
  const stamp = parseDateToken(value);
  if (Number.isFinite(stamp)) return formatDateStamp(stamp);
  const text = String(value).trim();
  return text;
}

function formatGroupLabel(value) {
  const text = String(value || '').trim();
  return formatReportDateLabel(text) || text || '-';
}

function buildDateRange(start, end) {
  if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
  const rangeStart = Math.min(start, end);
  const rangeEnd = Math.max(start, end);
  const days = Math.round((rangeEnd - rangeStart) / 86400000) + 1;
  return {
    start: rangeStart,
    end: rangeEnd,
    days,
    label: `${formatDateStamp(rangeStart)} 至 ${formatDateStamp(rangeEnd)}`
  };
}

function parseRangeFromText(text) {
  const source = String(text || '');
  const dateTokenSource = '20\\d{2}[-年_/.]?(?:1[0-2]|0?[1-9])[-月_/.]?(?:[12]\\d|3[01]|0?[1-9])日?';
  const datePattern = new RegExp(dateTokenSource, 'g');
  const pair = source.match(new RegExp(`(${dateTokenSource})[^+\\n]{0,30}(${dateTokenSource})`));
  if (pair) {
    const first = parseDateToken(pair[1]);
    const second = parseDateToken(pair[2]);
    const range = buildDateRange(first, second);
    if (range) return range;
  }
  const tokens = Array.from(source.matchAll(datePattern))
    .map((match) => parseDateToken(match[1]))
    .filter((stamp) => Number.isFinite(stamp));
  const unique = Array.from(new Set(tokens)).sort((a, b) => a - b);
  if (unique.length < 2) return null;
  const compactRange = buildDateRange(unique[0], unique[unique.length - 1]);
  if (compactRange && compactRange.days <= 45) return compactRange;
  return buildDateRange(tokens[0], tokens[1]);
}

function rowInDateRange(row, range) {
  if (!range) return true;
  const stamp = parseDateToken(row.date);
  if (!stamp) return true;
  return stamp >= range.start && stamp <= range.end;
}

function overallSourcePriority(row) {
  const source = String(row.sourceFile || '');
  if (/首页-数据概览/.test(source)) return 100;
  if (/店铺经营核心|经营核心|交易概况/.test(source)) return 90;
  if (/店铺绩效|业绩分析/.test(source)) return 70;
  if (/流量概况|流量看板|流量总览/.test(source)) return 30;
  return 10;
}

function coreValueScore(row) {
  return ['sales', 'visitors', 'orders', 'conversion', 'aov', 'refundAmount', 'refundRate']
    .reduce((score, key) => score + ((row[key] || 0) > 0 ? 1 : 0), 0);
}

function aggregateRows(rows) {
  const sales = rows.reduce((sum, row) => sum + row.sales, 0);
  const prevSales = rows.reduce((sum, row) => sum + (row.prevSales || 0), 0);
  const visitors = rows.reduce((sum, row) => sum + row.visitors, 0);
  const prevVisitors = rows.reduce((sum, row) => sum + (row.prevVisitors || 0), 0);
  const orders = rows.reduce((sum, row) => sum + row.orders, 0);
  const refundAmount = rows.reduce((sum, row) => sum + (row.refundAmount || 0), 0);
  const netSales = rows.reduce((sum, row) => sum + (row.netSales || 0), 0);
  const oldBuyerSales = rows.reduce((sum, row) => sum + (row.oldBuyerSales || 0), 0);
  const importedRefundRate = weightedAverage(rows, 'refundRate');
  const importedConversion = weightedAverage(rows, 'conversion', 'visitors');
  const importedAov = weightedAverage(rows, 'aov', 'sales');
  const trafficRows = rows.filter((row) => row.reportKind === 'trafficOverview');
  const memberRows = rows.filter((row) => row.reportKind === 'member');
  return {
    sales,
    prevSales,
    visitors,
    prevVisitors,
    orders,
    conversion: importedConversion || (visitors ? orders / visitors * 100 : 0),
    aov: importedAov || (orders ? sales / orders : 0),
    refundAmount,
    netSales,
    oldBuyerSales,
    refundRate: importedRefundRate || (sales ? refundAmount / sales * 100 : 0),
    roi: weightedAverage(rows, 'roi'),
    pageViews: rows.reduce((sum, row) => sum + (row.pageViews || 0), 0),
    bounceRate: weightedAverage(rows, 'bounceRate', 'visitors'),
    avgStay: weightedAverage(rows, 'avgStay', 'visitors'),
    oldVisitors: rows.reduce((sum, row) => sum + (row.oldVisitors || 0), 0),
    newVisitors: rows.reduce((sum, row) => sum + (row.newVisitors || 0), 0),
    followStoreUsers: rows.reduce((sum, row) => sum + (row.followStoreUsers || 0), 0),
    liveVisitors: rows.reduce((sum, row) => sum + (row.liveVisitors || 0), 0),
    liveClickUsers: rows.reduce((sum, row) => sum + (row.liveClickUsers || 0), 0),
    liveClickRate: weightedAverage(rows, 'liveClickRate', 'liveVisitors'),
    liveHours: rows.reduce((sum, row) => sum + (row.liveHours || 0), 0),
    shortVideoVisitors: rows.reduce((sum, row) => sum + (row.shortVideoVisitors || 0), 0),
    contentVisitors: rows.reduce((sum, row) => sum + (row.contentVisitors || 0), 0),
    storePageVisitors: rows.reduce((sum, row) => sum + (row.storePageVisitors || 0), 0),
    shopCustomers: rows.reduce((sum, row) => sum + (row.shopCustomers || 0), 0),
    unpurchasedReturning: rows.reduce((sum, row) => sum + (row.unpurchasedReturning || 0), 0),
    purchasedReturning: rows.reduce((sum, row) => sum + (row.purchasedReturning || 0), 0),
    hasTrafficOverview: trafficRows.length > 0,
    hasMemberOverview: memberRows.length > 0,
    productCount: Math.max(...rows.map((row) => row.productCount || 0), 0),
    activeProductCount: Math.max(...rows.map((row) => row.activeProductCount || 0), 0),
    topSkuShare: weightedAverage(rows, 'topSkuShare'),
    serviceRate: weightedAverage(rows, 'serviceRate', 'visitors'),
    searchShare: weightedAverage(rows, 'searchShare'),
    recommendShare: weightedAverage(rows, 'recommendShare'),
    contentShare: weightedAverage(rows, 'contentShare'),
    paidShare: weightedAverage(rows, 'paidShare'),
    privateShare: weightedAverage(rows, 'privateShare')
  };
}

function groupRows(rows, key, limit = 8) {
  const map = new Map();
  rows.forEach((row) => {
    const name = row[key];
    if (!name) return;
    if (!map.has(name)) {
      map.set(name, { name, sales: 0, visitors: 0, orders: 0, spend: 0, clicks: 0, impressions: 0, addCarts: 0, favorites: 0, refundAmount: 0, netSales: 0, oldBuyerSales: 0, liveVisitors: 0, liveClickUsers: 0, liveHours: 0, rows: [] });
    }
    const item = map.get(name);
    item.sales += row.sales || 0;
    item.visitors += row.visitors || 0;
    item.orders += row.orders || 0;
    item.spend += row.spend || 0;
    item.clicks += row.clicks || 0;
    item.impressions += row.impressions || 0;
    item.addCarts += row.addCarts || 0;
    item.favorites += row.favorites || 0;
    item.refundAmount += row.refundAmount || 0;
    item.netSales += row.netSales || 0;
    item.oldBuyerSales += row.oldBuyerSales || 0;
    item.liveVisitors += row.liveVisitors || 0;
    item.liveClickUsers += row.liveClickUsers || 0;
    item.liveHours += row.liveHours || 0;
    item.rows.push(row);
  });
  return Array.from(map.values()).map((item) => ({
    ...item,
    conversion: weightedAverage(item.rows, 'conversion', 'visitors') || (item.visitors ? item.orders / item.visitors * 100 : 0),
    liveClickRate: weightedAverage(item.rows, 'liveClickRate', 'liveVisitors') || (item.liveVisitors ? item.liveClickUsers / item.liveVisitors * 100 : 0),
    refundRate: weightedAverage(item.rows, 'refundRate', 'sales') || (item.sales ? item.refundAmount / item.sales * 100 : 0),
    uvValue: weightedAverage(item.rows, 'uvValue', 'visitors') || (item.visitors ? item.sales / item.visitors : 0),
    roi: item.spend ? item.sales / item.spend : weightedAverage(item.rows, 'roi'),
    note: rankingNote(item, key)
  })).sort((a, b) => b.sales - a.sales).slice(0, limit);
}

function buildDailyRows(rows, limit = 10) {
  const source = rows.filter((row) => (
    row.date &&
    parseDateToken(row.date) &&
    ['overall', 'shopPerformance'].includes(row.reportKind) &&
    (row.sales || row.visitors || row.orders || row.refundAmount || row.conversion)
  ));
  const map = new Map();
  source.forEach((row) => {
    const rawDate = String(row.date || '').trim();
    const name = formatReportDateLabel(rawDate);
    if (!rawDate || !name) return;
    if (!map.has(rawDate)) {
      map.set(rawDate, { name, date: name, rawDate, sales: 0, visitors: 0, orders: 0, refundAmount: 0, netSales: 0, rows: [] });
    }
    const item = map.get(rawDate);
    item.sales += row.sales || 0;
    item.visitors += row.visitors || 0;
    item.orders += row.orders || 0;
    item.refundAmount += row.refundAmount || 0;
    item.netSales += row.netSales || 0;
    item.rows.push(row);
  });
  return Array.from(map.values()).map((item) => ({
    ...item,
    conversion: weightedAverage(item.rows, 'conversion', 'visitors') || (item.visitors ? item.orders / item.visitors * 100 : 0),
    netSales: item.netSales || Math.max(0, item.sales - item.refundAmount),
    dateStamp: parseDateToken(item.rawDate || item.date) || 0
  })).sort((a, b) => b.dateStamp - a.dateStamp || String(b.date).localeCompare(String(a.date))).slice(0, limit);
}

function rankingNote(item, key) {
  if (key === 'promotionName') {
    if (item.spend && item.roi < 2) return 'ROI偏低，需控预算或查承接';
    if (item.spend && item.roi >= 3) return '效率较好，可保留预算并小幅测试扩量';
    return '需补点击/加购/成交数据后再决定预算';
  }
  if (key === 'trafficSource') {
    if (item.conversion < 1) return '流量成交效率偏低';
    if (item.conversion >= 3) return '转化表现较好';
    return '需补来源层级、加购和跳失数据，判断入口质量与页面承接';
  }
  if (key === 'activityName') {
    return item.sales ? '记录活动成交，复盘活动承接' : '需补充活动成交数据';
  }
  if (key === 'categoryName') {
    if (!item.sales && item.visitors) return '有访客无成交，暂不扩充该类目 SKU，先核查入口词和主推款';
    if (item.refundAmount > Math.max(item.sales * 0.12, 500)) return '类目退款侵蚀明显，先定位高退款 SKU 后再做放量';
    if (item.visitors >= 1000 && item.conversion < 1) return '类目高访低转，优先重排主推款和类目承接页';
    if (item.sales >= 10000 && item.conversion >= 1) return '核心成交类目，优先保库存、保搜索词和内容曝光';
    if (item.sales > 0 && item.visitors < 200 && item.conversion >= 2) return '小流量有成交，可补内容/搜索入口做二次测试';
    return '类目贡献偏中腰部，建议按销售占比和毛利决定是否保留资源';
  }
  if (item.sales > 0 && item.refundAmount > item.sales) return '退款高于本期支付，疑似历史订单退款，先核查退款归属';
  if (item.refundRate >= 50) return '退款对成交质量影响较大，暂停放量，优先核查规格/口感/页面承诺';
  if (item.refundRate >= 15 || item.refundAmount > Math.max(item.sales * 0.12, 500)) return '退款偏高，先改详情页预期、客服话术和售后原因';
  if (item.visitors >= 1000 && item.conversion < 0.5) return '高访低转，不建议加流量，先修主图首屏和价格理由';
  if (item.visitors >= 500 && item.conversion < 1) return '有流量但承接弱，优先检查主图、规格选择和评价证据';
  if (!item.sales && item.visitors) return '有访客无成交，先排查标题关键词、首图和价格带';
  if (item.sales >= 5000 && item.conversion >= 2 && item.refundRate < 10) return '成交与退款相对健康，可作为主推款继续维护';
  if (item.sales >= 2000 && item.orders <= 2) return '高客单低单量，核查是否依赖少数订单，谨慎判断主推价值';
  if (item.conversion >= 5 && item.visitors < 120) return '小流量高转化，可补搜索/内容流量做放量测试';
  if (item.sales > 0 && item.conversion >= 3) return '成交效率较好，补充流量后观察是否稳定放大';
  if (item.sales > 0) return '有成交但证据不足，需补加购/咨询/退款原因后定主推级别';
  return '数据不足，需补访客、支付买家和退款原因后判断';
}

function groupRefundReasons(rows, limit = 8) {
  const map = new Map();
  rows.forEach((row) => {
    const reason = row.refundReason || '未标明原因';
    if (!map.has(reason)) {
      map.set(reason, { reason, refundAmount: 0, refundOrders: 0, rows: 0, products: new Map() });
    }
    const item = map.get(reason);
    item.refundAmount += row.refundAmount || 0;
    item.refundOrders += row.refundOrders || (row.refundAmount || row.refundRate ? 1 : 0);
    item.rows += 1;
    if (row.itemName) {
      const product = item.products.get(row.itemName) || { name: row.itemName, refundAmount: 0, refundOrders: 0 };
      product.refundAmount += row.refundAmount || 0;
      product.refundOrders += row.refundOrders || (row.refundAmount || row.refundRate ? 1 : 0);
      item.products.set(row.itemName, product);
    }
  });
  return Array.from(map.values()).map((item) => {
    const topProduct = Array.from(item.products.values()).sort((a, b) => b.refundAmount - a.refundAmount || b.refundOrders - a.refundOrders)[0];
    return {
      reason: item.reason,
      refundAmount: item.refundAmount,
      refundOrders: item.refundOrders,
      rows: item.rows,
      topProduct: topProduct?.name || ''
    };
  }).sort((a, b) => b.refundAmount - a.refundAmount || b.refundOrders - a.refundOrders).slice(0, limit);
}

function buildImportedDetails(rows) {
  const productRows = rows.filter((row) => row.reportKind === 'product' || (!row.forcedReportKind && row.itemName && row.reportKind !== 'promotion'));
  const categoryRows = rows.filter((row) => row.reportKind === 'category' || (!row.forcedReportKind && row.categoryName));
  const allTrafficRows = rows.filter((row) => row.reportKind === 'traffic' || (!row.forcedReportKind && row.trafficSource));
  const trafficRows = allTrafficRows.some((row) => row.trafficDepth >= 2)
    ? allTrafficRows.filter((row) => row.trafficDepth >= 2)
    : allTrafficRows;
  const promotionRows = rows.filter((row) => row.reportKind === 'promotion' || (!row.forcedReportKind && row.promotionName));
  const activityRows = rows.filter((row) => row.reportKind === 'activity' || (!row.forcedReportKind && row.activityName));
  const liveRows = rows.filter((row) => row.reportKind === 'live' || (!row.forcedReportKind && row.liveName));
  const contentRows = rows.filter((row) => row.reportKind === 'content' || (!row.forcedReportKind && row.contentName));
  const serviceRows = rows.filter((row) => ['service', 'shopPerformance'].includes(row.reportKind) || (!row.forcedReportKind && row.serviceName));
  const refundRows = rows.filter((row) => (
    row.reportKind === 'refund' ||
    (!row.forcedReportKind && row.refundReason) ||
    (!row.forcedReportKind && row.itemName && (row.refundAmount || row.refundRate))
  ));
  const productDetails = groupRows(productRows.length ? productRows : rows, 'itemName', 8);
  const productDetailsAll = groupRows(productRows.length ? productRows : rows, 'itemName', 500);
  return {
    products: productDetails,
    productsAll: productDetailsAll,
    categories: groupRows(categoryRows, 'categoryName'),
    daily: buildDailyRows(rows),
    refundReasons: groupRefundReasons(refundRows),
    live: groupRows(liveRows, 'liveName'),
    content: groupRows(contentRows, 'contentName'),
    service: groupRows(serviceRows, 'serviceName'),
    traffic: groupRows(trafficRows.length ? trafficRows : rows, 'trafficSource'),
    promotion: groupRows(promotionRows.length ? promotionRows : rows, 'promotionName'),
    activity: groupRows(activityRows.length ? activityRows : rows, 'activityName')
  };
}

function sanitizeTrafficDetails(items, totalSales, totalVisitors) {
  if (!items || !items.length) return [];
  const filtered = items.filter((item) => {
    const salesOk = !totalSales || !item.sales || item.sales <= totalSales * 1.08;
    const visitorsOk = !totalVisitors || !item.visitors || item.visitors <= totalVisitors * 1.2;
    return salesOk && visitorsOk;
  });
  return filtered.length ? filtered : items;
}

function deriveProductStats(rows, totalSales) {
  const productRows = rows.filter((row) => row.reportKind === 'product' || (!row.forcedReportKind && row.itemName));
  const grouped = groupRows(productRows, 'itemName', 9999);
  const active = grouped.filter((item) => item.sales > 0 || item.orders > 0);
  const topSales = grouped.reduce((max, item) => Math.max(max, item.sales || 0), 0);
  return {
    productCount: grouped.length,
    activeProductCount: active.length,
    topSkuShare: totalSales && topSales ? topSales / totalSales * 100 : 0
  };
}

function sumTrafficVisitors(rows, matcher) {
  return rows.reduce((sum, row) => sum + (matcher(row) ? row.visitors || 0 : 0), 0);
}

function deriveStructuredChannelShares(rows) {
  const trafficRows = rows.filter((row) => (row.reportKind === 'traffic' || !row.forcedReportKind) && row.trafficLevel1 && row.visitors > 0);
  if (!trafficRows.length) return null;
  const rootRows = trafficRows.filter((row) => row.trafficDepth === 1);
  const businessRoot = rootRows.find((row) => /经营优势/.test(row.trafficLevel1));
  const paidRoot = rootRows.find((row) => /付费|推广/.test(row.trafficLevel1));
  const privateRoot = rootRows.find((row) => /主动回访|私域|会员|老客/.test(row.trafficLevel1));
  if (!businessRoot && !paidRoot && !privateRoot) return null;

  const businessRows = trafficRows.filter((row) => row.trafficLevel1 === businessRoot?.trafficLevel1 && row.trafficDepth >= 2);
  const searchShareBase = sumTrafficVisitors(businessRows, (row) => /搜索|关键词|搜/.test(row.trafficLevel2 || row.trafficSource));
  const contentShareBase = sumTrafficVisitors(businessRows, (row) => /内容|短视频|直播|图文|逛逛|种草/.test(row.trafficLevel2 || row.trafficSource));
  const businessTotal = businessRoot?.visitors || sumTrafficVisitors(businessRows, () => true);
  const recommendShareBase = Math.max(0, businessTotal - searchShareBase - contentShareBase);

  const paidShareBase = paidRoot?.visitors || sumTrafficVisitors(trafficRows, (row) => /付费|推广|直通车|万相台|引力魔方|无界|淘宝客|品销宝|钻展|千川|京准通/.test(row.trafficPath || row.trafficSource));
  const privateShareBase = privateRoot?.visitors || sumTrafficVisitors(trafficRows, (row) => /主动回访|私域|会员|老客|老买家|购物车|收藏|我的淘宝|我的京东|关注|消息/.test(row.trafficPath || row.trafficSource));
  const total = searchShareBase + recommendShareBase + contentShareBase + paidShareBase + privateShareBase;
  if (!total) return null;
  return {
    searchShare: searchShareBase / total * 100,
    recommendShare: recommendShareBase / total * 100,
    contentShare: contentShareBase / total * 100,
    paidShare: paidShareBase / total * 100,
    privateShare: privateShareBase / total * 100
  };
}

function deriveChannelShares(rows) {
  const structured = deriveStructuredChannelShares(rows);
  if (structured) return structured;
  const buckets = { searchShare: 0, recommendShare: 0, contentShare: 0, paidShare: 0, privateShare: 0 };
  const allTrafficRows = rows.filter((row) => (row.reportKind === 'traffic' || !row.forcedReportKind) && row.trafficSource && row.visitors > 0);
  const trafficRows = allTrafficRows.some((row) => row.trafficDepth >= 2)
    ? allTrafficRows.filter((row) => row.trafficDepth >= 2)
    : allTrafficRows;
  trafficRows.forEach((row) => {
    const name = row.trafficSource;
    if (/搜索|关键词|搜/.test(name)) buckets.searchShare += row.visitors;
    else if (/推荐|猜你喜欢|首页|频道|商品/.test(name)) buckets.recommendShare += row.visitors;
    else if (/内容|短视频|直播|图文|逛逛|种草/.test(name)) buckets.contentShare += row.visitors;
    else if (/付费|推广|直通车|万相台|引力魔方|品销宝|钻展|千川|京准通/.test(name)) buckets.paidShare += row.visitors;
    else if (/私域|会员|老客|老买家|主动回访|购物车|收藏|我的淘宝|我的京东|店铺/.test(name)) buckets.privateShare += row.visitors;
  });
  const total = Object.values(buckets).reduce((sum, value) => sum + value, 0);
  if (!total) return { searchShare: 0, recommendShare: 0, contentShare: 0, paidShare: 0, privateShare: 0 };
  return Object.fromEntries(Object.entries(buckets).map(([key, value]) => [key, value / total * 100]));
}

function rowModuleNames(row) {
  const modules = [];
  const allowFallback = !row.forcedReportKind;
  if (row.reportKind === 'overall' && (row.sales || row.visitors || row.orders)) modules.push('店铺整体');
  if (row.reportKind === 'trafficOverview' && row.visitors) modules.push('流量总览');
  if ((row.reportKind === 'traffic' || (allowFallback && row.trafficSource)) && row.trafficSource) modules.push('流量排行');
  if ((row.reportKind === 'product' || (allowFallback && row.itemName)) && row.itemName) modules.push('宝贝排行');
  if (row.reportKind === 'category' || (allowFallback && row.categoryName)) modules.push('品类/类目');
  if (row.reportKind === 'promotion' || (allowFallback && row.promotionName)) modules.push('推广情况');
  if (row.reportKind === 'live' || (allowFallback && row.liveName)) modules.push('直播业绩');
  if (row.reportKind === 'content' || (allowFallback && row.contentName)) modules.push('内容资产');
  if (row.reportKind === 'member') modules.push('客户/会员');
  if (row.reportKind === 'service' || row.reportKind === 'shopPerformance' || (allowFallback && row.serviceName)) modules.push('客服/店铺绩效');
  if (row.reportKind === 'refund' || (allowFallback && row.refundAmount) || (allowFallback && row.refundRate)) modules.push('退款售后');
  if (row.reportKind === 'activity' || (allowFallback && row.activityName)) modules.push('活动情况');
  return Array.from(new Set(modules));
}

function buildImportSummary(mapped, rawRows, skippedFiles = []) {
  const fileMap = new Map();
  rawRows.forEach((row) => {
    const name = row.来源文件 || row.sourceFile || '未知文件';
    if (!fileMap.has(name)) {
      fileMap.set(name, { name, rawRows: 0, usedRows: 0, modules: new Set(), kinds: new Map(), status: '已读取', note: '' });
    }
    fileMap.get(name).rawRows += 1;
  });
  mapped.forEach((row) => {
    const name = row.sourceFile || row.来源文件 || '未知文件';
    if (!fileMap.has(name)) {
      fileMap.set(name, { name, rawRows: 0, usedRows: 0, modules: new Set(), kinds: new Map(), status: '已读取', note: '' });
    }
    const item = fileMap.get(name);
    const modules = rowModuleNames(row);
    if (modules.length) item.usedRows += 1;
    modules.forEach((moduleName) => item.modules.add(moduleName));
    item.kinds.set(row.reportKind || 'unknown', (item.kinds.get(row.reportKind || 'unknown') || 0) + 1);
  });
  skippedFiles.forEach((name) => {
    fileMap.set(name, { name, rawRows: 0, usedRows: 0, modules: new Set(), kinds: new Map(), status: '未读取', note: '文件可能加密、损坏，或格式暂未支持' });
  });
  return Array.from(fileMap.values()).map((item) => {
    const modules = Array.from(item.modules);
    const kindEntries = Array.from(item.kinds.entries()).sort((a, b) => b[1] - a[1]);
    const dominantKind = kindEntries[0]?.[0] || 'unknown';
    const kinds = kindEntries.map(([name, count]) => `${reportKindLabel(name)}:${count}`).join('，');
    return {
      name: item.name,
      rawRows: item.rawRows,
      usedRows: item.usedRows,
      status: item.status,
      modules,
      dominantKind,
      kinds,
      note: item.note || (modules.length ? `已进入：${modules.join('、')}` : '已读取但没有匹配到可用于当前报告的关键字段')
    };
  });
}

function matchedFields(row, aliases) {
  const keys = Object.keys(row);
  return aliases.flatMap((alias) => {
    const target = normalizeKey(alias);
    const key = keys.find((item) => normalizeKey(item) === target);
    return key !== undefined && row[key] !== '' ? [key] : [];
  });
}

function buildDataLineage(rawRows) {
  return metricLineageSpecs().map((spec) => {
    const fileMap = new Map();
    const fieldSet = new Set();
    rawRows.forEach((row) => {
      const fields = matchedFields(row, spec.aliases);
      if (!fields.length) return;
      const file = row.来源文件 || row.sourceFile || '未知文件';
      fileMap.set(file, (fileMap.get(file) || 0) + 1);
      fields.forEach((field) => fieldSet.add(field));
    });
    const files = Array.from(fileMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4)
      .map(([file, count]) => `${file}（${count}行）`);
    const fields = Array.from(fieldSet).slice(0, 8);
    return {
      key: spec.key,
      files,
      fields,
      status: files.length ? '已匹配来源字段' : '待补充来源字段'
    };
  });
}

function buildImportedAux(current, mapped, previous = {}) {
  const trafficRows = mapped.filter((row) => row.reportKind === 'trafficOverview');
  const memberRows = mapped.filter((row) => row.reportKind === 'member');
  const latestTraffic = trafficRows.find((row) => String(row.sourceCategory || '').includes('我的')) || trafficRows[0] || {};
  const latestMember = memberRows[0] || {};
  const activeReturnRows = mapped.filter((row) => (
    (row.reportKind === 'traffic' || !row.forcedReportKind) &&
    /主动回访|老客|老买家|我的淘宝|购物车|消息|收藏/.test(row.trafficPath || row.trafficSource || '')
  ));
  const activeReturnSales = activeReturnRows.reduce((sum, row) => sum + (row.sales || 0), 0);
  const activeReturnVisitors = activeReturnRows.reduce((sum, row) => sum + (row.visitors || 0), 0);
  const activeReturnOrders = activeReturnRows.reduce((sum, row) => sum + (row.orders || 0), 0);
  return {
    pageViews: current.pageViews || latestTraffic.pageViews || 0,
    bounceRate: current.bounceRate || latestTraffic.bounceRate || 0,
    avgStay: current.avgStay || latestTraffic.avgStay || 0,
    oldVisitors: current.oldVisitors || latestTraffic.oldVisitors || 0,
    newVisitors: current.newVisitors || latestTraffic.newVisitors || latestMember.newVisitors || 0,
    followStoreUsers: current.followStoreUsers || latestTraffic.followStoreUsers || 0,
    liveVisitors: current.liveVisitors || latestTraffic.liveVisitors || 0,
    shortVideoVisitors: current.shortVideoVisitors || latestTraffic.shortVideoVisitors || 0,
    contentVisitors: current.contentVisitors || latestTraffic.contentVisitors || 0,
    storePageVisitors: current.storePageVisitors || latestTraffic.storePageVisitors || 0,
    shopCustomers: current.shopCustomers || latestMember.shopCustomers || 0,
    unpurchasedReturning: current.unpurchasedReturning || latestMember.unpurchasedReturning || 0,
    purchasedReturning: current.purchasedReturning || latestMember.purchasedReturning || 0,
    refundAmount: current.refundAmount || 0,
    prevRefundAmount: previous.refundAmount || 0,
    netSales: current.netSales || Math.max(0, (current.sales || 0) - (current.refundAmount || 0)),
    prevNetSales: previous.netSales || Math.max(0, (previous.sales || 0) - (previous.refundAmount || 0)),
    oldBuyerSales: current.oldBuyerSales || 0,
    activeReturnSales,
    activeReturnVisitors,
    activeReturnOrders,
    activeReturnConversion: activeReturnVisitors ? activeReturnOrders / activeReturnVisitors * 100 : 0,
    activeReturnUvValue: activeReturnVisitors ? activeReturnSales / activeReturnVisitors : 0,
    hasTrafficOverview: Boolean(trafficRows.length),
    hasMemberOverview: Boolean(memberRows.length)
  };
}

function pickCurrentOverallRows(rows) {
  const overallRows = rows.filter((row) => row.reportKind === 'overall' && row.bucket !== 'benchmark');
  if (!overallRows.length) return [];
  const ownRows = overallRows.filter((row) => !row.sourceCategory || String(row.sourceCategory).includes('本店'));
  const source = ownRows.length ? ownRows : overallRows;
  const homepageRows = source
    .filter((row) => /首页-数据概览/.test(row.sourceFile || '') && coreValueScore(row) >= 3)
    .sort((a, b) => a.rowIndex - b.rowIndex);
  if (homepageRows.length) return [homepageRows[0]];
  const ranked = source
    .filter((row) => coreValueScore(row) > 0)
    .sort((a, b) => (
      overallSourcePriority(b) - overallSourcePriority(a) ||
      coreValueScore(b) - coreValueScore(a) ||
      a.rowIndex - b.rowIndex
    ));
  const best = ranked[0];
  if (!best) return [];
  if (!best.date) return [best];
  const sameDate = ranked.filter((row) => (
    row.date === best.date &&
    overallSourcePriority(row) === overallSourcePriority(best)
  ));
  return sameDate.length ? sameDate : [best];
}

function pickPreviousOverallRows(rows, currentRows) {
  const current = currentRows[0] || {};
  if (/首页-数据概览/.test(current.sourceFile || '')) {
    const homepageRows = rows
      .filter((row) => row.reportKind === 'overall' && row.bucket !== 'benchmark' && row.sourceFile === current.sourceFile && row.rowIndex > current.rowIndex)
      .sort((a, b) => a.rowIndex - b.rowIndex);
    if (homepageRows.length) return [homepageRows[0]];
  }
  const currentDate = currentRows.find((row) => row.date)?.date;
  const currentCategory = currentRows.find((row) => row.sourceCategory)?.sourceCategory;
  const source = rows.filter((row) => (
    row.reportKind === 'overall' &&
    row.bucket !== 'benchmark' &&
    row.date &&
    row.date !== currentDate &&
    (!currentCategory || row.sourceCategory === currentCategory)
  ));
  const ranked = source.sort((a, b) => (
    overallSourcePriority(b) - overallSourcePriority(a) ||
    coreValueScore(b) - coreValueScore(a) ||
    a.rowIndex - b.rowIndex
  ));
  const firstDate = ranked.find((row) => row.date)?.date;
  return firstDate ? ranked.filter((row) => row.date === firstDate && overallSourcePriority(row) === overallSourcePriority(ranked[0])) : ranked.slice(0, 1);
}

function isUsefulImportedRow(row) {
  return Boolean(
    row.sales || row.visitors || row.orders || row.spend || row.clicks || row.impressions ||
    row.itemName || row.categoryName || row.trafficSource || row.promotionName || row.activityName || row.liveName || row.contentName || row.serviceName ||
    row.refundRate || row.refundAmount || row.liveVisitors || row.liveClickUsers || row.contentVisitors ||
    row.serviceRate || row.pageViews || row.shopCustomers || row.newVisitors || row.oldVisitors
  );
}

function rowsToFormDataFromMapped(mapped, rows, filename, options = {}) {
  const light = Boolean(options.light);
  if (!mapped.length) throw new Error('empty');
  const range = parseRangeFromText(filename || mapped.map((row) => row.sourceFile).join(' '));
  const scopedRows = range ? mapped.filter((row) => rowInDateRange(row, range)) : mapped;
  const sourceRows = scopedRows.length ? scopedRows : mapped;
  const currentRows = sourceRows.filter((row) => row.bucket === 'current');
  const previousRows = mapped.filter((row) => row.bucket === 'previous');
  const currentSource = currentRows.length ? currentRows : sourceRows.filter((row) => row.bucket !== 'benchmark');
  const currentOverallRows = pickCurrentOverallRows(currentSource);
  const previousOverallRows = previousRows.length ? pickCurrentOverallRows(previousRows) : pickPreviousOverallRows(currentSource, currentOverallRows);
  const current = aggregateRows(currentOverallRows.length ? currentOverallRows : currentSource);
  const previous = previousOverallRows.length
    ? aggregateRows(previousOverallRows)
    : previousRows.length
      ? aggregateRows(previousRows)
      : { sales: current.prevSales || 0, visitors: current.prevVisitors || 0 };
  const first = mapped.find((row) => row.storeName || row.industry || row.platform) || {};
  const period = range?.label || dateRangeLabel(currentOverallRows.length ? currentOverallRows : currentSource) || '导入周期';
  const reportType = range ? (range.days > 10 ? '月报' : '周报') : (currentSource.length > 10 ? '月报' : '周报');
  const skippedText = rows.skippedFiles?.length ? `；暂未读取 ${rows.skippedFiles.length} 个文件，请检查是否加密、损坏或暂不支持` : '';
  const summary = buildImportSummary(mapped, rows, rows.skippedFiles || []);
  const lineage = light ? [] : buildDataLineage(rows);
  const aux = buildImportedAux(current, mapped, previous);
  const productStats = deriveProductStats(currentSource, current.sales);
  const channelShares = deriveChannelShares(currentSource);
  const details = light ? {} : buildImportedDetails(currentSource);
  details.traffic = sanitizeTrafficDetails(details.traffic, current.sales, current.visitors);
  return {
    storeName: first.storeName || '',
    brandName: '',
    industry: first.industry || $('#industry').value || '美妆个护',
    platform: first.platform || selectedPlatform || '天猫',
    reportType,
    reportPurpose: $('#reportPurpose')?.value || '品牌方正式版',
    periodStart: range ? formatDateStamp(range.start) : '',
    periodEnd: range ? formatDateStamp(range.end) : '',
    period,
    compareType: (previous.sales || previous.visitors) ? '上一个周期' : '不对比',
    dataSource: filename || '导入数据',
    sales: Math.round(current.sales),
    prevSales: Math.round(previous.sales || 0),
    visitors: Math.round(current.visitors),
    prevVisitors: Math.round(previous.visitors || 0),
    conversion: Number(current.conversion.toFixed(2)),
    aov: Number(current.aov.toFixed(2)),
    refundAmount: Math.round(current.refundAmount || 0),
    refundRate: Number(current.refundRate.toFixed(2)),
    roi: Number(current.roi.toFixed(2)),
    productCount: Math.round(current.productCount || productStats.productCount),
    activeProductCount: Math.round(current.activeProductCount || productStats.activeProductCount),
    topSkuShare: Number((current.topSkuShare || productStats.topSkuShare).toFixed(1)),
    serviceRate: Number(current.serviceRate.toFixed(1)),
    searchShare: Number((current.searchShare || channelShares.searchShare).toFixed(1)),
    recommendShare: Number((current.recommendShare || channelShares.recommendShare).toFixed(1)),
    contentShare: Number((current.contentShare || channelShares.contentShare).toFixed(1)),
    paidShare: Number((current.paidShare || channelShares.paidShare).toFixed(1)),
    privateShare: Number((current.privateShare || channelShares.privateShare).toFixed(1)),
    importedDetails: details,
    importSummary: summary,
    importedAux: aux,
    importedLineage: lineage,
    notes: `已导入 ${mapped.length} 行经营数据，其中本期 ${currentSource.length} 行，上期 ${previousRows.length} 行${skippedText}。`
  };
}

function rowsToFormData(rows, filename, options = {}) {
  const mapped = rows.map(toImportedRow).filter(isUsefulImportedRow);
  return rowsToFormDataFromMapped(mapped, rows, filename, options);
}

async function rowsToFormDataAsync(rows, filename, options = {}) {
  const mapped = [];
  const chunkSize = Math.max(100, Number(options.chunkSize) || 500);
  const total = rows.length || 0;
  for (let index = 0; index < rows.length; index += chunkSize) {
    const part = rows.slice(index, index + chunkSize)
      .map(toImportedRow)
      .filter(isUsefulImportedRow);
    mapped.push(...part);
    options.onProgress?.({
      current: Math.min(index + chunkSize, total),
      total,
      mapped: mapped.length
    });
    await nextUiFrame();
  }
  return rowsToFormDataFromMapped(mapped, rows, filename, options);
}

function decodeTextBuffer(buffer, preferred = '') {
  const bytes = new Uint8Array(buffer);
  const utf8 = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
  if (preferred || utf8.includes('�')) {
    try {
      return new TextDecoder(preferred || 'gb18030', { fatal: false }).decode(bytes);
    } catch {
      return utf8;
    }
  }
  return utf8;
}

function columnIndex(ref) {
  const letters = String(ref || '').replace(/[^A-Z]/gi, '').toUpperCase();
  let index = 0;
  for (let i = 0; i < letters.length; i += 1) {
    index = index * 26 + letters.charCodeAt(i) - 64;
  }
  return Math.max(index - 1, 0);
}

function makeUniqueHeaders(headers) {
  const seen = new Map();
  return headers.map((header, index) => {
    const base = String(header || '').trim() || `字段${index + 1}`;
    const count = seen.get(base) || 0;
    seen.set(base, count + 1);
    return count ? `${base}__${count + 1}` : base;
  });
}

function parseRowsFromArrays(arrays) {
  const normalized = arrays
    .map((row) => row.map((cell) => String(cell || '').trim()))
    .filter((row) => row.some(Boolean));
  const headerIndex = normalized.findIndex((row) => {
    const text = row.join('|');
    return row.filter(Boolean).length >= 2 && /日期|支付金额|成交金额|访客|商品|宝贝|流量|计划|场景|退款|会员|客户|点击量|展现量|类目|直播|观看|开播|客服|咨询|响应|光合|资产|内容/.test(text);
  });
  if (headerIndex < 0) return [];
  const headers = makeUniqueHeaders(normalized[headerIndex]);
  return normalized.slice(headerIndex + 1).map((values) => {
    const item = {};
    headers.forEach((header, index) => {
      item[header] = values[index] || '';
    });
    return item;
  }).filter((row) => Object.values(row).some(Boolean));
}

function headerlessHeaders(filename, width) {
  const name = String(filename || '');
  const fill = (headers) => Array.from({ length: Math.max(width, headers.length) }, (_, index) => headers[index] || `字段${index + 1}`);
  if (/首页-数据概览/.test(name)) {
    return fill(['字段1', '字段2', '支付金额', '店铺客户数', '访客平均价值', '支付买家数', '支付转化率', '客单价', '成功退款率', '老买家支付人数', '老买家支付金额', '支付件数', '支付订单数', '访客数', '浏览量', '成功退款金额', '净支付金额', '商品加购件数', '商品加购人数', '商品收藏人数', '访问收藏转化率', '访问加购转化率', '搜索引导支付金额', '内容引导支付金额', '直播成交金额', '客服支付金额', '淘宝客佣金', '成交人数']);
  }
  if (/流量_流量看板|流量总览/.test(name)) {
    return fill(['访客数', '浏览量', '跳失率', '平均停留时长', '人均浏览量', '新访客数', '老访客数', '关注店铺人数', '商品访客数', '商品浏览量', '店铺页访客数', '直播间访客数', '短视频访客数', '内容查看人数']);
  }
  if (/客户-客户概况/.test(name)) {
    return fill(['店铺客户数', '新访客数', '老访客数', '已购客户回访', '未购客户回访']);
  }
  if (/店铺绩效/.test(name)) {
    return fill(['日期', '访客数', '咨询人数', '成交人数', '支付金额', '支付买家数', '成交笔数', '询单转化率', '支付转化率', '退款金额', '净支付金额']);
  }
  if (/客服绩效/.test(name)) {
    return fill(['客服名称', '咨询人数', '接待人数', '询单转化率', '成交人数', '客服支付金额', '成交笔数', '成交金额', '支付买家数', '支付件数', '客服成交占比', '退款金额', '净支付金额', '客服响应率']);
  }
  if (/客服团队概览/.test(name)) {
    return fill(['日期', '接待客服数', '平均响应时长', '满意度评价数', '客服支付金额', '支付买家数', '客服成交占比', '成交金额', '退款金额', '询单转化率', '接待人数', '客服响应率']);
  }
  if (/光合|资产总览/.test(name)) {
    return fill(['内容曝光量', '内容成交人数', '内容点击人数', '内容支付买家数', '内容成交金额', '内容互动人数', '内容发布数', '内容浏览量', '直播成交人数', '内容加购人数', '直播成交金额', '内容收藏人数', '内容关注人数', '内容转化率', '短视频访客数', '内容成交件数', '内容成交转化率', '图文发布数', '短视频发布数', '直播场次']);
  }
  return null;
}

function parseHeaderlessRows(arrays, filename) {
  const normalized = arrays
    .map((row) => row.map((cell) => String(cell || '').trim()))
    .filter((row) => row.some(Boolean));
  if (!normalized.length) return [];
  const width = Math.max(...normalized.map((row) => row.length));
  const headers = headerlessHeaders(filename, width);
  if (!headers) return [];
  return normalized.map((values) => {
    const item = {};
    headers.forEach((header, index) => {
      item[header] = values[index] || '';
    });
    return item;
  }).filter((row) => Object.values(row).some(Boolean));
}

async function inflateZipEntry(bytes, method) {
  if (method === 0) return bytes;
  if (method !== 8) throw new Error('unsupported-zip-method');
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

function findEndOfCentralDirectory(view) {
  for (let offset = view.byteLength - 22; offset >= Math.max(0, view.byteLength - 66000); offset -= 1) {
    if (view.getUint32(offset, true) === 0x06054b50) return offset;
  }
  return -1;
}

async function unzipEntries(buffer) {
  const view = new DataView(buffer);
  const decoder = new TextDecoder('utf-8');
  const eocd = findEndOfCentralDirectory(view);
  if (eocd < 0) throw new Error('invalid-xlsx');
  const totalEntries = view.getUint16(eocd + 10, true);
  let offset = view.getUint32(eocd + 16, true);
  const entries = {};
  for (let i = 0; i < totalEntries; i += 1) {
    if (view.getUint32(offset, true) !== 0x02014b50) break;
    const method = view.getUint16(offset + 10, true);
    const compressedSize = view.getUint32(offset + 20, true);
    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const localOffset = view.getUint32(offset + 42, true);
    const name = decoder.decode(new Uint8Array(buffer, offset + 46, nameLength));
    const localNameLength = view.getUint16(localOffset + 26, true);
    const localExtraLength = view.getUint16(localOffset + 28, true);
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = new Uint8Array(buffer, dataStart, compressedSize);
    entries[name] = await inflateZipEntry(compressed, method);
    offset += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
}

function xmlText(bytes) {
  return new TextDecoder('utf-8').decode(bytes);
}

function readOleSector(buffer, sectorSize, sectorId) {
  return new Uint8Array(buffer, (sectorId + 1) * sectorSize, sectorSize);
}

function readOleChain(buffer, fat, sectorSize, startSector) {
  const endOfChain = -2;
  const parts = [];
  const seen = new Set();
  let sector = startSector;
  while (sector >= 0 && sector < fat.length && !seen.has(sector)) {
    seen.add(sector);
    parts.push(readOleSector(buffer, sectorSize, sector));
    sector = fat[sector];
    if (sector === endOfChain) break;
  }
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  parts.forEach((part) => {
    out.set(part, offset);
    offset += part.length;
  });
  return out;
}

function parseOleWorkbookStream(buffer) {
  const view = new DataView(buffer);
  const signature = Array.from(new Uint8Array(buffer, 0, 8)).map((byte) => byte.toString(16).padStart(2, '0')).join('');
  if (signature !== 'd0cf11e0a1b11ae1') throw new Error('not-ole-xls');
  const sectorSize = 1 << view.getUint16(30, true);
  const miniSectorSize = 1 << view.getUint16(32, true);
  const miniCutoff = view.getUint32(56, true);
  const firstDirectorySector = view.getInt32(48, true);
  const firstMiniFatSector = view.getInt32(60, true);
  const miniFatSectorCount = view.getUint32(64, true);
  const firstDifatSector = view.getInt32(68, true);
  const difatSectorCount = view.getUint32(72, true);
  const difat = [];
  for (let i = 0; i < 109; i += 1) {
    const value = view.getInt32(76 + i * 4, true);
    if (value >= 0) difat.push(value);
  }
  let difatSector = firstDifatSector;
  for (let i = 0; i < difatSectorCount && difatSector >= 0; i += 1) {
    const sectorOffset = (difatSector + 1) * sectorSize;
    for (let pos = 0; pos < sectorSize - 4; pos += 4) {
      const value = view.getInt32(sectorOffset + pos, true);
      if (value >= 0) difat.push(value);
    }
    difatSector = view.getInt32(sectorOffset + sectorSize - 4, true);
  }
  const fat = [];
  difat.forEach((sectorId) => {
    const sectorOffset = (sectorId + 1) * sectorSize;
    for (let pos = 0; pos < sectorSize; pos += 4) {
      fat.push(view.getInt32(sectorOffset + pos, true));
    }
  });
  const directoryBytes = readOleChain(buffer, fat, sectorSize, firstDirectorySector);
  const nameDecoder = new TextDecoder('utf-16le');
  const entries = [];
  for (let offset = 0; offset + 128 <= directoryBytes.length; offset += 128) {
    const entryView = new DataView(directoryBytes.buffer, directoryBytes.byteOffset + offset, 128);
    const nameLength = entryView.getUint16(64, true);
    if (!nameLength) continue;
    const name = nameDecoder.decode(directoryBytes.slice(offset, offset + Math.max(0, nameLength - 2))).replace(/\0/g, '');
    const type = entryView.getUint8(66);
    entries.push({
      name,
      type,
      startSector: entryView.getInt32(116, true),
      size: entryView.getUint32(120, true)
    });
  }
  const root = entries.find((entry) => entry.type === 5);
  const workbook = entries.find((entry) => entry.type === 2 && /^(Workbook|Book)$/i.test(entry.name));
  if (!workbook) throw new Error('missing-workbook-stream');
  if (workbook.size < miniCutoff && root && root.startSector >= 0) {
    const miniFatBytes = miniFatSectorCount ? readOleChain(buffer, fat, sectorSize, firstMiniFatSector) : new Uint8Array();
    const miniFat = [];
    const miniFatView = new DataView(miniFatBytes.buffer, miniFatBytes.byteOffset, miniFatBytes.byteLength);
    for (let pos = 0; pos + 4 <= miniFatBytes.length; pos += 4) miniFat.push(miniFatView.getInt32(pos, true));
    const miniStream = readOleChain(buffer, fat, sectorSize, root.startSector);
    const parts = [];
    const seen = new Set();
    let sector = workbook.startSector;
    while (sector >= 0 && sector < miniFat.length && !seen.has(sector)) {
      seen.add(sector);
      parts.push(miniStream.slice(sector * miniSectorSize, sector * miniSectorSize + miniSectorSize));
      sector = miniFat[sector];
      if (sector === -2) break;
    }
    const out = new Uint8Array(parts.length * miniSectorSize);
    parts.forEach((part, index) => out.set(part, index * miniSectorSize));
    return out.slice(0, workbook.size);
  }
  return readOleChain(buffer, fat, sectorSize, workbook.startSector).slice(0, workbook.size);
}

function readBiffUnicodeString(bytes, offset) {
  if (offset + 3 > bytes.length) return { value: '', nextOffset: bytes.length };
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const length = view.getUint16(offset, true);
  let pos = offset + 2;
  const flags = bytes[pos] || 0;
  pos += 1;
  const is16Bit = Boolean(flags & 1);
  const hasRichText = Boolean(flags & 8);
  const hasExt = Boolean(flags & 4);
  const richRuns = hasRichText && pos + 2 <= bytes.length ? view.getUint16(pos, true) : 0;
  if (hasRichText) pos += 2;
  const extSize = hasExt && pos + 4 <= bytes.length ? view.getUint32(pos, true) : 0;
  if (hasExt) pos += 4;
  let value = '';
  for (let i = 0; i < length && pos < bytes.length; i += 1) {
    if (is16Bit) {
      if (pos + 2 > bytes.length) break;
      value += String.fromCharCode(view.getUint16(pos, true));
      pos += 2;
    } else {
      value += String.fromCharCode(bytes[pos]);
      pos += 1;
    }
  }
  pos += richRuns * 4 + extSize;
  return { value, nextOffset: pos };
}

function decodeRkNumber(raw) {
  const multiplied = raw & 1;
  let value;
  if (raw & 2) {
    value = raw >> 2;
  } else {
    const buffer = new ArrayBuffer(8);
    const bytes = new Uint8Array(buffer);
    bytes[4] = raw & 0xfc;
    bytes[5] = (raw >> 8) & 0xff;
    bytes[6] = (raw >> 16) & 0xff;
    bytes[7] = (raw >> 24) & 0xff;
    value = new DataView(buffer).getFloat64(0, true);
  }
  return multiplied ? value / 100 : value;
}

function setArrayCell(rows, row, col, value) {
  if (!rows[row]) rows[row] = [];
  rows[row][col] = value === undefined || value === null ? '' : String(value);
}

function parseLegacyXlsRows(buffer) {
  const workbook = parseOleWorkbookStream(buffer);
  const records = [];
  const view = new DataView(workbook.buffer, workbook.byteOffset, workbook.byteLength);
  for (let offset = 0; offset + 4 <= workbook.length;) {
    const type = view.getUint16(offset, true);
    const length = view.getUint16(offset + 2, true);
    const dataStart = offset + 4;
    const dataEnd = Math.min(dataStart + length, workbook.length);
    records.push({ type, bytes: workbook.slice(dataStart, dataEnd) });
    offset = dataStart + length;
  }

  const sst = [];
  for (let i = 0; i < records.length; i += 1) {
    if (records[i].type !== 0x00fc) continue;
    const chunks = [records[i].bytes];
    let next = i + 1;
    while (records[next] && records[next].type === 0x003c) {
      chunks.push(records[next].bytes);
      next += 1;
    }
    const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const bytes = new Uint8Array(total);
    let chunkOffset = 0;
    chunks.forEach((chunk) => {
      bytes.set(chunk, chunkOffset);
      chunkOffset += chunk.length;
    });
    const sstView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const uniqueCount = bytes.length >= 8 ? sstView.getUint32(4, true) : 0;
    let pos = 8;
    for (let index = 0; index < uniqueCount && pos < bytes.length; index += 1) {
      const parsed = readBiffUnicodeString(bytes, pos);
      sst.push(parsed.value);
      pos = parsed.nextOffset;
    }
    break;
  }

  const sheetRows = [];
  let inWorksheet = false;
  records.forEach((record) => {
    const bytes = record.bytes;
    if (record.type === 0x0809 && bytes.length >= 4) {
      const substreamType = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint16(2, true);
      inWorksheet = substreamType === 0x0010 || inWorksheet;
      return;
    }
    if (record.type === 0x000a) {
      if (inWorksheet && sheetRows.length) inWorksheet = false;
      return;
    }
    if (!inWorksheet && sheetRows.length) return;
    if (!inWorksheet && ![0x00fd, 0x0203, 0x027e, 0x00bd, 0x0204, 0x0006].includes(record.type)) return;
    const cellView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (record.type === 0x00fd && bytes.length >= 10) {
      const row = cellView.getUint16(0, true);
      const col = cellView.getUint16(2, true);
      const sstIndex = cellView.getUint32(6, true);
      setArrayCell(sheetRows, row, col, sst[sstIndex] || '');
    } else if (record.type === 0x0203 && bytes.length >= 14) {
      setArrayCell(sheetRows, cellView.getUint16(0, true), cellView.getUint16(2, true), cellView.getFloat64(6, true));
    } else if (record.type === 0x027e && bytes.length >= 10) {
      setArrayCell(sheetRows, cellView.getUint16(0, true), cellView.getUint16(2, true), decodeRkNumber(cellView.getInt32(6, true)));
    } else if (record.type === 0x00bd && bytes.length >= 6) {
      const row = cellView.getUint16(0, true);
      const firstCol = cellView.getUint16(2, true);
      const lastCol = cellView.getUint16(bytes.length - 2, true);
      for (let col = firstCol, pos = 4; col <= lastCol && pos + 6 <= bytes.length - 2; col += 1, pos += 6) {
        setArrayCell(sheetRows, row, col, decodeRkNumber(cellView.getInt32(pos + 2, true)));
      }
    } else if (record.type === 0x0204 && bytes.length >= 8) {
      const row = cellView.getUint16(0, true);
      const col = cellView.getUint16(2, true);
      const parsed = readBiffUnicodeString(bytes, 6);
      setArrayCell(sheetRows, row, col, parsed.value);
    } else if (record.type === 0x0006 && bytes.length >= 14) {
      const row = cellView.getUint16(0, true);
      const col = cellView.getUint16(2, true);
      const value = cellView.getFloat64(6, true);
      if (Number.isFinite(value)) setArrayCell(sheetRows, row, col, value);
    }
  });
  return parseRowsFromArrays(sheetRows);
}

function decodeXmlEntities(value) {
  return String(value || '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCharCode(parseInt(code, 16)));
}

function xmlAttr(node, name) {
  const match = String(node || '').match(new RegExp(`\\s${name}="([^"]*)"`, 'i'));
  return match ? decodeXmlEntities(match[1]) : '';
}

function xmlInner(node, tagName) {
  const match = String(node || '').match(new RegExp(`<${tagName}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tagName}>`, 'i'));
  return match ? decodeXmlEntities(match[1].replace(/<[^>]+>/g, '')) : '';
}

function xmlTagBlocks(xml, tagName) {
  const blocks = [];
  const pattern = new RegExp(`<${tagName}(?:\\s[^>]*)?>[\\s\\S]*?<\\/${tagName}>`, 'gi');
  let match;
  while ((match = pattern.exec(String(xml || '')))) blocks.push(match[0]);
  return blocks;
}

async function parseXlsxRows(buffer, filename = '') {
  const entries = await unzipEntries(buffer);
  const shared = [];
  if (entries['xl/sharedStrings.xml']) {
    const sharedXml = xmlText(entries['xl/sharedStrings.xml']);
    xmlTagBlocks(sharedXml, 'si').forEach((node) => {
      const parts = [];
      const textPattern = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/gi;
      let match;
      while ((match = textPattern.exec(node))) parts.push(decodeXmlEntities(match[1]));
      shared.push(parts.join(''));
    });
  }
  const sheetName = Object.keys(entries).find((name) => /^xl\/worksheets\/sheet\d+\.xml$/.test(name));
  if (!sheetName) return [];
  const sheetXml = xmlText(entries[sheetName]);
  const arrays = xmlTagBlocks(sheetXml, 'row').map((rowNode) => {
    const row = [];
    xmlTagBlocks(rowNode, 'c').forEach((cell) => {
      const ref = xmlAttr(cell, 'r');
      const index = columnIndex(ref);
      const type = xmlAttr(cell, 't');
      let value = xmlInner(cell, 'v');
      if (type === 's' && value !== '') value = shared[Number(value)] || '';
      if (type === 'inlineStr') {
        const parts = [];
        const textPattern = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/gi;
        let match;
        while ((match = textPattern.exec(cell))) parts.push(decodeXmlEntities(match[1]));
        value = parts.join('');
      }
      row[index] = value;
    });
    return row;
  });
  const parsed = parseRowsFromArrays(arrays);
  return parsed.length ? parsed : parseHeaderlessRows(arrays, filename);
}

function parseHtmlDocRows(text, filename) {
  if (!text.trim().startsWith('<')) return [{ 来源文件: filename, 文档类型: 'Word/HTML', 备注: '非结构化文档，未识别到数据表' }];
  const tables = String(text || '').match(/<table[\s\S]*?<\/table>/gi) || [];
  for (const table of tables) {
    const arrays = (table.match(/<tr[\s\S]*?<\/tr>/gi) || []).map((tr) => (
      (tr.match(/<t[hd][\s\S]*?<\/t[hd]>/gi) || []).map((cell) => decodeXmlEntities(cell.replace(/<[^>]+>/g, '').trim()))
    ));
    const rows = parseRowsFromArrays(arrays);
    if (rows.length) return rows;
  }
  return [{ 来源文件: filename, 文档类型: 'Word/HTML', 备注: '已读取参考文档，但未识别到可汇总的数据表' }];
}

async function parseDocxRows(buffer, filename) {
  try {
    const entries = await unzipEntries(buffer);
    const documentXml = entries['word/document.xml'];
    if (!documentXml) return [{ 来源文件: filename, 文档类型: 'Word/DOCX', 备注: '已读取 Word 参考文档，但未识别到正文数据' }];
    const docXml = xmlText(documentXml);
    const tables = docXml.match(/<w:tbl[\s\S]*?<\/w:tbl>/gi) || [];
    for (const table of tables) {
      const arrays = (table.match(/<w:tr[\s\S]*?<\/w:tr>/gi) || []).map((tr) => (
        (tr.match(/<w:tc[\s\S]*?<\/w:tc>/gi) || []).map((cell) => {
          const parts = [];
          const textPattern = /<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/gi;
          let match;
          while ((match = textPattern.exec(cell))) parts.push(decodeXmlEntities(match[1]));
          return parts.join('').trim();
        })
      ));
      const rows = parseRowsFromArrays(arrays);
      if (rows.length) return rows;
    }
    const parts = [];
    const textPattern = /<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/gi;
    let match;
    while ((match = textPattern.exec(docXml))) parts.push(decodeXmlEntities(match[1]));
    const text = parts.join(' ').trim();
    return [{ 来源文件: filename, 文档类型: 'Word/DOCX', 备注: text ? '已读取 Word 参考文档，暂作为报告口径参考，不作为结构化经营数据汇总' : '已读取 Word 参考文档，但未识别到可汇总的数据表' }];
  } catch {
    return [{ 来源文件: filename, 文档类型: 'Word/DOCX', 备注: 'Word 文档读取失败，可能为加密、损坏或非标准格式' }];
  }
}

async function readRowsFromFile(file) {
  const lowerName = file.name.toLowerCase();
  const buffer = await file.arrayBuffer();
  let rows;
  if (lowerName.endsWith('.xlsx')) {
    rows = await parseXlsxRows(buffer, file.name);
  } else if (lowerName.endsWith('.xls')) {
    try {
      rows = parseLegacyXlsRows(buffer);
    } catch {
      const text = decodeTextBuffer(buffer, 'gb18030');
      rows = text.trim().startsWith('<') ? parseHtmlDocRows(text, file.name) : parseDelimitedRows(text);
    }
  } else if (lowerName.endsWith('.docx')) {
    rows = await parseDocxRows(buffer, file.name);
  } else if (lowerName.endsWith('.doc') || lowerName.endsWith('.html')) {
    rows = parseHtmlDocRows(decodeTextBuffer(buffer), file.name);
  } else if (lowerName.endsWith('.json')) {
    const parsed = JSON.parse(decodeTextBuffer(buffer));
    rows = Array.isArray(parsed) ? parsed : (parsed.rows || parsed.data || []);
  } else {
    const text = decodeTextBuffer(buffer, lowerName.endsWith('.csv') ? 'gb18030' : '');
    rows = parseDelimitedRows(text);
  }
  return rows.map((row, index) => ({ ...row, 来源文件: file.name, __rowIndex: index }));
}

function createImportParserWorker() {
  const functions = [
    parseCsv,
    parseDelimitedRows,
    decodeTextBuffer,
    columnIndex,
    makeUniqueHeaders,
    parseRowsFromArrays,
    headerlessHeaders,
    parseHeaderlessRows,
    inflateZipEntry,
    findEndOfCentralDirectory,
    unzipEntries,
    xmlText,
    readOleSector,
    readOleChain,
    parseOleWorkbookStream,
    readBiffUnicodeString,
    decodeRkNumber,
    setArrayCell,
    parseLegacyXlsRows,
    decodeXmlEntities,
    xmlAttr,
    xmlInner,
    xmlTagBlocks,
    parseXlsxRows,
    parseHtmlDocRows,
    parseDocxRows,
    readRowsFromFile
  ].map((fn) => fn.toString()).join('\n\n');
  const source = `
    ${functions}
    self.onmessage = async (event) => {
      const file = event.data && event.data.file;
      try {
        if (!file) throw new Error('missing-file');
        const rows = await readRowsFromFile(file);
        self.postMessage({ ok: true, rows });
      } catch (error) {
        self.postMessage({ ok: false, error: error && error.message ? error.message : 'parse-failed' });
      }
    };
  `;
  const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
  const worker = new Worker(url);
  URL.revokeObjectURL(url);
  return worker;
}

function readRowsFromFileOffThread(file) {
  if (!window.Worker) return readRowsFromFile(file);
  return new Promise((resolve, reject) => {
    let worker;
    try {
      worker = createImportParserWorker();
    } catch (error) {
      readRowsFromFile(file).then(resolve).catch(reject);
      return;
    }
    const timer = setTimeout(() => {
      worker.terminate();
      reject(new Error('parse-timeout'));
    }, Math.max(45000, Math.ceil((file.size || 0) / 1024 / 1024) * 15000));
    worker.onmessage = (event) => {
      clearTimeout(timer);
      worker.terminate();
      if (event.data?.ok) resolve(event.data.rows || []);
      else reject(new Error(event.data?.error || 'parse-failed'));
    };
    worker.onerror = (event) => {
      clearTimeout(timer);
      worker.terminate();
      reject(new Error(event.message || 'worker-error'));
    };
    worker.postMessage({ file });
  });
}

function setImportProgress({ current = 0, total = 0, filename = '', rowCount = 0, mode = 'running', message = '' } = {}) {
  const box = $('#importProgress');
  if (!box) return;
  const percent = total ? Math.round(current / total * 100) : 0;
  box.hidden = false;
  $('#importProgressText').textContent = message || (filename ? `正在读取 ${current}/${total}：${filename}` : '正在准备导入');
  $('#importProgressPercent').textContent = `${Math.max(0, Math.min(100, percent))}%`;
  $('#importProgressBar').style.width = `${Math.max(0, Math.min(100, percent))}%`;
  $('#importProgressDetail').textContent = mode === 'done'
    ? `本轮导入完成，当前任务累计 ${importSessionFileNames.length} 个文件、${rowCount.toLocaleString('zh-CN')} 行数据。`
    : `已累计 ${importSessionFileNames.length} 个文件、${rowCount.toLocaleString('zh-CN')} 行数据；可继续分批追加上传。`;
}

function clearImportProgress() {
  const box = $('#importProgress');
  if (!box) return;
  box.hidden = true;
  $('#importProgressText').textContent = '等待导入';
  $('#importProgressPercent').textContent = '0%';
  $('#importProgressBar').style.width = '0%';
  $('#importProgressDetail').textContent = '可分批上传，后续批次会追加到当前报告任务。';
}

function nextUiFrame() {
  return new Promise((resolve) => {
    requestAnimationFrame(() => setTimeout(resolve, 0));
  });
}

function setReportProgress(percent, text, detail = '') {
  const box = $('#reportProgress');
  if (!box) return;
  const value = Math.max(0, Math.min(100, Math.round(percent || 0)));
  box.hidden = false;
  $('#reportProgressText').textContent = text || '正在生成报告';
  $('#reportProgressPercent').textContent = `${value}%`;
  $('#reportProgressBar').style.width = `${value}%`;
  $('#reportProgressDetail').textContent = detail || '正在分步生成报告，请不要关闭页面。';
}

function clearReportProgress() {
  const box = $('#reportProgress');
  if (!box) return;
  box.hidden = true;
  $('#reportProgressText').textContent = '等待生成报告';
  $('#reportProgressPercent').textContent = '0%';
  $('#reportProgressBar').style.width = '0%';
  $('#reportProgressDetail').textContent = '确认后会分步完成数据重算、诊断生成、报告渲染和历史写入。';
}

function setReportGeneratingState(isGenerating) {
  const confirmButton = $('#confirmImportedReport');
  const appendButton = $('#appendImportFiles');
  document.querySelectorAll('[data-close-import-modal]').forEach((button) => {
    button.disabled = Boolean(isGenerating);
  });
  if (confirmButton) {
    confirmButton.disabled = Boolean(isGenerating);
    confirmButton.textContent = isGenerating ? '正在生成...' : '生成报告并写入历史';
  }
  if (appendButton) appendButton.disabled = Boolean(isGenerating);
}

function resetImportSession() {
  importSessionRows = [];
  importSessionFileNames = [];
  importSessionSkippedFiles = [];
  queuedImportFiles = [];
  pendingImportMeta = null;
  clearImportProgress();
  clearReportProgress();
  if ($('#resumeImportConfirm')) $('#resumeImportConfirm').hidden = true;
  $('#importStatus').textContent = '尚未导入数据，可先使用示例数据体验。';
}

async function importDataFiles(files) {
  const fileList = Array.from(files || []);
  if (!fileList.length) return;
  if (isImportingFiles) {
    const queuedNames = new Set(queuedImportFiles.map((file) => file.name));
    const nextFiles = fileList.filter((file) => !queuedNames.has(file.name));
    queuedImportFiles.push(...nextFiles);
    updateWorkflowStatus('parsing', `当前批次仍在处理，已将 ${nextFiles.length} 个文件加入下一批队列。系统会自动继续导入。`);
    toast(nextFiles.length ? `已加入下一批队列：${nextFiles.length} 个文件` : '这些文件已在队列中');
    return;
  }
  isImportingFiles = true;
  try {
  if (pendingImportMeta?.rawRows?.length && !importSessionRows.length) {
    importSessionRows = [...pendingImportMeta.rawRows];
    importSessionFileNames = pendingImportMeta.fileNameList || String(pendingImportMeta.fileNames || '').split(' + ').filter(Boolean);
    importSessionSkippedFiles = pendingImportMeta.skippedFiles || [];
  }
  const existing = new Set(importSessionFileNames);
  const incoming = fileList.filter((file) => !existing.has(file.name));
  const duplicateCount = fileList.length - incoming.length;
  if (!incoming.length) {
    toast('这些文件已经在当前任务中，不再重复导入');
    return;
  }
  const appended = importSessionRows.length > 0;
  updateWorkflowStatus('parsing', `${appended ? '正在追加' : '正在读取'} ${incoming.length} 个文件。文件较多时会逐个解析并显示进度，可分批上传。`);
  setImportProgress({ current: 0, total: incoming.length, rowCount: importSessionRows.length, message: appended ? '准备追加本批文件' : '准备读取本批文件' });
  const batchSkipped = [];
  for (let index = 0; index < incoming.length; index += 1) {
    const file = incoming[index];
    setImportProgress({ current: index, total: incoming.length, filename: file.name, rowCount: importSessionRows.length });
    try {
      const rows = await readRowsFromFileOffThread(file);
      importSessionRows.push(...rows);
      importSessionFileNames.push(file.name);
    } catch {
      batchSkipped.push(file.name);
      importSessionSkippedFiles.push(file.name);
    }
    setImportProgress({ current: index + 1, total: incoming.length, filename: file.name, rowCount: importSessionRows.length });
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  const rows = [...importSessionRows];
  const skippedFiles = [...importSessionSkippedFiles];
  rows.skippedFiles = skippedFiles;
  setImportProgress({ current: incoming.length, total: incoming.length, rowCount: rows.length, message: '正在轻量汇总文件识别结果' });
  await nextUiFrame();
  const data = await rowsToFormDataAsync(rows, importSessionFileNames.join(' + '), {
    light: true,
    chunkSize: 400,
    onProgress: ({ current, total, mapped }) => {
      const percentDone = total ? Math.round(current / total * 100) : 100;
      setImportProgress({
        current: incoming.length,
        total: incoming.length,
        rowCount: rows.length,
        message: `正在标准化导入数据 ${percentDone}%`
      });
      $('#importProgressDetail').textContent = `已识别 ${mapped.toLocaleString('zh-CN')} 行有效经营数据，正在生成确认信息。`;
    }
  });
  const suggestions = inferImportSuggestions(importSessionFileNames.map((name) => ({ name })), rows, data);
  data.storeName = data.storeName || suggestions.storeName;
  data.industry = suggestions.industry || data.industry;
  data.platform = suggestions.platform || data.platform;
  setFormData(data);
  clearReportProgress();
  const skippedText = skippedFiles.length ? `；${skippedFiles.length} 个文件暂未读取，请检查是否为加密、损坏或暂不支持格式` : '';
  pendingImportMeta = {
    fileCount: importSessionFileNames.length,
    rowCount: rows.length,
    reportType: data.reportType,
    skippedText,
    suggestions,
    modules: summarizeImportModules(data.importSummary || []),
    fileSummaries: data.importSummary || [],
    skippedFiles,
    rawRows: rows,
    fileNames: importSessionFileNames.join(' + '),
    fileNameList: [...importSessionFileNames],
    batchFileCount: incoming.length,
    duplicateCount,
    appended
  };
  setImportProgress({ current: incoming.length, total: incoming.length, rowCount: rows.length, mode: 'done', message: duplicateCount ? `本轮完成，已跳过 ${duplicateCount} 个重复文件` : '本轮导入完成' });
  const batchText = appended ? `本批追加 ${incoming.length} 个文件，当前累计` : '已导入';
  const duplicateText = duplicateCount ? `；跳过 ${duplicateCount} 个重复文件` : '';
  $('#importStatus').textContent = `${batchText} ${pendingImportMeta.fileCount} 个文件、${pendingImportMeta.rowCount} 行数据${duplicateText}。请确认文件识别结果、店铺名称和类目后生成${data.reportType}${skippedText}。`;
  updateWorkflowStatus('confirm', `${batchText} ${pendingImportMeta.fileCount} 个文件、${pendingImportMeta.rowCount} 行数据。可继续分批追加，或确认后生成${data.reportType}。`);
  openImportConfirmModal(pendingImportMeta);
  toast(batchSkipped.length ? '已导入可识别文件，部分文件未读取' : appended ? '本批文件已追加，请确认识别结果' : '数据已导入，请确认店铺信息');
  } finally {
  isImportingFiles = false;
  if (queuedImportFiles.length) {
    const nextBatch = queuedImportFiles.splice(0);
    setTimeout(() => importDataFiles(nextBatch), 0);
  }
  }
}

function inferImportSuggestions(fileList, rows, data) {
  const filenames = fileList.map((file) => file.name);
  const text = [
    filenames.join(' '),
    rows.slice(0, 120).map((row) => Object.values(row).join(' ')).join(' ')
  ].join(' ');
  return {
    storeName: data.storeName || inferStoreName(filenames, rows),
    industry: data.industry && data.industry !== '美妆个护' ? data.industry : inferIndustry(text, data.industry),
    platform: data.platform || inferImportPlatform(text),
    reportType: data.reportType
  };
}

function inferStoreName(filenames, rows) {
  const fromRows = rows.map((row) => pick(row, ['店铺名称', '店铺', 'storeName', 'store'])).find(Boolean);
  const rowName = cleanStoreNameCandidate(fromRows);
  if (rowName && !isWeakStoreNameCandidate(rowName)) return rowName;
  const firstStrongName = filenames
    .map((name) => name.replace(/\.[^.]+$/, '').split(/[_\-—]/)[0])
    .map(cleanStoreNameCandidate)
    .find((name) => !isWeakStoreNameCandidate(name) && /旗舰店|专营店|专卖店|店$/.test(name) && name.length >= 2);
  if (firstStrongName) return firstStrongName;
  const cleaned = filenames
    .map((name) => name.replace(/\.[^.]+$/, ''))
    .map((name) => name.replace(/\(.*?\)|（.*?）/g, ''))
    .map((name) => name.replace(/^\d+[_-]?/, ''))
    .map(cleanStoreNameCandidate)
    .filter((name) => name.length >= 2 && name.length <= 24 && !isWeakStoreNameCandidate(name));
  const best = cleaned.find((name) => /旗舰店|专营店|店|TALASA|世纪茗家|茗家/.test(name)) || cleaned[0];
  return best || '';
}

function isWeakStoreNameCandidate(name) {
  const text = String(name || '').trim();
  if (!text) return true;
  if (/^(直播|店播|客户|粉丝|流量|商品|客服|内容|推广|品类|退款|首页|光合|营销|计划|创意|单元|关键词|人群|地域|数据|报表|概览|分析|标准类目)/.test(text)) return true;
  if (/直播业绩|店播|播中|点击转化|成交拆解|客户概况|粉丝|流量来源|流量总览|数据概览|资产总览|标准类目|退款|售后|报表|下载|汇总|概览|明细|分析/.test(text) && !/旗舰店|专营店|专卖店|TALASA|世纪茗家|茗家/.test(text)) return true;
  return false;
}

function cleanStoreNameCandidate(name) {
  return String(name || '')
    .replace(/(店铺经营|经营月报|经营周报|首页|数据概览|生意参谋平台|生意参谋|无线店铺流量来源|商品_全部|商品报表|流量来源|流量看板|流量总览|退款分析|客户-粉丝分析|客户概况|客户|粉丝运营|粉丝增长|粉丝激活|粉丝唤醒|粉丝类型|客服|直播业绩|店播|播中|点击转化分析|点击转化|成交拆解|内容资产|资产总览|光合|标准类目|营销场景|计划报表|推广计划|创意报表|单元报表|关键词报表|人群报表|地域报表|内容报表|月报|周报|报告|数据下载|汇总下载|离线|全部|天猫|京东|抖音|小红书|拼多多|视频号|最近\d+天|第\d+周|20\d{2}[-_~年]\d{1,2}.*$|\d{2,4}年\d{1,2}月.*$|\d{8}.*$)/g, '')
    .replace(/[_\-—+\s]+/g, '')
    .trim();
}

function inferIndustry(text, fallback) {
  if (/连衣裙|女装|男装|T恤|衬衫|裤|裙|鞋|包|尺码|版型|面料|穿搭/.test(text)) return '服装鞋包';
  if (/茶|咖啡|食品|饮|酒|陈皮|礼盒|口味|保质期|自饮/.test(text)) return '食品茶饮';
  if (/面膜|护肤|精华|口红|美妆|个护|洗护|功效|成分|肤质/.test(text)) return '美妆个护';
  if (/母婴|奶粉|营养|宝宝|孕|儿童|适龄|月龄/.test(text)) return '母婴营养';
  if (/家居|百货|家具|收纳|厨房|床品|尺寸|安装|材质/.test(text)) return '家居百货';
  if (/工厂|产业带|源头|批发|供应链|厂家/.test(text)) return '产业带工厂';
  if (/到店|预约|核销|门店|套餐|本地生活/.test(text)) return '本地生活';
  return fallback || '美妆个护';
}

function inferImportPlatform(text) {
  if (/京东|JD|京准通|我的京东|10292689|734249/.test(text)) return '京东';
  if (/抖音|千川|巨量|直播间/.test(text)) return '抖音';
  if (/小红书|薯条|笔记|种草/.test(text)) return '小红书';
  if (/视频号|微信/.test(text)) return '视频号';
  if (/拼多多|多多/.test(text)) return '拼多多';
  return '天猫';
}

function summarizeImportModules(importSummary) {
  const counts = new Map();
  importSummary.forEach((item) => {
    (item.modules || []).forEach((moduleName) => {
      counts.set(moduleName, (counts.get(moduleName) || 0) + (item.usedRows || 0));
    });
  });
  return Array.from(counts.entries()).map(([name, rows]) => ({ name, rows }));
}

function importFileNeedsReview(item) {
  return item?.status === '未读取' || ['unknown', 'ignored'].includes(item?.dominantKind) || !item?.usedRows;
}

function importRecognitionHtml(importSummary = []) {
  if (!importSummary.length) {
    return `
      <div class="modal-recognition empty">
        <div class="recognition-head">
          <strong>文件识别结果确认</strong>
          <span>暂无可展示的文件识别结果。</span>
        </div>
        <div class="recognition-empty">继续导入报表后，这里会显示每个文件的识别类型、使用行数和人工修正入口。</div>
      </div>
    `;
  }
  const pageSize = 8;
  const pageCount = Math.ceil(importSummary.length / pageSize);
  const reviewCount = importSummary.filter(importFileNeedsReview).length;
  const readyCount = Math.max(0, importSummary.length - reviewCount);
  const options = reportKindOptions.map(([value, label]) => `<option value="${value}">${label}</option>`).join('');
  const rows = importSummary.map((item, index) => {
    const usageRate = item.rawRows ? item.usedRows / item.rawRows * 100 : 0;
    const statusClass = importFileNeedsReview(item) ? 'warn' : 'ok';
    return `
      <tr data-recognition-row="${index}" data-recognition-status="${statusClass}">
        <td><strong>${index + 1}. ${escapeHtml(item.name)}</strong><span>${escapeHtml(item.note || '-')}</span></td>
        <td><b class="recognition-badge ${statusClass}">${escapeHtml(reportKindLabel(item.dominantKind || 'unknown'))}</b></td>
        <td>${item.rawRows ? `${item.usedRows}/${item.rawRows}` : '-'}</td>
        <td>${item.rawRows ? percent(usageRate, 1) : '-'}</td>
        <td>${escapeHtml(item.modules?.length ? item.modules.join('、') : '未进入正文模块')}</td>
        <td>
          <select data-import-kind="${escapeHtml(item.name)}" aria-label="修正 ${escapeHtml(item.name)} 的报表类型">
            ${options}
          </select>
        </td>
      </tr>
    `;
  }).join('');
  const pager = pageCount > 1 ? `
    <div class="recognition-pager" data-recognition-pager>
      <button type="button" data-recognition-prev>上一页</button>
      <span data-recognition-page-text>第 1 / ${pageCount} 页</span>
      <button type="button" data-recognition-next>下一页</button>
    </div>
  ` : '';
  return `
    <div class="modal-recognition" data-page-size="${pageSize}">
      <div class="recognition-head">
        <strong>文件识别结果确认</strong>
        <span>${importSummary.length} 个文件${pageCount > 1 ? `，每页 ${pageSize} 个` : ''}。如识别不准，可先修正类型再生成报告。</span>
      </div>
      <div class="recognition-filter" data-recognition-filter>
        <button type="button" class="active" data-recognition-filter-value="all">全部 ${importSummary.length}</button>
        <button type="button" data-recognition-filter-value="review" ${reviewCount ? '' : 'disabled'}>需处理 ${reviewCount}</button>
        <button type="button" data-recognition-filter-value="ready" ${readyCount ? '' : 'disabled'}>已使用 ${readyCount}</button>
      </div>
      <div class="recognition-table-wrap">
        <table class="recognition-table">
          <thead><tr><th>文件</th><th>识别为</th><th>使用行</th><th>使用率</th><th>进入模块</th><th>人工修正</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      ${pager}
    </div>
  `;
}

function setupRecognitionPager(root = document) {
  root.querySelectorAll('.modal-recognition').forEach((panel) => {
    const rows = Array.from(panel.querySelectorAll('[data-recognition-row]'));
    const pageSize = Number(panel.dataset.pageSize) || 8;
    const pager = panel.querySelector('[data-recognition-pager]');
    const pageText = panel.querySelector('[data-recognition-page-text]');
    const prevButton = panel.querySelector('[data-recognition-prev]');
    const nextButton = panel.querySelector('[data-recognition-next]');
    const filterButtons = Array.from(panel.querySelectorAll('[data-recognition-filter-value]'));
    let page = 0;
    let filter = 'all';

    const rowMatchesFilter = (row) => {
      if (filter === 'review') return row.dataset.recognitionStatus === 'warn';
      if (filter === 'ready') return row.dataset.recognitionStatus === 'ok';
      return true;
    };

    const renderPage = () => {
      const visibleRows = rows.filter(rowMatchesFilter);
      const pageCount = Math.max(1, Math.ceil(visibleRows.length / pageSize));
      page = Math.max(0, Math.min(page, pageCount - 1));
      rows.forEach((row) => {
        const index = visibleRows.indexOf(row);
        row.hidden = index < 0 || index < page * pageSize || index >= (page + 1) * pageSize;
      });
      filterButtons.forEach((button) => {
        button.classList.toggle('active', button.dataset.recognitionFilterValue === filter);
      });
      if (!pager) return;
      if (pageText) pageText.textContent = visibleRows.length ? `第 ${page + 1} / ${pageCount} 页` : '无文件';
      if (prevButton) prevButton.disabled = page <= 0;
      if (nextButton) nextButton.disabled = page >= pageCount - 1;
    };

    filterButtons.forEach((button) => {
      button.onclick = () => {
        if (button.disabled) return;
        filter = button.dataset.recognitionFilterValue || 'all';
        page = 0;
        renderPage();
      };
    });
    if (prevButton) prevButton.onclick = () => {
      page -= 1;
      renderPage();
    };
    if (nextButton) nextButton.onclick = () => {
      page += 1;
      renderPage();
    };
    renderPage();
  });
}

function importModuleChips(modules) {
  if (!modules || !modules.length) return '<span class="modal-chip">暂未识别模块</span>';
  return modules.map((item) => `<span class="modal-chip">${escapeHtml(item.name)} ${Math.round(item.rows || 0)}行</span>`).join('');
}

function openImportConfirmModal(meta) {
  const modal = $('#importConfirmModal');
  if (!modal) return;
  clearImportConfirmErrors();
  const suggestion = meta.suggestions || {};
  const fileSummaries = meta.fileSummaries || [];
  const reviewCount = fileSummaries.filter(importFileNeedsReview).length;
  const readyCount = Math.max(0, fileSummaries.length - reviewCount);
  const skipped = meta.skippedFiles?.length ? `，${meta.skippedFiles.length} 个文件未读取` : '';
  $('#importConfirmText').textContent = `已导入 ${meta.fileCount} 个文件、${meta.rowCount} 行数据${skipped}。可继续追加下一批文件，或确认店铺信息后生成${meta.reportType}。`;
  $('#modalImportSummary').innerHTML = `
    <strong>系统识别建议</strong>
    <p>店铺：${escapeHtml(suggestion.storeName || '待填写')}；类目：${escapeHtml(suggestion.industry || '待选择')}；平台：${escapeHtml(suggestion.platform || selectedPlatform)}；报告：${escapeHtml(suggestion.reportType || meta.reportType)}。</p>
    <div class="modal-metrics">
      <span><b>${meta.fileCount || fileSummaries.length}</b>文件</span>
      <span><b>${Math.round(meta.rowCount || 0).toLocaleString('zh-CN')}</b>行数据</span>
      <span class="${reviewCount ? 'warn' : 'ok'}"><b>${reviewCount}</b>需处理</span>
      <span><b>${readyCount}</b>已使用</span>
    </div>
    <div class="modal-chips">${importModuleChips(meta.modules)}</div>
  `;
  $('#modalRecognitionPanel').innerHTML = importRecognitionHtml(fileSummaries);
  document.querySelectorAll('[data-import-kind]').forEach((select) => {
    const file = select.getAttribute('data-import-kind');
    const summary = (meta.fileSummaries || []).find((item) => item.name === file);
    select.value = summary?.dominantKind || 'auto';
  });
  setupRecognitionPager(modal);
  $('#modalStoreName').value = suggestion.storeName || $('#storeName').value || '';
  $('#modalIndustry').value = suggestion.industry || $('#industry').value || '美妆个护';
  $('#modalPlatform').value = suggestion.platform || selectedPlatform || '天猫';
  $('#modalReportType').value = suggestion.reportType || meta.reportType || $('#reportType').value || '月报';
  if ($('#resumeImportConfirm')) $('#resumeImportConfirm').hidden = true;
  modal.hidden = false;
  setTimeout(() => $('#modalStoreName').focus(), 0);
}

function closeImportConfirmModal() {
  if (isGeneratingReport) return;
  const modal = $('#importConfirmModal');
  if (modal) modal.hidden = true;
  if (pendingImportMeta) {
    if ($('#resumeImportConfirm')) $('#resumeImportConfirm').hidden = false;
    updateWorkflowStatus('confirm', '文件识别结果已保留。点击“继续确认并生成报告”可返回当前任务。');
  }
}

function previewImportedDraft() {
  if (isGeneratingReport || !pendingImportMeta) return;
  const modalStoreName = String($('#modalStoreName')?.value || '').trim();
  if (modalStoreName) $('#storeName').value = modalStoreName;
  if ($('#modalIndustry')?.value) $('#industry').value = $('#modalIndustry').value;
  if ($('#modalReportType')?.value) $('#reportType').value = $('#modalReportType').value;
  if ($('#modalPlatform')?.value) {
    selectedPlatform = $('#modalPlatform').value;
    document.querySelectorAll('#platformTabs button').forEach((button) => {
      button.classList.toggle('selected', button.dataset.platform === selectedPlatform);
    });
  }
  const modal = $('#importConfirmModal');
  if (modal) modal.hidden = true;
  setLatest(analyze(getFormData()));
  if ($('#resumeImportConfirm')) $('#resumeImportConfirm').hidden = false;
  updateWorkflowStatus('draft', '已生成当前导入数据的草稿预览；确认店铺信息后再写入正式历史。');
  jumpToReportPreview();
  toast('已生成草稿预览，确认任务信息后可生成正式报告');
}

function clearImportConfirmErrors() {
  ['modalStoreName', 'modalIndustry', 'modalPlatform', 'modalReportType'].forEach((id) => {
    const element = $('#' + id);
    element?.closest('label')?.classList.remove('field-error');
    element?.removeAttribute('aria-invalid');
  });
}

function markImportFieldError(id) {
  const element = $('#' + id);
  element?.closest('label')?.classList.add('field-error');
  element?.setAttribute('aria-invalid', 'true');
}

function validateImportConfirmForm() {
  clearImportConfirmErrors();
  const required = [
    ['modalStoreName', '店铺名称'],
    ['modalIndustry', '店铺类目'],
    ['modalPlatform', '店铺平台'],
    ['modalReportType', '报告类型']
  ];
  const missing = required.filter(([id]) => !String($('#' + id)?.value || '').trim());
  missing.forEach(([id]) => markImportFieldError(id));
  if (missing.length) {
    $('#' + missing[0][0])?.focus();
    updateWorkflowStatus('confirmError', `请补充${missing.map((item) => item[1]).join('、')}，补齐后再生成报告。`);
    toast(`请补充${missing.map((item) => item[1]).join('、')}`);
    return false;
  }
  return true;
}

function getImportKindOverrides() {
  const overrides = new Map();
  document.querySelectorAll('[data-import-kind]').forEach((select) => {
    const file = select.getAttribute('data-import-kind');
    const value = select.value;
    if (file && value && value !== 'auto') overrides.set(file, value);
  });
  return overrides;
}

function applyImportKindOverrides(rows, overrides) {
  if (!rows || !overrides || !overrides.size) return rows;
  const nextRows = rows.map((row) => {
    const file = row.来源文件 || row.sourceFile || '';
    const override = overrides.get(file);
    return override ? { ...row, __reportKindOverride: override } : row;
  });
  nextRows.skippedFiles = rows.skippedFiles || [];
  return nextRows;
}

function jumpToReportPreview() {
  const report = $('#report');
  if (!report) return;
  report.scrollIntoView({ behavior: 'smooth', block: 'start' });
  report.classList.add('report-focus');
  clearTimeout(jumpToReportPreview.timer);
  jumpToReportPreview.timer = setTimeout(() => report.classList.remove('report-focus'), 1800);
}

async function confirmImportedReport() {
  if (isGeneratingReport) return;
  const storeName = $('#modalStoreName').value.trim();
  const industry = $('#modalIndustry').value;
  const platform = $('#modalPlatform').value;
  const reportType = $('#modalReportType').value;
  if (!validateImportConfirmForm()) return;
  isGeneratingReport = true;
  setReportGeneratingState(true);
  try {
    updateWorkflowStatus('generating', `任务信息已确认：${storeName} · ${platform} · ${industry} · ${reportType}，正在生成报告。`);
    setReportProgress(5, '正在确认任务信息', `${storeName} · ${platform} · ${industry} · ${reportType}`);
    await nextUiFrame();

    if (pendingImportMeta?.rawRows) {
      const current = getFormData();
      const overrides = getImportKindOverrides();
      setReportProgress(18, '正在应用文件识别修正', `共 ${pendingImportMeta.fileCount || 0} 个文件、${pendingImportMeta.rowCount || 0} 行数据。`);
      await nextUiFrame();
      const rows = applyImportKindOverrides(pendingImportMeta.rawRows, overrides);

      setReportProgress(34, '正在重新汇总经营数据', '系统正在重算销售、访客、退款、商品、流量、推广等模块。');
      await nextUiFrame();
      const refreshed = await rowsToFormDataAsync(rows, pendingImportMeta.fileNames || current.dataSource || '', {
        chunkSize: 500,
        onProgress: ({ current: doneRows, total }) => {
          const ratio = total ? doneRows / total : 1;
          const percentDone = Math.round(ratio * 100);
          setReportProgress(
            34 + (ratio * 16),
            `正在标准化经营数据 ${percentDone}%`,
            `已处理 ${doneRows.toLocaleString('zh-CN')} / ${total.toLocaleString('zh-CN')} 行，正在汇总销售、流量、退款、商品和推广模块。`
          );
        }
      });
      refreshed.brandName = current.brandName || refreshed.brandName || '';
      refreshed.reportPurpose = current.reportPurpose || refreshed.reportPurpose || '品牌方正式版';
      refreshed.periodStart = current.periodStart || refreshed.periodStart || '';
      refreshed.periodEnd = current.periodEnd || refreshed.periodEnd || '';
      refreshed.storeName = storeName;
      refreshed.industry = industry;
      refreshed.platform = platform;
      refreshed.reportType = reportType;
      setFormData(refreshed);
    } else {
      $('#storeName').value = storeName;
      $('#industry').value = industry;
      $('#reportType').value = reportType;
      selectedPlatform = platform;
      document.querySelectorAll('#platformTabs button').forEach((button) => {
        button.classList.toggle('selected', button.dataset.platform === selectedPlatform);
      });
    }

    setReportProgress(52, '正在生成经营诊断', '系统正在计算健康度、问题优先级、交付等级和下周期动作。');
    await nextUiFrame();
    const diagnosis = analyze(getFormData());

    setReportProgress(68, '正在准备报告预览', '正在生成封面、图表、模块洞察、右侧补数建议和微信群话术。');
    showReportRenderPlaceholder(diagnosis);
    await nextUiFrame();
    latestDiagnosis = diagnosis;
    syncActionLedger(diagnosis);
    setReportProgress(72, '正在渲染核心指标', '正在刷新健康度、指标评分、问题优先级和行动建议。');
    renderSummary(diagnosis);
    renderHealth(diagnosis);
    await nextUiFrame();
    setReportProgress(78, '正在渲染问题与动作', '正在生成关键问题、执行计划和右侧补数建议。');
    renderIssues(diagnosis);
    renderActions(diagnosis);
    renderReviewVerification(diagnosis);
    await nextUiFrame();
    setReportProgress(84, '正在渲染正式报告', '正在组装图表、表格、口径说明和微信群话术。');
    renderReport(diagnosis);

    setReportProgress(90, '正在写入历史记录', '报告即将完成，请稍候。');
    await nextUiFrame();
    history = [diagnosis, ...history.filter((item) => item.id !== diagnosis.id)].slice(0, 200);
    const historySaved = saveHistory();
    renderHistory();

    const meta = pendingImportMeta || { fileCount: 0, rowCount: 0, reportType: diagnosis.data.reportType, skippedText: '' };
    setReportProgress(100, '报告生成完成', historySaved ? `已生成${diagnosis.data.reportType}并写入历史。` : `已生成${diagnosis.data.reportType}，浏览器历史空间不足，建议先导出 Word 留档。`);
    await nextUiFrame();
    $('#importStatus').textContent = historySaved
      ? `已导入 ${meta.fileCount} 个文件、${meta.rowCount} 行数据，自动生成${diagnosis.data.reportType}并写入历史${meta.skippedText || ''}。`
      : `已导入 ${meta.fileCount} 个文件、${meta.rowCount} 行数据，已生成${diagnosis.data.reportType}；浏览器历史空间不足，建议立即导出 Word/TXT 留档${meta.skippedText || ''}。`;
    pendingImportMeta = null;
    importSessionRows = [];
    importSessionFileNames = [];
    importSessionSkippedFiles = [];
    updateWorkflowStatus('generated', historySaved
      ? `已生成${diagnosis.data.reportType}并写入历史。请先核实报告标题、周期、数据口径和关键结论。`
      : `已生成${diagnosis.data.reportType}，但历史空间不足未完整保存。请先导出 Word/TXT，再清理历史记录。`);
    isGeneratingReport = false;
    setReportGeneratingState(false);
    closeImportConfirmModal();
    jumpToReportPreview();
    toast(historySaved ? '已生成并写入历史，已跳转到报告预览，请先核实任务信息' : '报告已生成，历史空间不足，请先导出 Word 留档');
  } catch (error) {
    console.error('[Pinmoo] report generation failed', error);
    isGeneratingReport = false;
    setReportGeneratingState(false);
    const errorMessage = error?.message ? `失败原因：${error.message}` : '请检查文件识别类型、店铺信息或是否存在异常空表。';
    setReportProgress(100, '报告生成失败', errorMessage);
    updateWorkflowStatus('confirmError', `报告生成失败。${errorMessage}`);
    toast('报告生成失败，请检查文件识别结果后重试');
  }
}

function downloadDataTemplate() {
  const template = [
    '周期,日期,店铺名称,平台,行业,宝贝名称,流量来源,推广计划,活动名称,销售额,访客数,订单数,转化率,客单价,退款金额,退款率,退款原因,退款笔数,ROI,花费,点击量,加购数,商品总数,有成交商品数,TOP SKU销售占比,客服响应达标率,搜索占比,推荐占比,内容占比,付费占比,私域占比',
    '上期,2026-05-01,某美妆旗舰店,天猫,美妆个护,5年陈皮100g,搜索流量,关键词推广,日常销售,42000,31000,690,2.23,60.87,1800,4.8,规格误解,18,2.6,1200,3600,520,86,50,42,84,35,19,18,20,8',
    '本期,2026-05-08,某美妆旗舰店,天猫,美妆个护,5年陈皮100g,搜索流量,关键词推广,618预热,45800,32800,770,2.35,59.48,1600,4.2,物流破损,14,2.9,1350,3900,610,86,54,41,87,34,18,21,19,8',
    '本期,2026-05-09,某美妆旗舰店,天猫,美妆个护,礼盒组合装,付费流量,万相台推广,618预热,31800,18600,390,2.10,81.54,1200,3.8,描述不符,9,2.4,1325,2400,320,86,54,41,87,34,18,21,19,8'
  ].join('\n');
  downloadText(template, 'pinmoo-week-month-report-template.csv');
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 2200);
}

const workflowStates = {
  idle: {
    active: 'upload',
    hint: '导入、识别、确认、生成，最后更新行动状态并在下一周期验证。',
    labels: {
      upload: '等待上传经营报表',
      parse: '识别报表类型与关键字段',
      confirm: '核实店铺、周期和数据任务',
      preview: '生成复盘并确认异常依据',
      export: '更新行动状态并沉淀记录'
    }
  },
  selecting: {
    active: 'upload',
    hint: '请选择本周期需要分析的经营报表，可一次选择多份文件。',
    labels: { upload: '正在选择文件' }
  },
  parsing: {
    active: 'parse',
    done: ['upload'],
    hint: '系统正在读取文件、识别报表类型和汇总字段。',
    labels: { upload: '已选择文件', parse: '正在识别报表' }
  },
  confirm: {
    active: 'confirm',
    done: ['upload', 'parse'],
    hint: '请先确认文件识别结果、店铺名称、类目、平台和报告类型，确认后再写入历史。',
    labels: { upload: '文件已导入', parse: '报表已识别', confirm: '等待确认识别结果' }
  },
  draft: {
    active: 'confirm',
    done: ['upload', 'parse'],
    hint: '已生成草稿预览，但尚未写入历史；请回到确认弹窗或重新导入后生成正式报告。',
    labels: { upload: '数据已导入', parse: '报表已识别', confirm: '尚未最终确认', preview: '草稿可查看' }
  },
  confirmError: {
    active: 'confirm',
    error: ['confirm'],
    done: ['upload', 'parse'],
    hint: '有必填信息缺失，已在弹窗中标红，请补齐后再生成报告。',
    labels: { confirm: '需要补充信息' }
  },
  generating: {
    active: 'preview',
    done: ['upload', 'parse', 'confirm'],
    hint: '系统正在根据已确认的任务信息生成正式报告。',
    labels: { confirm: '任务已确认', preview: '正在生成报告' }
  },
  generated: {
    active: 'preview',
    done: ['upload', 'parse', 'confirm'],
    hint: '复盘已生成，请核实异常依据并更新行动状态；下期同店铺数据将自动验证效果。',
    labels: { upload: '数据已就绪', parse: '异常已识别', confirm: '任务已确认', preview: '等待核实复盘', export: '可跟踪行动或导出' }
  },
  exported: {
    active: 'export',
    done: ['upload', 'parse', 'confirm', 'preview', 'export'],
    hint: '本期复盘已沉淀。执行过程中可继续更新行动状态，下期将自动验证相关指标。',
    labels: { upload: '数据已就绪', parse: '异常已识别', confirm: '任务已确认', preview: '复盘已核实', export: '行动与报告已沉淀' }
  },
  error: {
    active: 'upload',
    error: ['upload'],
    hint: '导入失败，请检查文件是否加密、损坏，或改用 xls/xlsx/csv/docx 常见格式。',
    labels: { upload: '导入失败' }
  }
};

function updateWorkflowStatus(stateName = 'idle', detail = '') {
  const panel = $('#workflowPanel');
  const steps = $('#workflowSteps');
  if (!panel || !steps) return;
  const state = workflowStates[stateName] || workflowStates.idle;
  const order = ['upload', 'parse', 'confirm', 'preview', 'export'];
  const done = new Set(state.done || []);
  const errors = new Set(state.error || []);
  const activeIndex = order.indexOf(state.active);
  $('#workflowHint').textContent = detail || state.hint || workflowStates.idle.hint;
  order.forEach((key, index) => {
    const item = steps.querySelector(`[data-flow-step="${key}"]`);
    if (!item) return;
    item.classList.remove('active', 'done', 'error');
    if (errors.has(key)) item.classList.add('error');
    else if (done.has(key) || (stateName === 'exported' && index <= activeIndex)) item.classList.add('done');
    else if (key === state.active) item.classList.add('active');
    const label = item.querySelector('span');
    const text = state.labels?.[key] || workflowStates.idle.labels[key];
    if (label && text) label.textContent = text;
  });
}

function triggerDataImport(detail = '') {
  updateWorkflowStatus('selecting', detail || '请选择天猫/生意参谋经营报表，支持一次选择多份文件。');
  $('#dataFile').click();
}

function bindEvents() {
  document.querySelectorAll('#platformTabs button').forEach((button) => {
    button.addEventListener('click', () => {
      selectedPlatform = button.dataset.platform;
      document.querySelectorAll('#platformTabs button').forEach((item) => item.classList.toggle('selected', item === button));
      scheduleFormRecompute(80);
    });
  });

  fieldIds.forEach((id) => {
    const element = $('#' + id);
    if (!element) return;
    element.addEventListener('input', () => scheduleFormRecompute());
    element.addEventListener('change', () => scheduleFormRecompute(80));
  });

  $('#diagnosisForm').addEventListener('submit', (event) => {
    event.preventDefault();
    const data = getFormData();
    if (!hasMeaningfulData(data)) {
      toast('请至少填写销售额、访客或商品数据，或直接上传经营报表');
      return;
    }
    updateWorkflowStatus('generating', '正在根据当前表单内容生成报告，并写入历史记录。');
    setLatest(analyze(data), true);
    updateWorkflowStatus('generated', '已生成并保存诊断报告。请先核实报告预览，再导出 Word 或复制话术。');
    jumpToReportPreview();
    toast('已生成并保存诊断报告');
  });

  $('#loadSample').addEventListener('click', () => {
    resetImportSession();
    const sample = samples[Math.floor(Math.random() * samples.length)];
    setFormData(sample);
    setLatest(analyze(getFormData()));
    setManualFieldsVisible(false);
    updateWorkflowStatus('generated', '示例数据已导入并生成预览，可用于体验完整报告结构。');
    toast('已导入示例数据');
  });

  $('#resetForm').addEventListener('click', () => {
    resetImportSession();
    localStorage.removeItem(draftKey);
    setFormData(blankFormData());
    renderEmptyWorkspace();
    setManualFieldsVisible(true);
    updateWorkflowStatus('idle');
    toast('已清空当前任务');
  });

  $('#saveDraft').addEventListener('click', () => {
    localStorage.setItem(draftKey, JSON.stringify(getFormData()));
    updateWorkflowStatus('draft', '草稿已保存，但尚未写入正式历史；确认无误后请点击生成并保存。');
    toast('草稿已保存');
  });

  $('#historySearch').addEventListener('input', renderHistory);
  $('#actionList')?.addEventListener('input', (event) => {
    const control = event.target.closest('[data-action-owner], [data-action-due]');
    if (!control || !latestDiagnosis) return;
    const id = control.dataset.actionOwner || control.dataset.actionDue;
    let entry = actionLedger.find((item) => item.id === id);
    if (!entry) {
      entry = actionEntriesForDiagnosis(latestDiagnosis).find((item) => item.id === id);
      if (!entry) return;
      actionLedger.unshift(entry);
    }
    if (control.matches('[data-action-owner]')) entry.owner = control.value.trim() || '待确认';
    else if (control.value) entry.dueDate = control.value;
    saveActionLedger();
    clearTimeout(actionEditTimer);
    actionEditTimer = setTimeout(() => {
      renderReport(latestDiagnosis);
      renderHistory();
      updateWorkflowStatus('generated', '行动台账已自动保存。执行中可继续更新，下期同店铺复盘将自动验证对应指标。');
    }, 260);
  });
  $('#actionList')?.addEventListener('change', (event) => {
    const control = event.target.closest('[data-action-status], [data-action-owner], [data-action-due]');
    if (!control || !latestDiagnosis) return;
    const id = control.dataset.actionStatus || control.dataset.actionOwner || control.dataset.actionDue;
    let entry = actionLedger.find((item) => item.id === id);
    if (!entry) {
      entry = actionEntriesForDiagnosis(latestDiagnosis).find((item) => item.id === id);
      if (!entry) return;
      actionLedger.unshift(entry);
    }
    let message = '行动任务已更新';
    if (control.matches('[data-action-status]')) {
      entry.status = control.value;
      entry.completedAt = control.value === 'done' ? new Date().toLocaleString('zh-CN', { hour12: false }) : '';
      message = `行动状态已更新为“${actionStatusLabel(entry.status)}”`;
    } else if (control.matches('[data-action-owner]')) {
      entry.owner = control.value.trim() || '待确认';
      message = `责任人已更新为“${entry.owner}”`;
    } else {
      entry.dueDate = control.value || entry.dueDate;
      message = `截止日期已更新为 ${entry.dueDate}`;
    }
    if (!saveActionLedger()) return toast('行动状态未保存，请检查浏览器存储空间');
    renderActions(latestDiagnosis);
    renderReviewVerification(latestDiagnosis);
    renderReport(latestDiagnosis);
    renderHistory();
    updateWorkflowStatus('generated', '行动台账已保存。执行中可继续更新状态，下期同店铺复盘将自动验证对应指标。');
    toast(message);
  });
  $('#copyExecutive').addEventListener('click', copyExecutiveSummary);
  $('#copyWechat')?.addEventListener('click', copyWechatText);
  $('#copyReport').addEventListener('click', copyReport);
  $('#exportWord').addEventListener('click', exportWord);
  $('#exportReport').addEventListener('click', exportReport);
  $('#printReport').addEventListener('click', () => window.print());
  $('#exportHistory').addEventListener('click', exportHistory);
  $('#importHistory').addEventListener('click', () => $('#historyFile').click());
  $('#importData').addEventListener('click', () => triggerDataImport());
  $('#importDataMain')?.addEventListener('click', () => triggerDataImport());
  $('#toggleManualFieldsTop')?.addEventListener('click', () => {
    setManualFieldsVisible($('#manualFields')?.hidden, true);
  });
  document.addEventListener('click', (event) => {
    if (event.target.closest('[data-trigger-import]')) triggerDataImport();
  });
  $('#appendImportFiles')?.addEventListener('click', () => {
    triggerDataImport('请选择下一批报表文件，系统会追加到当前报告任务中。');
  });
  $('#resumeImportConfirm')?.addEventListener('click', () => {
    if (pendingImportMeta) openImportConfirmModal(pendingImportMeta);
  });
  $('#previewImportDraft')?.addEventListener('click', previewImportedDraft);
  $('#downloadTemplate').addEventListener('click', downloadDataTemplate);
  $('#confirmImportedReport').addEventListener('click', confirmImportedReport);
  document.querySelectorAll('[data-close-import-modal]').forEach((button) => {
    button.addEventListener('click', closeImportConfirmModal);
  });
  $('#modalStoreName').addEventListener('keydown', (event) => {
    if (event.key === 'Enter') confirmImportedReport();
  });
  ['modalStoreName', 'modalIndustry', 'modalPlatform', 'modalReportType'].forEach((id) => {
    const element = $('#' + id);
    element?.addEventListener('input', () => {
      element.closest('label')?.classList.remove('field-error');
      element.removeAttribute('aria-invalid');
    });
    element?.addEventListener('change', () => {
      element.closest('label')?.classList.remove('field-error');
      element.removeAttribute('aria-invalid');
    });
  });

  $('#dataFile').addEventListener('change', async (event) => {
    const files = event.target.files;
    if (!files || !files.length) return;
    try {
      await importDataFiles(files);
    } catch {
      updateWorkflowStatus('error');
      toast('导入失败，请检查字段名或使用模板 CSV');
    } finally {
      event.target.value = '';
    }
  });

  $('#historyFile').addEventListener('change', async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    try {
      const imported = JSON.parse(await file.text());
      const importedHistory = Array.isArray(imported) ? imported : imported.history;
      const importedLedger = Array.isArray(imported?.actionLedger) ? imported.actionLedger : [];
      if (!Array.isArray(importedHistory)) throw new Error('invalid');
      history = [...importedHistory, ...history]
        .filter((item, index, items) => item?.id && items.findIndex((candidate) => candidate?.id === item.id) === index)
        .slice(0, 200);
      actionLedger = [...importedLedger, ...actionLedger]
        .filter((item, index, items) => item?.id && items.findIndex((candidate) => candidate?.id === item.id) === index)
        .slice(0, 600);
      saveHistory();
      saveActionLedger();
      renderHistory();
      toast(`已导入 ${importedHistory.length} 份复盘记录和 ${importedLedger.length} 条行动任务`);
    } catch {
      toast('导入失败，请使用导出的 JSON 文件');
    } finally {
      event.target.value = '';
    }
  });

  $('#historyBody').addEventListener('click', (event) => {
    const loadButton = event.target.closest('[data-load]');
    const deleteButton = event.target.closest('[data-delete]');
    if (loadButton) {
      const item = history.find((record) => record.id === loadButton.dataset.load);
      if (!item) return;
      syncActionLedger(item);
      setFormData(item.data);
      setLatest(item);
      updateWorkflowStatus('generated', '已载入历史报告，请核实报告内容或继续导出交付。');
      document.getElementById('report').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (deleteButton) {
      const reportId = deleteButton.dataset.delete;
      const removed = history.find((record) => record.id === reportId);
      history = history.filter((record) => record.id !== reportId);
      const samePeriodStillExists = removed && history.some((record) =>
        normalizedStoreKey(record.data) === normalizedStoreKey(removed.data) &&
        normalizedPeriodKey(record.data) === normalizedPeriodKey(removed.data));
      if (removed && !samePeriodStillExists) {
        actionLedger = actionLedger.filter((entry) => !actionMatchesDiagnosis(entry, removed));
      }
      saveHistory();
      saveActionLedger();
      renderHistory();
      toast('已删除该复盘记录及对应行动任务');
    }
  });

  $('#clearHistory').addEventListener('click', () => {
    if (!history.length && !actionLedger.length) return toast('暂无历史可清空');
    history = [];
    actionLedger = [];
    saveHistory();
    saveActionLedger();
    renderHistory();
    toast('复盘历史与行动台账已清空');
  });

  window.addEventListener('beforeunload', (event) => {
    if (!isImportingFiles && !isGeneratingReport && !queuedImportFiles.length) return;
    event.preventDefault();
    event.returnValue = '';
  });
}

function init() {
  if ($('#appVersion')) $('#appVersion').textContent = appVersion;
  const draft = loadJson(draftKey, null);
  const isLegacySampleDraft = /示例数据/.test(String(draft?.dataSource || ''));
  const hasDraft = Boolean(!isLegacySampleDraft && draft && (draft.storeName || draft.sales || draft.dataSource));
  if (isLegacySampleDraft) localStorage.removeItem(draftKey);
  if (hasDraft) {
    setFormData({ ...blankFormData(), ...draft });
    setLatest(analyze(getFormData()));
    setManualFieldsVisible(true);
  } else {
    setFormData(blankFormData());
    setManualFieldsVisible(false);
    renderEmptyWorkspace();
  }
  renderHistory();
  bindEvents();
  updateWorkflowStatus(hasDraft ? 'draft' : 'idle', hasDraft ? '已载入上次保存的草稿，请核实后生成正式报告。' : '');
}

init();
